require('./config')
const fs = require('fs')
const chalk = require('chalk')

global.bugmenu = (prefix) => {
return`◪ ~𝗕𝗨𝗚 𝗣𝗥𝗜𝗕𝗔𝗗𝗜~ ⚙️ ೄྀ࿐ ˊˎ-
│
├─ ❏ ꜱᴀɴᴛᴇᴛ (628xxxx)
├─ ❏ ꜱᴇɴᴅɢᴀꜱꜰᴜʟʟ (628xxxx)
├─ ❏ ꜱᴇɴᴅᴜɴʟɪᴛʀᴏʟɪ (628xxxx)
├─ ❏ ꜱᴇɴᴅᴜɴʟɪᴅᴏᴄᴜ (628xxxx)
├─ ❏ ꜱᴇɴᴅᴜɴʟɪᴄᴜʏ (628xxxx)
├─ ❏ ꜱᴇɴᴅᴜɴʟɪʙᴏᴍ (628xxxx)
├─ ❏ ꜱᴇɴᴅᴜɴʟɪʟᴀɢ (628xxxx)
└─ ❏ ꜱᴇɴᴅᴜɴʟɪᴅᴇʟᴀʏ (628xxxx)

◪ ~𝗕𝗨𝗚 𝗚𝗥𝗨𝗣~ ⚙️ ೄྀ࿐ ˊˎ-
│
├─ ❏ ɢᴀꜱꜰᴜʟʟɢᴄ (ɪᴅ ɢʀᴏᴜᴘ)
├─ ❏ ꜱᴀɴᴛᴇᴛɢᴄ (ɪᴅ ɢʀᴏᴜᴘ)
├─ ❏ ᴛʀᴏʟɪɢᴄ (ɪᴅ ɢʀᴏᴜᴘ)
├─ ❏ ᴅᴏᴄᴜɢᴄ (ɪᴅ ɢʀᴏᴜᴘ)
├─ ❏ ᴜɴʟɪᴅᴇʟᴀʏɢᴄ (ɪᴅ ɢʀᴏᴜᴘ)
├─ ❏ ᴜɴʟɪʟᴀɢɢᴄ (ɪᴅ ɢʀᴏᴜᴘ)
├─ ❏ ᴜɴʟɪʙᴏᴍɢᴄ (ɪᴅ ɢʀᴏᴜᴘ)
└─ ❏ ᴜɴʟɪᴄᴜʏɢᴄ (ɪᴅ ɢʀᴏᴜᴘ)

◪ ~𝗕𝗨𝗚 𝗦𝗣𝗔𝗠~ ⚙️ ೄྀ࿐ ˊˎ-
│
├─ ❏ ᴜɴʟɪᴛᴇᴛ
├─ ❏ ᴜɴʟɪᴛʀᴏʟɪ
├─ ❏ ᴜɴʟɪᴅᴏᴄᴜ
├─ ❏ ᴜɴʟɪᴠɪʀᴛᴇxᴛ
├─ ❏ ᴜɴʟɪᴅᴇʟᴀʏ
├─ ❏ ᴜɴʟɪʟᴀɢ
├─ ❏ ᴜɴʟɪʙᴏᴍ
└─ ❏ ᴜɴʟɪᴄᴜʏ
`}

global.downloadmenu = (prefix) => {
return`◪ ~𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 𝗠𝗘𝗡𝗨~ 📥 ೄྀ࿐ ˊˎ-
│
├─ ❏ fbvideo (linknya)
├─ ❏ igvideo (linknya)
├─ ❏ twitvideo (linknya)
├─ ❏ tiktokvideo (linknya)
├─ ❏ tiktokaudio (linknya)
├─ ❏ ytmp3 (linknya)
├─ ❏ ytmp4 (linknya)
├─ ❏ ytsearch (nama pencarian)
├─ ❏ play (linknya)
├─ ❏ mediafire (linknya)
├─ ❏ gitclone (linknya)
├─ ❏ spotify (linknya)
├─ ❏ happymod (nama apk)
├─ ❏ gdrive (link)
├─ ❏ ringtone (text)
├─ ❏ xnxxsearch/xnxxs (text)
├─ ❏ xnxxdl (linknya)
├─ ❏ xvideosearch/xvideos (text)
├─ ❏ xvideodl (linknya)
└─ ❏ sfilemobisearch (text)
`}

global.groupmenu = (prefix) => {
return`◪ ~𝗚𝗥𝗨𝗣 𝗠𝗘𝗡𝗨~ 🗃️ೄྀ࿐ ˊˎ-
│
├─ ❏ welcome [ 𝗼𝗻 | 𝗼𝗳𝗳 ]
├─ ❏ antilink [ 𝗼𝗻 | 𝗼𝗳𝗳 ]
├─ ❏ antilinkgc [ 𝗼𝗻 | 𝗼𝗳𝗳 ]
├─ ❏ antilinkwame [ 𝗼𝗻 | 𝗼𝗳𝗳 ]
├─ ❏ antitoxic [ 𝗼𝗻 | 𝗼𝗳𝗳 ]
├─ ❏ hapuspromo [ 𝗼𝗻 | 𝗼𝗳𝗳 ]
├─ ❏ antivirus [ 𝗼𝗻 | 𝗼𝗳𝗳 ]
├─ ❏ antibule [ 𝗼𝗻 | 𝗼𝗳𝗳 ]
├─ ❏ bukagrup [ 𝗱 | 𝗺 | 𝗷 | 𝗵 ]
├─ ❏ tutupgrup [ 𝗱 | 𝗺 | 𝗷 | 𝗵 ]
├─ ❏ group [ open | close ]
├─ ❏ editinfo [ open | close ]
├─ ❏ ban (628xxx)
├─ ❏ unban (628xxx)
├─ ❏ listban
├─ ❏ pushkontak (textnya)
├─ ❏ pushkontakid (id group | Text)
├─ ❏ bcgc (textnya)
├─ ❏ openai (textnya)
├─ ❏ hidetag (textnya)
├─ ❏ kick (628xx)
├─ ❏ add (628xx)
├─ ❏ promote (628xx)
├─ ❏ demote (628xx)
├─ ❏ sendlinkgc (628xx)
├─ ❏ join (linknya)
├─ ❏ editsubjek (textnya)
├─ ❏ editdesk (textnya)
├─ ❏ tagall (textnya)
├─ ❏ inspect (linknya)
├─ ❏ linkgroup
├─ ❏ resetlinkgc
├─ ❏ promoteall
├─ ❏ demoteall
├─ ❏ addbadword (kata kotor/kasar)
├─ ❏ delbadword (kata kotor/kasar)
├─ ❏ larangan
├─ ❏ setppgroup
├─ ❏ virgam
├─ ❏ buatsw
├─ ❏ buatswimage
├─ ❏ buatswvideo
├─ ❏ swin
├─ ❏ vnsw
├─ ❏ inisw
├─ ❏ buatswptv
├─ ❏ toptv
├─ ❏ buatsws
├─ ❏ vote
├─ ❏ upvote
├─ ❏ checkvote
├─ ❏ delvote
├─ ❏ poll
├─ ❏ warn
└─ ❏ delwarn
`}

global.randommenu = (prefix) => {
return`◪ ~𝗥𝗔𝗡𝗗𝗢𝗠 𝗠𝗘𝗡𝗨~ 🕹️ೄྀ࿐ ˊˎ-
│
├─ ❏ owner
├─ ❏ sticker
├─ ❏ qc (warna text)
├─ ❏ sewa
├─ ❏ wm
├─ ❏ wmvideo
├─ ❏ emojimix
├─ ❏ emojimix2
├─ ❏ attp (textnya)
├─ ❏ ttp (textnya)
├─ ❏ afk (alasan afk)
├─ ❏ faktaunik
├─ ❏ katabijak
├─ ❏ pantun
├─ ❏ bucin
├─ ❏ toimage
├─ ❏ tomp4
├─ ❏ tomp3
├─ ❏ toaud
├─ ❏ tovn
├─ ❏ togif
├─ ❏ tourl
├─ ❏ smeme
├─ ❏ quotes
├─ ❏ darkjokes
├─ ❏ google
├─ ❏ couple
├─ ❏ coffe
├─ ❏ getname
├─ ❏ getpic
├─ ❏ setppbot
├─ ❏ block
├─ ❏ unblock
├─ ❏ infogempa
├─ ❏ lirik
├─ ❏ cerpen
├─ ❏ ceritahoror
├─ ❏ cuaca
├─ ❏ jadwaltv
├─ ❏ jadwalnow
├─ ❏ runtime
├─ ❏ imdb
├─ ❏ ping
├─ ❏ myip
├─ ❏ restart (Work In Panell Only)
├─ ❏ shutdown
├─ ❏ listpc
├─ ❏ listgc
├─ ❏ remini
├─ ❏ reportbug (text)
├─ ❏ obfuscate (java scripts)
├─ ❏ gayatext (text)
├─ ❏ fliptext (text)
├─ ❏ tts (text)
├─ ❏ bass
├─ ❏ blown
├─ ❏ deep
├─ ❏ earrape
├─ ❏ fast
├─ ❏ fat
├─ ❏ nightcore
├─ ❏ reverse
├─ ❏ robot
├─ ❏ slow
├─ ❏ smooth
├─ ❏ squirrel
├─ ❏ ebinary
├─ ❏ dbinary
├─ ❏ ssweb
├─ ❏ tinyurl
└─ ❏ limit (untuk cek limit)
`}

global.islammenu = (prefix) => {
return`◪ ~𝗜𝗦𝗟𝗔𝗠 𝗠𝗘𝗡𝗨~ 🕋 ೄྀ࿐ ˊˎ-
│
├─ ❏ jadwalsholat (Kota)
├─ ❏ kisahnabi (Nama Nabi)
├─ ❏ alquranaudio
├─ ❏ asmaulhusna (1-99)
├─ ❏ alquran
└─ ❏ listsurah
`}

global.gasmenu = (prefix) => {
return`◪ ~𝗚𝗔𝗦 𝗠𝗘𝗡𝗨~ ⛽ ೄྀ࿐ ˊˎ-
│
├─ ❏ spamsms (628xx)
├─ ❏ call (628xx)
├─ ❏ kenon (628xx)
├─ ❏ banned (+628xx)
├─ ❏ unbannedv2 (+628xx)
├─ ❏ unbannedv3 (+628xx)
├─ ❏ unbannedv4 (+628xx)
└─ ❏ unbannedv5 (+628xx)
`}

global.textmakermenu = (prefix) => {
return`◪ ~𝗧𝗘𝗫𝗧𝗣𝗥𝗢~ 📝ೄྀ࿐ ˊˎ-
│
├─ ❏ candy 
├─ ❏ christmas 
├─ ❏ 3dchristmas 
├─ ❏ sparklechristmas
├─ ❏ deepsea 
├─ ❏ scifi 
├─ ❏ rainbow 
├─ ❏ waterpipe 
├─ ❏ spooky 
├─ ❏ pencil 
├─ ❏ circuit 
├─ ❏ discovery 
├─ ❏ metalic 
├─ ❏ fiction 
├─ ❏ demon 
├─ ❏ transformer 
├─ ❏ berry 
├─ ❏ thunder 
├─ ❏ magma 
├─ ❏ 3dstone 
├─ ❏ neonlight 
├─ ❏ glitch 
├─ ❏ harrypotter 
├─ ❏ brokenglass 
├─ ❏ papercut 
├─ ❏ watercolor 
├─ ❏ multicolor 
├─ ❏ neondevil 
├─ ❏ underwater 
├─ ❏ graffitibike
├─ ❏ snow 
├─ ❏ cloud 
├─ ❏ honey 
├─ ❏ ice 
├─ ❏ fruitjuice 
├─ ❏ biscuit 
├─ ❏ wood 
├─ ❏ chocolate 
├─ ❏ strawberry 
├─ ❏ matrix 
├─ ❏ blood 
├─ ❏ dropwater 
├─ ❏ toxic 
├─ ❏ lava 
├─ ❏ rock 
├─ ❏ bloodglas 
├─ ❏ hallowen 
├─ ❏ darkgold 
├─ ❏ joker 
├─ ❏ wicker
├─ ❏ firework 
├─ ❏ skeleton 
├─ ❏ blackpink 
├─ ❏ sand 
├─ ❏ glue 
├─ ❏ 1917 
├─ ❏ leaves
├─ ❏ retro
├─ ❏ pornhub
├─ ❏ 8bit
├─ ❏ batman
├─ ❏ 3dbox
├─ ❏ lion
├─ ❏ 3davengers
├─ ❏ window
├─ ❏ 3dspace
├─ ❏ bokeh
├─ ❏ holographic
├─ ❏ thewall
├─ ❏ carbon
├─ ❏ whitebear
├─ ❏ metallic
├─ ❏ steel
├─ ❏ fabric
├─ ❏ ancient
├─ ❏ marvel
└─ ❏ naruto

◪ ~𝗘𝗽𝗵𝗼𝘁𝗼360~ 📝 ೄྀ࿐ ˊˎ-
│
├─ ❏ glitchtext
├─ ❏ writetext
├─ ❏ advancedglow
├─ ❏ typographytext
├─ ❏ pixelglitch
├─ ❏ neonglitch
├─ ❏ flagtext
├─ ❏ flag3dtext
├─ ❏ deletingtext
├─ ❏ blackpinkstyle
├─ ❏ glowingtext
├─ ❏ underwatertext
├─ ❏ logomaker
├─ ❏ cartoonstyle
├─ ❏ papercutstyle
├─ ❏ watercolortext
├─ ❏ effectclouds
├─ ❏ blackpinklogo
├─ ❏ gradienttext
├─ ❏ summerbeach
├─ ❏ luxurygold
├─ ❏ multicoloredneon
├─ ❏ sandsummer
├─ ❏ galaxywallpaper
├─ ❏ 1917style
├─ ❏ makingneon
├─ ❏ royaltext
├─ ❏ freecreate
├─ ❏ galaxystyle
└─ ❏ lighteffects

◪ ~𝗣𝗵𝗼𝘁𝗼𝗢𝘅𝘆~ 📝 ೄྀ࿐ ˊˎ-
│
├─ ❏ shadow 
├─ ❏ write 
├─ ❏ romantic 
├─ ❏ burnpaper
├─ ❏ smoke 
├─ ❏ narutobanner 
├─ ❏ love 
├─ ❏ undergrass
├─ ❏ doublelove 
├─ ❏ coffecup
├─ ❏ underwaterocean
├─ ❏ smokyneon
├─ ❏ starstext
├─ ❏ rainboweffect
├─ ❏ balloontext
├─ ❏ metalliceffect
├─ ❏ embroiderytext
├─ ❏ flamingtext
├─ ❏ stonetext
├─ ❏ writeart
├─ ❏ summertext
├─ ❏ wolfmetaltext
├─ ❏ nature3dtext
├─ ❏ rosestext
├─ ❏ naturetypography
├─ ❏ quotesunder
└─ ❏ shinetext
`}

global.listmusikmenu = (prefix) => {
return`◪ ~𝗠𝗨𝗦𝗜𝗞 𝗠𝗘𝗡𝗨~ 🎧 ೄྀ࿐ ˊˎ-
│
├─ ❏ sound1
├─ ❏ sound2
├─ ❏ sound3
├─ ❏ sound4
├─ ❏ sound5
├─ ❏ sound6
├─ ❏ sound7
├─ ❏ sound8
├─ ❏ sound9
├─ ❏ sound10
├─ ❏ sound11
├─ ❏ sound12
├─ ❏ sound13
├─ ❏ sound14
├─ ❏ sound15
├─ ❏ sound16
├─ ❏ sound17
├─ ❏ sound18
├─ ❏ sound18
├─ ❏ sound20
├─ ❏ sound21
├─ ❏ sound22
├─ ❏ sound23
├─ ❏ sound24
├─ ❏ sound25
├─ ❏ sound26
├─ ❏ sound27
├─ ❏ sound28
├─ ❏ sound29
├─ ❏ sound30
├─ ❏ sound31
├─ ❏ sound32
├─ ❏ sound33
├─ ❏ sound34
├─ ❏ sound35
├─ ❏ sound36
├─ ❏ sound37
├─ ❏ sound38
├─ ❏ sound39
├─ ❏ sound40
├─ ❏ sound41
├─ ❏ sound42
├─ ❏ sound43
├─ ❏ sound44
├─ ❏ sound45
├─ ❏ sound46
├─ ❏ sound47
├─ ❏ sound48
├─ ❏ sound49
├─ ❏ sound50
├─ ❏ sound51
├─ ❏ sound52
├─ ❏ sound53
├─ ❏ sound54
├─ ❏ sound55
├─ ❏ sound56
├─ ❏ sound57
├─ ❏ sound58
├─ ❏ sound59
├─ ❏ sound60
├─ ❏ sound61
├─ ❏ sound62
├─ ❏ sound63
├─ ❏ sound64
├─ ❏ sound65
├─ ❏ sound66
├─ ❏ sound67
├─ ❏ sound68
├─ ❏ sound69
├─ ❏ sound70
├─ ❏ sound71
├─ ❏ sound72
├─ ❏ sound73
├─ ❏ sound74
├─ ❏ sound75
├─ ❏ sound76
├─ ❏ sound77
├─ ❏ sound78
├─ ❏ sound79
├─ ❏ sound80
├─ ❏ sound81
├─ ❏ sound82
├─ ❏ sound83
├─ ❏ sound84
├─ ❏ sound85
├─ ❏ sound86
├─ ❏ sound87
├─ ❏ sound88
├─ ❏ sound89
├─ ❏ sound90
├─ ❏ sound91
├─ ❏ sound92
├─ ❏ sound93
├─ ❏ sound94
├─ ❏ sound95
├─ ❏ sound96
├─ ❏ sound97
├─ ❏ sound98
├─ ❏ sound99
├─ ❏ sound100
├─ ❏ sound101
├─ ❏ sound102
├─ ❏ sound103
├─ ❏ sound104
├─ ❏ sound105
├─ ❏ sound106
├─ ❏ sound107
├─ ❏ sound108
├─ ❏ sound109
├─ ❏ sound110
├─ ❏ sound111
├─ ❏ sound112
├─ ❏ sound113
├─ ❏ sound114
├─ ❏ sound115
├─ ❏ sound116
├─ ❏ sound117
├─ ❏ sound118
├─ ❏ sound119
├─ ❏ sound120
├─ ❏ sound121
├─ ❏ sound122
├─ ❏ sound123
├─ ❏ sound124
├─ ❏ sound125
├─ ❏ sound126
├─ ❏ sound127
├─ ❏ sound128
├─ ❏ sound129
├─ ❏ sound130
├─ ❏ sound131
├─ ❏ sound132
├─ ❏ sound133
├─ ❏ sound134
├─ ❏ sound135
├─ ❏ sound136
├─ ❏ sound137
├─ ❏ sound138
├─ ❏ sound139
├─ ❏ sound140
├─ ❏ sound141
├─ ❏ sound142
├─ ❏ sound143
├─ ❏ sound144
├─ ❏ sound145
├─ ❏ sound146
├─ ❏ sound147
├─ ❏ sound148
├─ ❏ sound149
├─ ❏ sound150
├─ ❏ sound151
├─ ❏ sound152
├─ ❏ sound153
├─ ❏ sound154
├─ ❏ sound155
├─ ❏ sound156
├─ ❏ sound157
├─ ❏ sound158
├─ ❏ sound159
├─ ❏ sound160
└─ ❏ sound161
`}

global.addmenmenu = (prefix) => {
return`◪ ~𝗔𝗗𝗗 𝗠𝗘𝗡𝗨~ ➕ ೄྀ࿐ ˊˎ-
│
├─ ❏ addprem
├─ ❏ delprem
├─ ❏ listprem
├─ ❏ addsewa
├─ ❏ delsewa
├─ ❏ listsewa
├─ ❏ addseler
├─ ❏ delseler
├─ ❏ listseler
├─ ❏ setcmd
├─ ❏ delcmd
├─ ❏ listcmd
├─ ❏ addpdf
├─ ❏ delpdf
├─ ❏ listpdf
├─ ❏ yopdf
├─ ❏ sendpdf
├─ ❏ addzip
├─ ❏ delzip
├─ ❏ listzip
├─ ❏ yozip
├─ ❏ sendzip
├─ ❏ addapk
├─ ❏ delapk
├─ ❏ listapk
├─ ❏ yoapk
├─ ❏ sendapk
├─ ❏ addvn
├─ ❏ delvn
├─ ❏ listvn
├─ ❏ addmsg
├─ ❏ sendlist
├─ ❏ listmsg
├─ ❏ delmsg
└─ ❏ getmsg
`}

global.cucimatamenu = (prefix) => {
return`◪ ~𝗧𝗶𝗸𝘁𝗼𝗸 𝗩𝗶𝗱𝗲𝗼~ 💽 ೄྀ࿐ ˊˎ-
│
├─ ❏ tiktokgirl
├─ ❏ tiktokghea
├─ ❏ tiktokbocil
├─ ❏ tiktoknukhty
├─ ❏ tiktoksantuy
├─ ❏ tiktokkayes
├─ ❏ tiktokpanrika
└─ ❏ tiktoknotnot

◪ ~𝗖𝘂𝗰𝗶 𝗠𝗮𝘁𝗮~ 🎊 ೄྀ࿐ ˊˎ-
│
├─ ❏ china
├─ ❏ hijab
├─ ❏ indo
├─ ❏ japanese
├─ ❏ korean
├─ ❏ malay
├─ ❏ randomgirl
├─ ❏ randomboy
├─ ❏ thai
└─ ❏ vietnamese

◪ ~𝗣𝗜𝗖𝗞 𝗥𝗔𝗡𝗗𝗢𝗠~ 🖼️ ೄྀ࿐ ˊˎ-
│
├─ ❏ aesthetic
├─ ❏ akira
├─ ❏ akiyama
├─ ❏ ana
├─ ❏ art
├─ ❏ asuna
├─ ❏ ayuzawa
├─ ❏ boneka
├─ ❏ boruto
├─ ❏ bts
├─ ❏ cecan
├─ ❏ chiho
├─ ❏ chitoge
├─ ❏ cogan
├─ ❏ cosplay
├─ ❏ cosplayloli
├─ ❏ cosplaysagiri
├─ ❏ cyber
├─ ❏ deidara
├─ ❏ doraemon
├─ ❏ eba
├─ ❏ elaina
├─ ❏ emilia
├─ ❏ erza
├─ ❏ exo
├─ ❏ femdom
├─ ❏ freefire
├─ ❏ gamewallpaper
├─ ❏ glasses
├─ ❏ gremory
├─ ❏ hacker
├─ ❏ hestia
├─ ❏ husbu
├─ ❏ inori
├─ ❏ islamic
├─ ❏ isuzu
├─ ❏ itachi
├─ ❏ itori
├─ ❏ jennie
├─ ❏ jiso
├─ ❏ justina
├─ ❏ kaga
├─ ❏ kagura
├─ ❏ kakasih
├─ ❏ kaori
├─ ❏ cartoon
├─ ❏ shortquote
├─ ❏ keneki
├─ ❏ kotori
├─ ❏ kpop
├─ ❏ kucing
├─ ❏ kurumi
├─ ❏ lisa
├─ ❏ madara
├─ ❏ megumin
├─ ❏ mikasa
├─ ❏ mikey
├─ ❏ miku
├─ ❏ minato
├─ ❏ mobile
├─ ❏ motor
├─ ❏ mountain
├─ ❏ narutouzumaki
├─ ❏ nekonime
├─ ❏ nezuko
├─ ❏ onepiece
├─ ❏ pentol
├─ ❏ pokemon
├─ ❏ profil
├─ ❏ progamming
├─ ❏ pubg
├─ ❏ randblackpink
├─ ❏ randomnime
├─ ❏ randomnime2
├─ ❏ rize
├─ ❏ rose
├─ ❏ ryujin
├─ ❏ sagiri
├─ ❏ sakura
├─ ❏ sasuke
├─ ❏ satanic
├─ ❏ shina
├─ ❏ shinka
├─ ❏ shinomiya
├─ ❏ shizuka
├─ ❏ shota
├─ ❏ space
├─ ❏ technology
├─ ❏ tejina
├─ ❏ toukachan
├─ ❏ tsunade
├─ ❏ waifu
├─ ❏ wallhp
├─ ❏ wallml
├─ ❏ wallmlnime
├─ ❏ yotsuba
├─ ❏ yuki
├─ ❏ yulibocil
├─ ❏ yumeko
├─ ❏ cat
├─ ❏ notnot
├─ ❏ ulzzangboy
├─ ❏ antiwork
├─ ❏ ppcouple
├─ ❏ ulzzanggirl
├─ ❏ bike
├─ ❏ doggo
├─ ❏ profilepic
├─ ❏ kayes
└─ ❏ car
`}

global.beritamenu = (prefix) => {
return`◪ ~𝗕𝗘𝗥𝗜𝗧𝗔 𝗠𝗘𝗡𝗨~ 🗞️ ೄྀ࿐ ˊˎ-
│
├─ ❏ fajar
├─ ❏ cnn
├─ ❏ layarkaca
├─ ❏ cnbc
├─ ❏ tribun
├─ ❏ indozone
├─ ❏ kompas
├─ ❏ detik
├─ ❏ daily
├─ ❏ inews
├─ ❏ okezone
├─ ❏ sindo
├─ ❏ tempo
├─ ❏ antara
├─ ❏ kontan
├─ ❏ merdeka
└─ ❏ jalantikus-meme
`}

global.nsfwmenu = (prefix) => {
return`◪ ~𝗡𝗦𝗙𝗪 𝗠𝗘𝗡𝗨~ 🔞 ೄྀ࿐ ˊˎ-
│
├─ ❏ ahegao
├─ ❏ cum
├─ ❏ hentai
├─ ❏ hentaivideo
├─ ❏ hneko
├─ ❏ nwaifu
├─ ❏ animespank
├─ ❏ orgy
├─ ❏ ass
├─ ❏ eba
├─ ❏ jahy
├─ ❏ panties
├─ ❏ asupan2
├─ ❏ ero
├─ ❏ manga
├─ ❏ pussy
├─ ❏ asupan
├─ ❏ femdom
├─ ❏ masturbation
├─ ❏ tentacles
├─ ❏ bdsm
├─ ❏ foot
├─ ❏ milf
├─ ❏ thighs
├─ ❏ blowjob
├─ ❏ gangbang
├─ ❏ neko
├─ ❏ yuri
├─ ❏ boobs
├─ ❏ gifs
├─ ❏ zettai
├─ ❏ cuckold
├─ ❏ glasses
├─ ❏ nsfwloli
└─ ❏ loli
`}

global.funmenu = (prefix) => {
return`◪ ~𝗙𝗨𝗡 𝗠𝗘𝗡𝗨~ 🎭 ೄྀ࿐ ˊˎ-
│
├─ ❏ ᴀʀᴛɪɴᴀᴍᴀ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ᴀʀᴛɪᴍɪᴍᴘɪ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ᴋᴇᴄᴏᴄᴏᴋᴀɴᴘᴀꜱᴀɴɢᴀɴ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ᴋᴇᴄᴏᴄᴏᴋᴀɴɴᴀᴍᴀ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ᴊᴀᴅɪᴀɴᴘᴇʀɴɪᴋᴀʜᴀɴ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ʀᴇᴊᴇᴋɪ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ꜱɪꜰᴀᴛᴜꜱᴀʜᴀ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ᴘᴇᴋᴇʀᴊᴀᴀɴ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ᴀʀᴛɪᴛᴀʀᴏᴛ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ᴘᴏᴛᴇɴꜱɪᴘᴇɴʏᴀᴋɪᴛ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ʀᴀᴍᴀʟᴀɴɴᴀꜱɪʙ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ʜᴀʀɪꜱᴀɴɢᴀʀ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ʜᴀʀɪʙᴀɪᴋ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ꜰᴇɴɢꜱʜᴜɪ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ɴᴀɢᴀʜᴀʀɪ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ʜᴀʀɪɴᴀᴀꜱ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ᴡᴇᴛᴏɴ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ᴘᴇʀᴜɴᴛᴜɴɢᴀɴ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ᴀʀᴀʜʀᴇᴊᴇᴋɪ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ꜱɪꜰᴀᴛ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ᴋᴇʙᴇʀᴜɴᴛᴜɴɢᴀɴ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ᴍᴇᴍᴀɴᴄɪɴɢ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ᴍᴀꜱᴀꜱᴜʙᴜʀ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ᴢᴏᴅɪᴀᴋ (ᴛᴇxᴛɴʏᴀ)
├─ ❏ ꜱʜɪᴏ (ᴛᴇxᴛɴʏᴀ)
└─ ❏ ʀᴀᴍᴀʟᴀɴᴊᴏᴅᴏʜ (ᴛᴇxᴛɴʏᴀ)
`}

global.stalkmenu = (prefix) => {
return`◪ ~𝗦𝗧𝗔𝗟𝗞𝗘𝗥 𝗠𝗘𝗡𝗨~ 📊 ೄྀ࿐ ˊˎ-
│
├─ ❏ ffstalk (ID FF)
├─ ❏ mlstalk (ID ML | ID ZONE)
├─ ❏ npmstalk (Nama Module)
├─ ❏ githubstalk (Username)
├─ ❏ igstalk (Nick Name IG)
└─ ❏ stalktiktok (Username Tiktok)
`}

global.storemenu = (prefix) => {
return`◪ ~𝗦𝗧𝗢𝗥𝗘 𝗠𝗘𝗡𝗨~ 🛍️ ೄྀ࿐ ˊˎ-
│
├─ ❏ produk
├─ ❏ addproduk
├─ ❏ delproduk
├─ ❏ updateproduk
├─ ❏ proses
└─ ❏ done
`}

global.gamemenu = (prefix) => {
return`◪ ~𝗚𝗔𝗠𝗘 𝗠𝗘𝗡𝗨~ 🎮 ೄྀ࿐ ˊˎ-
│
├─ ❏ ttc
├─ ❏ deltc
├─ ❏ suitpvp
├─ ❏ tebak kata
├─ ❏ tebak gambar
├─ ❏ tebak lirik
├─ ❏ tebak kalimat
├─ ❏ tebak lontong
├─ ❏ family100
├─ ❏ kuismath noob
├─ ❏ kuismath easy
├─ ❏ kuismath medium
├─ ❏ kuismath hard
├─ ❏ kuismath extreme
├─ ❏ kuismath impossible
└─ ❏ kuismath impossible2
`}

global.scmenu = (prefix) => {
return`°⌜꧁༒~${global.botname}~༒꧂⌟°


*bot version update :* ${global.hinatabotversion}

   ()   ()
 („• ֊ •„)
━O━O━━━━━━━━━━
 ~𝗜𝗡𝗙𝗢 𝗨𝗣𝗗𝗔𝗧𝗘~ ೄྀ࿐ ˊˎ-
 ━━━━━━⊱⋆⊰━━━━━━
ミ Meng optimalakan fitur pemakaian limit
ミ Add fitur warn for group
ミ Add fitur unbanned v2-5
ミ Auto kick user in max warn

◪ ~𝗡𝗲𝘄 𝗙𝗶𝘁𝘂𝗿~ ೄྀ࿐ ˊˎ-
│
├─ ❏ shinobu
├─ ❏ bully
├─ ❏ cuddle
├─ ❏ cry
├─ ❏ hug
├─ ❏ awoo
├─ ❏ kiss
├─ ❏ pat
├─ ❏ 
├─ ❏ 
├─ ❏ 
├─ ❏ 
├─ ❏ 
├─ ❏ 
├─ ❏ 
├─ ❏ 
├─ ❏ 
├─ ❏ 
├─ ❏ 
├─ ❏ 
├─ ❏ 
├─ ❏ 
├─ ❏ 
├─ ❏ 
└─ ❏ unbannedv5 (+628xx)

kalau mau semprot donasi ya monggo
dana : 089629929193

pm owner jika ada yang ingin di tnyakan
+${global.ownernumber}

Terima Kasih.. 🤗
`}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})