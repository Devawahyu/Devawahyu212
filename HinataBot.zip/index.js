require('./config')
const { modul } = require('./module')
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, generateForwardMessageContent, prepareWAMessageMedia, generateWAMessageFromContent, generateMessageID, downloadContentFromMessage, makeInMemoryStore, jidDecode, getAggregateVotesInPollMessage, areJidsSameUser, proto, delay } = global.baileys
const { axios, boom, FileType, fs, pino, chalk, colors, path, yargs, PhoneNumber, moment, _ } = modul
const { Boom } = boom
const { color, bgcolor } = require('./HinataBase/lib/color')
const { uncache, nocache } = require('./HinataBase/lib/loader')
const { start } = require('./HinataBase/lib/spinner')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./HinataBase/lib/exif')
const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, await, sleep } = require('./HinataBase/lib/myfunc')
//=================================================//
var low
try {
low = require('lowdb')
} catch (e) {
low = require('./HinataBase/lib/lowdb')}
//=================================================//
const { Low, JSONFile } = low
const mongoDB = require('./HinataBase/lib/mongoDB')
//=================================================//
//=================================================//
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
//=================================================//
global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse())
global.db = new Low(
/https?:\/\//.test(opts['db'] || '') ?
new cloudDBAdapter(opts['db']) : /mongodb/.test(opts['db']) ?
new mongoDB(opts['db']) :
new JSONFile(`./HinataBase/database/database.json`)
)
global.DATABASE = global.db // Backwards Compatibility
global.loadDatabase = async function loadDatabase() {
if (global.db.READ) return new Promise((resolve) => setInterval(function () { (!global.db.READ ? (clearInterval(this), resolve(global.db.data == null ? global.loadDatabase() : global.db.data)) : null) }, 1 * 1000))
if (global.db.data !== null) return
global.db.READ = true
await global.db.read()
global.db.READ = false
global.db.data = {
users: {},
chats: {},
game: {},
database: {},
settings: {},
setting: {},
others: {},
sticker: {},
...(global.db.data || {})}
global.db.chain = _.chain(global.db.data)}
loadDatabase()
if (global.db) setInterval(async () => {
if (global.db.data) await global.db.write()
}, 30 * 1000)
//=================================================//
async function starthinata() {
const { state, saveCreds } = await useMultiFileAuthState(global.sessionName)
let { version, isLatest } = await fetchLatestBaileysVersion() 
const connectionOptions = {
version,
printQRInTerminal: true,
auth: state,
browser: [`${global.botname}`, 'Safari', '1.0.0'],
logger: pino({ level: 'silent' })
} 
const hinata = makeWASocket(connectionOptions)
//=================================================//
hinata.decodeJid = (jid) => {
if (!jid) return jid
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {}
return decode.user && decode.server && decode.user + '@' + decode.server || jid
} else return jid
}
//=================================================//
hinata.ev.on('messages.upsert', async chatUpdate => {
try {
mek = chatUpdate.messages[0]
if (!mek.message) return
mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
if (mek.key && mek.key.remoteJid === 'status@broadcast')  {
await hinata.readMessages([mek.key]) }
if (!hinata.public && !mek.key.fromMe && chatUpdate.type === 'notify') return
if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return
const m = smsg(hinata, mek, store)
require("./hinata")(hinata, m, chatUpdate, store)
} catch (err) {
console.log(err)
}
})
hinata.ev.on('call', async (celled) => {
let botNumber = await hinata.decodeJid(hinata.user.id)
let koloi = global.anticall
if (!koloi) return
console.log(celled)
for (let kopel of celled) {
if (kopel.isGroup == false) {
if (kopel.status == "offer") {
let nomer = await hinata.sendTextWithMentions(kopel.from, `*${hinata.user.name}* tidak bisa menerima panggilan ${kopel.isVideo ? `video` : `suara`}. Maaf @${kopel.from.split('@')[0]} kamu akan diblokir. Silahkan hubungi Owner membuka blok !`)
hinata.sendContact(kopel.from, owner.map( i => i.split("@")[0]), nomer)
await sleep(8000)
await hinata.updateBlockStatus(kopel.from, "block")
}
}
}
})
hinata.ev.on('messages.update', async chatUpdate => {
for(const { key, update } of chatUpdate) {
if(update.pollUpdates && key.fromMe) {
const pollCreation = await getMessage(key)
if(pollCreation) {
const pollUpdate = await getAggregateVotesInPollMessage({
message: pollCreation,
pollUpdates: update.pollUpdates,
})
var toCmd = pollUpdate.filter(v => v.voters.length !== 0)[0]?.name
if (toCmd == undefined) return
var prefCmd = prefix+toCmd
hinata.appenTextMessage(prefCmd, chatUpdate)
}
}
}
})
//=================================================//
hinata.ev.on('group-participants.update', async (anu) => {
if (wlcm.includes(anu.id)) return
console.log(anu)
try {
let metadata = await hinata.groupMetadata(anu.id)
let participants = anu.participants
for (let num of participants) {
// Get Profile Picture User
try {
ppuser = await hinata.profilePictureUrl(num, 'image')
} catch {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}

// Get Profile Picture Group
try {
ppgroup = await hinata.profilePictureUrl(anu.id, 'image')
} catch {
ppgroup = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}

if (anu.action == 'add') {
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const salam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
const xdate = moment.tz('Asia/Jakarta').format('DD')
const xjam = moment.tz('Asia/Jakarta').format('HH')
const xhari = moment().tz('Asia/Jakarta').locale('id').format('dddd')
const xbulan = moment().tz('Asia/Jakarta').locale('id').format('MMMM')
const xtahun = moment.tz('Asia/Jakarta').format('YYYY')
const xmembers = metadata.participants.length
hinata.sendMessage(anu.id, { image: { url: ppuser }, mentions: [num], caption: `「🔮 🇼‌🇪‌🇱‌🇱‌🇨‌🇴‌🇲‌🇪‌ 🔮」

Halo, Selamat ${salam} 👋
Selamat Datang Di Group *${metadata.subject}*

Mohon kerja samanya ya, Tolong patuhi dan taati peraturan peraturan Grup 😉

   ()   ()
 („• ֊ •„)
━O━O━━━━━━━━━━
꒰ 👤 ~𝗜𝗡𝗙𝗢 𝗨𝗦𝗘𝗥~ ꒱ ೄྀ࿐ ˊˎ-
━━━━━━━━━━━━━━
ミ *Nama* : @${num.split("@")[0]}
ミ *Member* : ke ${xmembers}
ミ *Jam* : ${time}
ミ *Tanggal* : ${xdate}
ミ *Hari* : ${xhari}
ミ *Bulan* : ${xbulan}
ミ *Tahun* : ${xtahun}
━━━━━━━━━━━━━━

${metadata.desc}
`})
} else if (anu.action == 'remove') {
hinata.sendMessage(anu.id, { image: { url: ppuser }, mentions: [num], caption: `✦「♨️ 𝐒αꭑρα𝗂 𝐉υꭑρα ♨️」✦

Selamat tinggal @${num.split("@")[0]} Dari Group *${metadata.subject}*
Terimakasih atas kunjungannya, Semoga hari mu menyenangkan

Ba Bay.. 🤗`})
} else if (anu.action == 'promote') {
hinata.sendMessage(anu.id, { image: { url: ppuser }, mentions: [num], caption: `@${num.split('@')[0]} Ciee Jadi Admin Di Group ${metadata.subject} ${metadata.desc}`  })
} else if (anu.action == 'demote') {
hinata.sendMessage(anu.id, { image: { url: ppuser }, mentions: [num], caption: `@${num.split('@')[0]} Ciee Di Hapus Jadi Admin Di Group ${metadata.subject} ${metadata.desc}`})
  }
}
} catch (err) {
console.log(err)
}
})
//=================================================//
hinata.ev.on('contacts.update', update => {
for (let contact of update) {
let id = hinata.decodeJid(contact.id)
if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }}})
//=================================================//
hinata.getName = (jid, withoutContact  = false) => {
id = hinata.decodeJid(jid)
withoutContact = hinata.withoutContact || withoutContact 
let v
if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
v = store.contacts[id] || {}
if (!(v.name || v.subject)) v = hinata.groupMetadata(id) || {}
resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
})
else v = id === '0@s.whatsapp.net' ? {
id,
name: 'WhatsApp'
} : id === hinata.decodeJid(hinata.user.id) ?
hinata.user :
(store.contacts[id] || {})
return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')}
//=================================================//
hinata.sendContact = async (jid, kon, quoted = '', opts = {}) => {
let list = []
for (let i of kon) {
list.push({
displayName: await hinata.getName(i + '@s.whatsapp.net'),
vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await hinata.getName(i + '@s.whatsapp.net')}\nFN:${await hinata.getName(i + '@s.whatsapp.net')}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Ponsel\nitem2.EMAIL;type=INTERNET:${global.email}\nitem2.X-ABLabel:Email\nitem3.URL:${global.web}\nitem3.X-ABLabel:Instagram\nitem4.ADR:;;${global.region};;;;\nitem4.X-ABLabel:Region\nEND:VCARD`})}
//=================================================//
hinata.sendMessage(jid, { contacts: { displayName: `${list.length} Kontak`, contacts: list }, ...opts }, { quoted })}
//=================================================//
//Kalau Mau Self Lu Buat Jadi false
hinata.public = true
//=================================================//
hinata.ev.on('creds.update', saveCreds)
//=================================================//
hinata.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])}
return buffer}
//=================================================//
hinata.sendImage = async (jid, path, caption = '', quoted = '', options) => {
let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
return await hinata.sendMessage(jid, { image: buffer, caption: caption, ...options }, { quoted })
}
//=================================================//
hinata.sendText = (jid, text, quoted = '', options) => hinata.sendMessage(jid, { text: text, ...options }, { quoted })
//=================================================//
hinata.sendTextWithMentions = async (jid, text, quoted, options = {}) => hinata.sendMessage(jid, { text: text, contextInfo: { mentionedJid: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net') }, ...options }, { quoted })
//=================================================//
hinata.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImg(buff, options)
} else {
buffer = await imageToWebp(buff)}
await hinata.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer}
//=================================================//
hinata.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifVid(buff, options)
} else {
buffer = await videoToWebp(buff)}
await hinata.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer}
//=================================================//
hinata.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
let quoted = message.msg ? message.msg : message
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(quoted, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])}
let type = await FileType.fromBuffer(buffer)
trueFileName = attachExtension ? (filename + '.' + type.ext) : filename
// save to file
await fs.writeFileSync(trueFileName, buffer)
return trueFileName}
//=================================================
hinata.cMod = (jid, copy, text = '', sender = hinata.user.id, options = {}) => {
//let copy = message.toJSON()
let mtype = Object.keys(copy.message)[0]
let isEphemeral = mtype === 'ephemeralMessage'
if (isEphemeral) {
mtype = Object.keys(copy.message.ephemeralMessage.message)[0]}
let msg = isEphemeral ? copy.message.ephemeralMessage.message : copy.message
let content = msg[mtype]
if (typeof content === 'string') msg[mtype] = text || content
else if (content.caption) content.caption = text || content.caption
else if (content.text) content.text = text || content.text
if (typeof content !== 'string') msg[mtype] = {
...content,
...options}
if (copy.key.participant) sender = copy.key.participant = sender || copy.key.participant
else if (copy.key.participant) sender = copy.key.participant = sender || copy.key.participant
if (copy.key.remoteJid.includes('@s.whatsapp.net')) sender = sender || copy.key.remoteJid
else if (copy.key.remoteJid.includes('@broadcast')) sender = sender || copy.key.remoteJid
copy.key.remoteJid = jid
copy.key.fromMe = sender === hinata.user.id
return proto.WebMessageInfo.fromObject(copy)}
hinata.sendFile = async(jid, PATH, fileName, quoted = {}, options = {}) => {
let types = await hinata.getFile(PATH, true)
let { filename, size, ext, mime, data } = types
let type = '', mimetype = mime, pathFile = filename
if (options.asDocument) type = 'document'
if (options.asSticker || /webp/.test(mime)) {
let { writeExif } = require('./HinataBase/lib/sticker.js')
let media = { mimetype: mime, data }
pathFile = await writeExif(media, { packname: global.packname, author: global.packname2, categories: options.categories ? options.categories : [] })
await fs.promises.unlink(filename)
type = 'sticker'
mimetype = 'image/webp'}
else if (/image/.test(mime)) type = 'image'
else if (/video/.test(mime)) type = 'video'
else if (/audio/.test(mime)) type = 'audio'
else type = 'document'
await hinata.sendMessage(jid, { [type]: { url: pathFile }, mimetype, fileName, ...options }, { quoted, ...options })
return fs.promises.unlink(pathFile)}
hinata.parseMention = async(text) => {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')}
//=================================================//
hinata.copyNForward = async (jid, message, forceForward = false, options = {}) => {
let vtype
if (options.readViewOnce) {
message.message = message.message && message.message.ephemeralMessage && message.message.ephemeralMessage.message ? message.message.ephemeralMessage.message : (message.message || undefined)
vtype = Object.keys(message.message.viewOnceMessage.message)[0]
delete(message.message && message.message.ignore ? message.message.ignore : (message.message || undefined))
delete message.message.viewOnceMessage.message[vtype].viewOnce
message.message = {
...message.message.viewOnceMessage.message}}
let mtype = Object.keys(message.message)[0]
let content = await generateForwardMessageContent(message, forceForward)
let ctype = Object.keys(content)[0]
let context = {}
if (mtype != "conversation") context = message.message[mtype].contextInfo
content[ctype].contextInfo = {
...context,
...content[ctype].contextInfo}
const waMessage = await generateWAMessageFromContent(jid, content, options ? {
...content[ctype],
...options,
...(options.contextInfo ? {
contextInfo: {
...content[ctype].contextInfo,
...options.contextInfo}} : {})} : {})
await hinata.relayMessage(jid, waMessage.message, { messageId:  waMessage.key.id })
return waMessage}
//=================================================//
hinata.getFile = async (PATH, save) => {
let res
let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0)
//if (!Buffer.isBuffer(data)) throw new TypeError('Result is not a buffer')
let type = await FileType.fromBuffer(data) || {
mime: 'application/octet-stream',
ext: '.bin'
}
filename = path.join(__filename, '../src/' + new Date * 1 + '.' + type.ext)
if (data && save) fs.promises.writeFile(filename, data)
return {
res,
filename,
	size: await getSizeMedia(data),
...type,
data
}
}
hinata.serializeM = (m) => smsg(hinata, m, store)
//=================================================//
hinata.ev.on('connection.update', async (update) => {
const { connection, lastDisconnect } = update
if (connection === 'close') {
let reason = new Boom(lastDisconnect?.error)?.output.statusCode
if (reason === DisconnectReason.badSession) {
    console.log(`File Sesi Buruk, Harap Hapus Sesi dan Pindai Lagi`);
    starthinata();
  } else if (reason === DisconnectReason.connectionClosed) {
    console.log("Koneksi ditutup, menghubungkan kembali....");
    starthinata();
  } else if (reason === DisconnectReason.connectionLost) {
    console.log("Koneksi Hilang dari Server, menghubungkan kembali...");
    starthinata();
  } else if (reason === DisconnectReason.connectionReplaced) {
    console.log("Koneksi Diganti, Sesi Baru Dibuka, Harap Tutup Sesi Saat Ini Terlebih Dahulu");
    starthinata();
  } else if (reason === DisconnectReason.loggedOut) {
    console.log(`Perangkat Keluar, Harap Pindai Lagi Dan Jalankan.`);
    starthinata();
  } else if (reason === DisconnectReason.restartRequired) {
    console.log("Mengulang kembali Diperlukan, Mengulang kembali...");
    starthinata();
  } else if (reason === DisconnectReason.timedOut) {
    console.log("Koneksi Habis, Menghubungkan...");
    starthinata();
  } else {
    console.log(`Unknown DisconnectReason: ${reason}|${connection}`);
    starthinata();
  }
} if (update.connection == "connecting" || update.receivedPendingNotifications == "false") {
    console.log(color(`\n🔴  Menghubungkan...`, 'yellow'));
} if (update.connection == "open" || update.receivedPendingNotifications == "true") {
    console.log(color(` `,'magenta'));
    console.log(color(`🟢  Terhubung dengan => ` + JSON.stringify(hinata.user, null, 2), 'yellow'));
    await delay(1999);
    console.log(color(`< ============================================ >`, 'cyan'));
    console.log(color(`\n📍 YT CHANNEL: ${global.youtube}`,'magenta'));
    console.log(color(`📍 GITHUB: ${global.github}`,'magenta'));
    console.log(color(`📍 INSTAGRAM: ${global.instagram}`,'magenta'));
    console.log(color(`📍 WA NUMBER: ${owner}`,'magenta'));
    console.log(color(`📍 BOTNAME: ${botname}\n`,'magenta'));
    hinata.sendMessage('6281779122444' + "@s.whatsapp.net", { text: `*🫡 Lapor Komandan!*\n\n🟢 *HinataBot* Telah Aktif \n*HinataBot* Versi : ${global.hinatabotversion}\n\n꒰ 📝 ~𝗜𝗡𝗙𝗢 𝗕𝗢𝗧 𝗦𝗜𝗠𝗣𝗘𝗟~ ꒱ ೄྀ࿐ ˊˎ-\n━━━━━━⊱⋆⊰━━━━━━\nミ *Nama Bot* : ${global.botname}\nミ *Pengembang* : ${global.ownername}\nミ *Nomer* :${global.ownernumber}\nミ *Group* : ${global.gr}\nミ *Instagram* : ${global.instagram}\nミ *Facebook* : ${global.facebook}\nミ *TikTok* : ${global.tiktok}\nミ *YouTube* : ${global.youtube}\nミ *Github* : ${global.github}` });
}
// console.log('Connected...', update)
});
hinata.sendPoll = (jid, name = '', values = [], selectableCount = 1) => { return hinata.sendMessage(jid, { poll: { name, values, selectableCount }}) }
return hinata
}
//=================================================//
starthinata()
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
