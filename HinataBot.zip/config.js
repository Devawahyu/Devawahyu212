const fs = require('fs')
const chalk = require('chalk')

//=================================================//
global.baileys = require('@whiskeysockets/baileys') // Ini modul Ga usah di ubah :v
global.autoTyping = false // Untuk Menampilkan tulisan Sedang Merekan Audio
global.autoRecord = false // Untuk Menampilkan tulisan Sedang Mengetik
global.hideBotOnline = true
global.anticall = true // Anti telpon, Auto block kalau telpon
global.autoblocknokos = true
global.uselimit = true
global.maxwarn = 3
//=================================================//
global.gr = 'https://chat.whatsapp.com/DqRDCdTesfhIU2ET32qS1c' // Tautan Grup WhatsApp
global.web = 'https://github.com/Cie Anak Yatim mau curi SC' // WebSite
global.ig = '@gak Ada' // UserName Instagram
global.email = 'Devawahyusaputra14@gmail.com' // E-Mail
global.region = "-" // Alamat
global.ytname = "YT: Devawahyusaptra952" //ur yt chanel name
global.socialm = "-" //ur github or insta name
global.ownername = 'DevaWahyu' //ubah jadi nama mu, note tanda ' gausah di hapus!
global.owner = ['628884189755'] // ubah aja pake nomor lu
global.ownernumber = '628884189755' // ubah aja pake nomor lu
global.keyopenai = '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'
global.botname = 'ДеваБОТЗИ' //ubah jadi nama bot mu, note tanda ' gausah di hapus!
global.packname = 'ДеваБОТЗИ // ubah aja ini nama sticker
global.author = 'ДеваБОТЗИ' // ubah aja ini nama sticker
global.prefa = ['.']
global.sessionName = 'session' //Gausah Juga
global.sp = '▢' // Gausah Juga
global.wlcm = []
global.wlcmm = []
global.hostname = 'DevaWahyu'
//=================================================//
global.instagram = '-'
global.facebook = '-'
global.tiktok = '-'
global.youtube = 'youtube.com/@devawahyusaputra952'
global.github = 'github.com/Blawuken'
//=================================================//
global.limiuser = 100
//=================================================//
global.mess = {
    success: 'ɴɪʜ... 😉',
}
//=================================================//
global.botversion = '2.1.9'
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})